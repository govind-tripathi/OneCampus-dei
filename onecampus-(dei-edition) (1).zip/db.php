<?php
/**
 * ONECAMPUS (DEI Edition)
 * Database Connection & Global Utility Helpers
 * Dayalbagh Educational Institute, Agra
 */

// Start session if not active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Credentials (Standard XAMPP / WAMP / LAMP defaults)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'onecampus');
define('DB_PORT', 3306);

// Enable MySQLi Exception Reporting for robust error handling
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    // Graceful error display if MySQL is not yet configured or running
    $db_error = $e->getMessage();
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Database Connection Notice - ONECAMPUS DEI</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light d-flex align-items-center min-vh-100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-7">
                    <div class="card shadow-sm border-0 rounded-4 p-4 text-center">
                        <div class="mb-3">
                            <span class="badge bg-danger-subtle text-danger px-3 py-2 rounded-pill fs-6">
                                ⚠️ MySQL Database Offline or Unconfigured
                            </span>
                        </div>
                        <h3 class="fw-bold text-dark mb-2">Connect to MySQL Database</h3>
                        <p class="text-secondary small mb-4">
                            Please ensure your MySQL server (XAMPP / WAMP / AWebServer) is running and import the provided 
                            <code>database.sql</code> script into a database named <code>onecampus</code>.
                        </p>
                        <div class="alert alert-warning text-start small font-monospace">
                            <strong>System Error:</strong> <?= htmlspecialchars($db_error); ?>
                        </div>
                        <div class="d-flex justify-content-center gap-2">
                            <button onclick="window.location.reload();" class="btn btn-emerald px-4" style="background-color: #059669; color: #fff;">
                                🔄 Retry Connection
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

/**
 * Sanitize User Inputs against XSS attacks
 */
function clean($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $conn->real_escape_string($data);
}

/**
 * Set a Flash Message for Bootstrap Toasts / Alerts
 */
function set_flash($message, $type = 'success') {
    $_SESSION['flash_message'] = [
        'text' => $message,
        'type' => $type // 'success', 'danger', 'warning', 'info'
    ];
}

/**
 * Retrieve & Clear Flash Message
 */
function get_flash() {
    if (isset($_SESSION['flash_message'])) {
        $msg = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $msg;
    }
    return null;
}

/**
 * Authentication Helpers
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function current_user() {
    global $conn;
    if (!is_logged_in()) {
        return null;
    }
    $stmt = $conn->prepare("SELECT id, full_name, roll_no, department, email, role, skill_credits, green_points, avatar_seed, created_at FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $res = $stmt->get_result();
    return $res->fetch_assoc();
}

function require_login() {
    if (!is_logged_in()) {
        set_flash("Please login to access the ONECAMPUS portal.", "warning");
        header("Location: login.php");
        exit;
    }
}

function require_admin() {
    require_login();
    $user = current_user();
    if ($user['role'] !== 'admin') {
        set_flash("Unauthorized: Admin privileges required.", "danger");
        header("Location: index.php");
        exit;
    }
}

/**
 * Format relative time (e.g. '5 mins ago')
 */
function time_ago($timestamp) {
    $time = strtotime($timestamp);
    $diff = time() - $time;
    if ($diff < 60) return 'Just now';
    if ($diff < 3600) return round($diff / 60) . ' mins ago';
    if ($diff < 86400) return round($diff / 3600) . ' hrs ago';
    return date('d M, Y', $time);
}
?>
