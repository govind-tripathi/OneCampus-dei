<?php
require_once 'db.php';
require_login();

$user = current_user();
$isAdmin = ($user['role'] === 'admin');

// Ensure uploads directory exists
$upload_dir = __DIR__ . '/uploads';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Handle New Eco / Maintenance Report Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_report') {
    $location = clean($_POST['location'] ?? '');
    $category = clean($_POST['issue_category'] ?? '');
    $description = clean($_POST['description'] ?? '');
    $image_path = null;

    // Handle Photo Upload
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['photo']['tmp_name'];
        $file_name = $_FILES['photo']['name'];
        $file_size = $_FILES['photo']['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $allowed_exts = ['jpg', 'jpeg', 'png', 'webp'];
        $max_size = 5 * 1024 * 1024; // 5 MB

        if (!in_array($file_ext, $allowed_exts)) {
            set_flash("Invalid image format! Please upload JPG, PNG, or WebP.", "danger");
            header("Location: ecopulse.php");
            exit;
        } elseif ($file_size > $max_size) {
            set_flash("Image size exceeds 5MB limit.", "danger");
            header("Location: ecopulse.php");
            exit;
        } else {
            $new_filename = 'eco_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $file_ext;
            $destination = $upload_dir . '/' . $new_filename;
            if (move_uploaded_file($file_tmp, $destination)) {
                $image_path = 'uploads/' . $new_filename;
            }
        }
    }

    if (!empty($location) && !empty($category) && !empty($description)) {
        $stmt = $conn->prepare("INSERT INTO eco_reports (user_id, location, issue_category, description, image_path, status) VALUES (?, ?, ?, ?, ?, 'Open')");
        $stmt->bind_param("issss", $user['id'], $location, $category, $description, $image_path);
        if ($stmt->execute()) {
            set_flash("🌱 Thank you! Your campus care report was logged. You'll receive +10 Green Points upon admin resolution.", "success");
        } else {
            set_flash("Could not submit report.", "danger");
        }
    } else {
        set_flash("Please fill in location, category, and issue description.", "warning");
    }
    header("Location: ecopulse.php");
    exit;
}

// Handle Admin Resolution Action (+10 Green Points to reporter)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'resolve_report') {
    if (!$isAdmin) {
        set_flash("Only faculty administrators can resolve maintenance tickets.", "danger");
        header("Location: ecopulse.php");
        exit;
    }

    $report_id = intval($_POST['report_id'] ?? 0);

    // Fetch reporter ID
    $r_stmt = $conn->prepare("SELECT user_id, status FROM eco_reports WHERE id = ?");
    $r_stmt->bind_param("i", $report_id);
    $r_stmt->execute();
    $rep = $r_stmt->get_result()->fetch_assoc();

    if ($rep && $rep['status'] === 'Open') {
        $conn->begin_transaction();
        try {
            // Update report status
            $u_stmt = $conn->prepare("UPDATE eco_reports SET status = 'Resolved' WHERE id = ?");
            $u_stmt->bind_param("i", $report_id);
            $u_stmt->execute();

            // Reward reporter with 10 Green Points
            $p_stmt = $conn->prepare("UPDATE users SET green_points = green_points + 10 WHERE id = ?");
            $p_stmt->bind_param("i", $rep['user_id']);
            $p_stmt->execute();

            $conn->commit();
            set_flash("✅ Report resolved! Student has been awarded +10 Green Points for their campus stewardship.", "success");
        } catch (Exception $e) {
            $conn->rollback();
            set_flash("Failed to resolve report: " . $e->getMessage(), "danger");
        }
    }
    header("Location: ecopulse.php");
    exit;
}

// Fetch Reports Feed
$feed_stmt = $conn->prepare("
    SELECT r.*, u.full_name, u.department, u.roll_no 
    FROM eco_reports r 
    JOIN users u ON r.user_id = u.id 
    ORDER BY (r.status = 'Open') DESC, r.id DESC
");
$feed_stmt->execute();
$reports = $feed_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch Top 5 Eco Champions Leaderboard
$leader_res = $conn->query("
    SELECT full_name, roll_no, department, green_points 
    FROM users 
    WHERE role = 'student' 
    ORDER BY green_points DESC 
    LIMIT 5
");
$champions = $leader_res->fetch_all(MYSQLI_ASSOC);

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoPulse Campus Care | ONECAMPUS - DEI</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dei-emerald: #059669;
            --dei-emerald-dark: #047857;
            --dei-amber: #f59e0b;
        }
        body {
            background-color: #f8fafc;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            color: #1e293b;
        }
        .navbar-dei {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
        }
        .nav-link.active-tab {
            color: var(--dei-emerald) !important;
            font-weight: 600;
            border-bottom: 2px solid var(--dei-emerald);
        }
        .report-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            transition: all 0.25s ease;
        }
        .report-card:hover {
            box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.06);
            border-color: #cbd5e1;
        }
        .rank-badge {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 12px;
        }
        .rank-1 { background-color: #fef08a; color: #854d0e; }
        .rank-2 { background-color: #e2e8f0; color: #475569; }
        .rank-3 { background-color: #ffedd5; color: #9a3412; }

        .btn-emerald {
            background-color: var(--dei-emerald);
            color: #ffffff;
        }
        .btn-emerald:hover {
            background-color: var(--dei-emerald-dark);
            color: #ffffff;
        }
    </style>
</head>
<body>

<!-- Navigation Header -->
<nav class="navbar navbar-expand-lg navbar-dei sticky-top py-2">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold text-dark" href="index.php">
            <span class="bg-success text-white px-2 py-1 rounded-3 fs-6">
                <i class="fa-solid fa-graduation-cap"></i>
            </span>
            <span>ONECAMPUS <span class="badge bg-light text-success border border-success-subtle fw-normal ms-1" style="font-size: 11px;">DEI Agra</span></span>
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3 gap-1">
                <li class="nav-item">
                    <a class="nav-link px-3 text-secondary" href="index.php">
                        <i class="fa-solid fa-door-open me-1"></i> SmartSpace
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 text-secondary" href="peerlearn.php">
                        <i class="fa-solid fa-handshake-simple me-1"></i> PeerLearn
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 active-tab" href="ecopulse.php">
                        <i class="fa-solid fa-leaf me-1"></i> EcoPulse
                    </a>
                </li>
            </ul>

            <!-- Balance & User -->
            <div class="d-flex align-items-center gap-3">
                <span class="badge bg-success-subtle text-success border border-success px-3 py-2 rounded-pill fw-semibold">
                    <i class="fa-solid fa-award text-success me-1"></i> <?= $user['green_points']; ?> Eco Karma
                </span>

                <div class="dropdown">
                    <button class="btn btn-light btn-sm dropdown-toggle rounded-pill px-3 border" type="button" data-bs-toggle="dropdown">
                        <i class="fa-solid fa-circle-user text-secondary me-1"></i> <?= htmlspecialchars($user['full_name']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                        <li class="px-3 py-1">
                            <small class="text-muted d-block"><?= htmlspecialchars($user['department']); ?></small>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>

<main class="container py-4">

    <!-- Flash Alert -->
    <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type']; ?> alert-dismissible fade show rounded-3 shadow-sm mb-4" role="alert">
            <?= htmlspecialchars($flash['text']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Header Section -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-2 border-bottom">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <span class="badge bg-emerald-subtle text-emerald px-2 py-0.5 rounded" style="background-color: #d1fae5; color: #065f46;">Campus Stewardship</span>
                <span class="text-secondary opacity-50">·</span>
                <span class="text-muted small">Inspired by SeeClickFix & Harvard Sustainability</span>
            </div>
            <h2 class="fw-bold tracking-tight mb-0">EcoPulse Campus Care & Green Audit</h2>
            <p class="text-secondary small mb-0">Report facility maintenance, leaking taps, and green ideas to keep Dayalbagh pristine.</p>
        </div>

        <div class="d-flex gap-2">
            <button type="button" class="btn btn-emerald btn-sm px-3 rounded-pill" data-bs-toggle="modal" data-bs-target="#newReportModal">
                <i class="fa-solid fa-camera me-1"></i> Report an Issue (+10 Karma)
            </button>
        </div>
    </div>

    <div class="row g-4">
        
        <!-- Left: Reported Issues Feed -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="fw-bold mb-0">Campus Issue Tracker</h4>
                    <span class="badge bg-light text-secondary border"><?= count($reports); ?> Reports Logged</span>
                </div>

                <div class="space-y-3">
                    <?php if (empty($reports)): ?>
                        <div class="py-5 text-center text-muted">
                            <i class="fa-solid fa-seedling fs-2 mb-2 d-block opacity-50"></i>
                            All campus facilities are currently running smoothly!
                        </div>
                    <?php else: ?>
                        <?php foreach ($reports as $rep): ?>
                            <?php 
                                $isOpen = ($rep['status'] === 'Open'); 
                                $catIcon = 'fa-wrench';
                                if ($rep['issue_category'] === 'Electrical/Fan') $catIcon = 'fa-bolt text-warning';
                                if ($rep['issue_category'] === 'Water Leakage') $catIcon = 'fa-droplet text-primary';
                                if ($rep['issue_category'] === 'Cleanliness') $catIcon = 'fa-broom text-secondary';
                                if ($rep['issue_category'] === 'Green Initiative') $catIcon = 'fa-leaf text-success';
                            ?>
                            <div class="report-card p-3 mb-3">
                                <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-start gap-2 mb-2">
                                    <div>
                                        <div class="d-flex align-items-center gap-2 mb-1">
                                            <span class="badge <?= $isOpen ? 'bg-danger-subtle text-danger' : 'bg-success-subtle text-success'; ?> px-2 py-1 rounded-pill small fw-semibold">
                                                <i class="fa-solid <?= $isOpen ? 'fa-clock' : 'fa-circle-check'; ?> me-1"></i>
                                                <?= $rep['status']; ?>
                                            </span>
                                            <span class="badge bg-light text-dark border px-2 py-0.5 rounded small">
                                                <i class="fa-solid <?= $catIcon; ?> me-1"></i> <?= htmlspecialchars($rep['issue_category']); ?>
                                            </span>
                                        </div>
                                        <h6 class="fw-bold text-dark mb-1">
                                            <i class="fa-solid fa-location-dot text-danger me-1"></i> <?= htmlspecialchars($rep['location']); ?>
                                        </h6>
                                    </div>

                                    <small class="text-muted" style="font-size: 11px;">
                                        Reported by <?= htmlspecialchars($rep['full_name']); ?> · <?= time_ago($rep['created_at']); ?>
                                    </small>
                                </div>

                                <p class="text-secondary small mb-2" style="line-height: 1.5;">
                                    <?= htmlspecialchars($rep['description']); ?>
                                </p>

                                <?php if (!empty($rep['image_path']) && file_exists(__DIR__ . '/' . $rep['image_path'])): ?>
                                    <div class="mb-3">
                                        <img src="<?= htmlspecialchars($rep['image_path']); ?>" alt="Campus Issue Photo" class="rounded-3 border" style="max-height: 180px; object-fit: cover;">
                                    </div>
                                <?php endif; ?>

                                <!-- Admin Resolution Action Bar -->
                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="small text-muted" style="font-size: 11px;">
                                        <i class="fa-solid fa-coins text-warning me-1"></i> Reward: +10 Green Points upon resolution
                                    </span>

                                    <?php if ($isOpen && $isAdmin): ?>
                                        <form action="ecopulse.php" method="POST" class="m-0">
                                            <input type="hidden" name="action" value="resolve_report">
                                            <input type="hidden" name="report_id" value="<?= $rep['id']; ?>">
                                            <button type="submit" class="btn btn-outline-success btn-sm rounded-pill px-3 py-1" onclick="return confirm('Resolve ticket and grant +10 Green Points to reporter?');">
                                                <i class="fa-solid fa-check me-1"></i> Mark Resolved (+10 Karma)
                                            </button>
                                        </form>
                                    <?php elseif (!$isOpen): ?>
                                        <span class="text-success small fw-medium">
                                            <i class="fa-solid fa-badge-check me-1"></i> Verified & Resolved by Administration
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

            </div>
        </div>

        <!-- Right: DEI Eco-Champions Leaderboard -->
        <div class="col-lg-4">
            
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white mb-4">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h5 class="fw-bold mb-0">🏆 DEI Eco-Champions</h5>
                    <span class="badge bg-success-subtle text-success">Live Karma</span>
                </div>
                <p class="text-secondary small mb-3">Top student stewards actively maintaining Dayalbagh green ethos.</p>

                <div class="list-group list-group-flush">
                    <?php $rank = 1; foreach ($champions as $champ): ?>
                        <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center border-bottom-0">
                            <div class="d-flex align-items-center gap-2">
                                <span class="rank-badge rank-<?= $rank <= 3 ? $rank : '3'; ?>">
                                    <?= $rank; ?>
                                </span>
                                <div>
                                    <div class="fw-bold text-dark small mb-0"><?= htmlspecialchars($champ['full_name']); ?></div>
                                    <small class="text-muted" style="font-size: 11px;"><?= htmlspecialchars($champ['department']); ?></small>
                                </div>
                            </div>
                            <span class="badge bg-emerald-subtle text-emerald rounded-pill px-2 py-1 small fw-bold" style="background-color: #d1fae5; color: #065f46;">
                                <?= $champ['green_points']; ?> pts
                            </span>
                        </div>
                    <?php $rank++; endforeach; ?>
                </div>
            </div>

            <!-- Sustainability Tip Card -->
            <div class="card border-0 shadow-sm rounded-4 p-4 text-white" style="background: linear-gradient(135deg, #059669 0%, #047857 100%);">
                <h6 class="fw-bold mb-2"><i class="fa-solid fa-lightbulb text-warning me-2"></i>Dayalbagh Eco Ethos</h6>
                <p class="small text-white-75 mb-3">
                    Turning off classroom fans and lights when vacating lecture halls saves up to 40 kWh of solar battery storage per block daily!
                </p>
                <div class="text-end">
                    <span class="badge bg-white text-dark small">Eco Audit 2026</span>
                </div>
            </div>

        </div>

    </div>

</main>

<!-- New Report Modal -->
<div class="modal fade" id="newReportModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <div class="modal-header border-bottom-0 pb-0">
                <h5 class="modal-title fw-bold">Report Facility or Eco Need</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="ecopulse.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="submit_report">
                <div class="modal-body">
                    <p class="text-secondary small mb-3">Help the caretaker staff resolve issues quickly. Earn +10 points when resolved.</p>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Campus Location / Room</label>
                        <input type="text" name="location" class="form-control" placeholder="e.g. Faculty of Science, 1st Floor Restroom / E-204" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Category</label>
                        <select name="issue_category" class="form-select" required>
                            <option value="Electrical/Fan">Electrical / Fan Left Running</option>
                            <option value="Water Leakage">Water Leakage / Tap Dripping</option>
                            <option value="Cleanliness">Cleanliness & Waste Segregation</option>
                            <option value="Green Initiative">Green Initiative / Solar Proposal</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Issue Description</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Describe the maintenance issue or suggestion clearly..." required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Attach Photo (Optional, Max 5MB)</label>
                        <input type="file" name="photo" class="form-control" accept="image/png, image/jpeg, image/webp">
                        <small class="text-muted" style="font-size: 11px;">Uploads are stored in <code>uploads/</code> directory.</small>
                    </div>
                </div>
                <div class="modal-footer border-top-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-emerald rounded-pill px-4">Submit Report</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
