import { Room, RoomBooking, Skill, EcoReport, CampusNotification, PublicProfile } from './types';

export const DEI_CAMPUS_CENTER = { lat: 27.2266, lng: 78.0124 };

export const CAMPUS_ZONES_GEO = [
  { label: 'Faculty of Engineering', x: 180, y: 115, lat: 27.2274, lng: 78.0112 },
  { label: 'Faculty of Science & Botanical Garden', x: 400, y: 105, lat: 27.2269, lng: 78.0126 },
  { label: 'Central Library', x: 610, y: 115, lat: 27.2263, lng: 78.0135 },
  { label: 'DEI Girls Hostel', x: 150, y: 315, lat: 27.2255, lng: 78.0108 },
  { label: 'DEI Canteen & Solar Pavilion', x: 355, y: 315, lat: 27.2258, lng: 78.0124 },
  { label: 'Seminar Hall Complex (Dayal Hall)', x: 595, y: 315, lat: 27.2261, lng: 78.0141 }
];

export const getTodayIsoDate = (): string => {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

export const INITIAL_PROFILES: PublicProfile[] = [
  {
    uid: 'demo-aarav',
    fullName: 'Aarav Sharma',
    rollNo: '220101',
    department: 'Faculty of Engineering - Mechanical',
    role: 'student',
    skillCredits: 7,
    greenPoints: 35,
    avatarSeed: 'aarav',
    visibility: 'campus'
  },
  {
    uid: 'demo-priya',
    fullName: 'Priya Verma',
    rollNo: '220205',
    department: 'Faculty of Science - Physics',
    role: 'student',
    skillCredits: 6,
    greenPoints: 45,
    avatarSeed: 'priya',
    visibility: 'campus'
  },
  {
    uid: 'demo-rohan',
    fullName: 'Rohan Gupta',
    rollNo: '220312',
    department: 'Multimedia Lab & Design',
    role: 'student',
    skillCredits: 4,
    greenPoints: 20,
    avatarSeed: 'rohan',
    visibility: 'campus'
  },
  {
    uid: 'demo-sunidhi',
    fullName: 'Sunidhi Satsangi',
    rollNo: '220419',
    department: 'Faculty of Social Sciences',
    role: 'student',
    skillCredits: 8,
    greenPoints: 50,
    avatarSeed: 'sunidhi',
    visibility: 'campus'
  }
];

// All 29 DEI Campus Rooms — Matched 1:1 with CampusFloorPlan.tsx SVG Blueprint
export const INITIAL_ROOMS: Room[] = [
  // 1. Faculty of Engineering (8 rooms)
  {
    docId: 'room-1',
    roomId: 1,
    code: 'E-204',
    buildingName: 'Faculty of Engineering',
    roomName: 'Lecture Hall E-204',
    roomType: 'Classroom',
    capacity: 65,
    status: 'Available',
    currentActivity: 'Free for Group Study & Presentation Rehearsal',
    updatedBy: 'Campus Schedule',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '10 mins ago'
  },
  {
    docId: 'room-2',
    roomId: 2,
    code: 'CAD-01',
    buildingName: 'Faculty of Engineering',
    roomName: 'Advanced CAD/CAM & Robotics Lab',
    roomType: 'Computer Lab',
    capacity: 40,
    status: 'Occupied',
    currentActivity: 'B.Tech Mechanical SolidWorks Practical Session',
    updatedBy: 'Faculty Coordinator',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '25 mins ago'
  },
  {
    docId: 'room-3',
    roomId: 3,
    code: 'E-202',
    buildingName: 'Faculty of Engineering',
    roomName: 'Mechatronics & IoT Workshop',
    roomType: 'Computer Lab',
    capacity: 35,
    status: 'Available',
    currentActivity: 'Open for Embedded Systems Prototyping',
    updatedBy: 'Lab Caretaker',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '18 mins ago'
  },
  {
    docId: 'room-4',
    roomId: 4,
    code: 'E-201',
    buildingName: 'Faculty of Engineering',
    roomName: 'Faculty Conference & Seminar Room',
    roomType: 'Reading Hall',
    capacity: 25,
    status: 'Occupied',
    currentActivity: 'Departmental Curriculum Review Meeting',
    updatedBy: 'Dean Office',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '30 mins ago'
  },
  {
    docId: 'room-5',
    roomId: 5,
    code: 'E-101',
    buildingName: 'Faculty of Engineering',
    roomName: 'Thermodynamics Testing Hall',
    roomType: 'Classroom',
    capacity: 50,
    status: 'Available',
    currentActivity: 'Free for Peer Study & Problem Solving',
    updatedBy: 'Campus Schedule',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '12 mins ago'
  },
  {
    docId: 'room-6',
    roomId: 6,
    code: 'E-102',
    buildingName: 'Faculty of Engineering',
    roomName: 'Electrical Drives & EV Innovation Lab',
    roomType: 'Computer Lab',
    capacity: 45,
    status: 'Occupied',
    currentActivity: 'Electric Vehicle Powertrain Calibration',
    updatedBy: 'EV Lab Team',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '40 mins ago'
  },
  {
    docId: 'room-7',
    roomId: 7,
    code: 'E-103',
    buildingName: 'Faculty of Engineering',
    roomName: 'Student Capstone Project Studio',
    roomType: 'Reading Hall',
    capacity: 30,
    status: 'Available',
    currentActivity: 'Open Collaborative Workbenches Available',
    updatedBy: 'Campus Schedule',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '5 mins ago'
  },
  {
    docId: 'room-8',
    roomId: 8,
    code: 'E-104',
    buildingName: 'Faculty of Engineering',
    roomName: 'Rapid Prototyping & 3D Print Cell',
    roomType: 'Computer Lab',
    capacity: 20,
    status: 'Available',
    currentActivity: 'Available for SLA & FDM Print Slots',
    updatedBy: 'Workshop Staff',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '15 mins ago'
  },

  // 2. Faculty of Science (6 rooms)
  {
    docId: 'room-9',
    roomId: 9,
    code: 'S-102',
    buildingName: 'Faculty of Science',
    roomName: 'Quantum Physics Room S-102',
    roomType: 'Classroom',
    capacity: 45,
    status: 'Available',
    currentActivity: 'Free for Self Study & Peer Mentorship',
    updatedBy: 'Campus Schedule',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '5 mins ago'
  },
  {
    docId: 'room-10',
    roomId: 10,
    code: 'S-OPT',
    buildingName: 'Faculty of Science',
    roomName: 'Spectroscopy & Optics Research Lab',
    roomType: 'Classroom',
    capacity: 30,
    status: 'Occupied',
    currentActivity: 'M.Sc Optics Laser Interferometry Practical',
    updatedBy: 'Lab Assistant',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '40 mins ago'
  },
  {
    docId: 'room-11',
    roomId: 11,
    code: 'S-104',
    buildingName: 'Faculty of Science',
    roomName: 'Condensed Matter Computing Lab',
    roomType: 'Computer Lab',
    capacity: 35,
    status: 'Available',
    currentActivity: 'MATLAB & Python Simulation Terminals Free',
    updatedBy: 'Physics Dept',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '20 mins ago'
  },
  {
    docId: 'room-12',
    roomId: 12,
    code: 'S-CHEM1',
    buildingName: 'Faculty of Science',
    roomName: 'Organic Chemistry Analytical Lab',
    roomType: 'Classroom',
    capacity: 40,
    status: 'Occupied',
    currentActivity: 'B.Sc Titration & Synthesis Batch B',
    updatedBy: 'Chemistry Dept',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '35 mins ago'
  },
  {
    docId: 'room-13',
    roomId: 13,
    code: 'S-MATH',
    buildingName: 'Faculty of Science',
    roomName: 'Applied Mathematics & Statistics Lab',
    roomType: 'Computer Lab',
    capacity: 30,
    status: 'Available',
    currentActivity: 'Open for R / Statistical Computing Practice',
    updatedBy: 'Math Dept',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '8 mins ago'
  },
  {
    docId: 'room-14',
    roomId: 14,
    code: 'S-BIO',
    buildingName: 'Faculty of Science',
    roomName: 'Bio-Science & Botany Observation Lab',
    roomType: 'Reading Hall',
    capacity: 25,
    status: 'Available',
    currentActivity: 'Quiet Microscopy & Herbarium Study',
    updatedBy: 'Botany Wing',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '22 mins ago'
  },

  // 3. Central Library (3 rooms)
  {
    docId: 'room-15',
    roomId: 15,
    code: 'LIB-SR',
    buildingName: 'Central Library',
    roomName: 'Quiet Study Hall - 1st Floor',
    roomType: 'Reading Hall',
    capacity: 120,
    status: 'Available',
    currentActivity: 'Silent Reading & Research Zone (92 Seats Free)',
    updatedBy: 'Library Desk',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '6 mins ago'
  },
  {
    docId: 'room-16',
    roomId: 16,
    code: 'LIB-RES',
    buildingName: 'Central Library',
    roomName: 'Scholars Research & Thesis Carrels',
    roomType: 'Reading Hall',
    capacity: 30,
    status: 'Occupied',
    currentActivity: 'Ph.D & M.Tech Dissertation Writing Hours',
    updatedBy: 'Library Desk',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '45 mins ago'
  },
  {
    docId: 'room-17',
    roomId: 17,
    code: 'LIB-E',
    buildingName: 'Central Library',
    roomName: 'E-Library & Digital Database Terminal',
    roomType: 'Computer Lab',
    capacity: 45,
    status: 'Available',
    currentActivity: 'IEEE / Springer Journal Access Workstations Open',
    updatedBy: 'Digital Archive',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '14 mins ago'
  },

  // 4. Multimedia Lab (5 rooms)
  {
    docId: 'room-18',
    roomId: 18,
    code: 'M-01',
    buildingName: 'Multimedia Lab',
    roomName: 'Creative UI/UX & VR Suite M-01',
    roomType: 'Computer Lab',
    capacity: 32,
    status: 'Available',
    currentActivity: 'Open for Project Work, Figma & Video Editing',
    updatedBy: 'Design Lab',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: 'Just now'
  },
  {
    docId: 'room-19',
    roomId: 19,
    code: 'M-02',
    buildingName: 'Multimedia Lab',
    roomName: 'Sound Engineering & Foley Suite',
    roomType: 'Computer Lab',
    capacity: 15,
    status: 'Occupied',
    currentActivity: 'Campus Radio Podcast Recording Session',
    updatedBy: 'Audio Tech',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '30 mins ago'
  },
  {
    docId: 'room-20',
    roomId: 20,
    code: 'M-03',
    buildingName: 'Multimedia Lab',
    roomName: 'Digital Animation & Render Farm',
    roomType: 'Computer Lab',
    capacity: 25,
    status: 'Available',
    currentActivity: 'Blender & 3D Rendering Nodes Available',
    updatedBy: 'Design Lab',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '16 mins ago'
  },
  {
    docId: 'room-21',
    roomId: 21,
    code: 'M-04',
    buildingName: 'Multimedia Lab',
    roomName: 'Design Thinking Ideation Lounge',
    roomType: 'Reading Hall',
    capacity: 40,
    status: 'Available',
    currentActivity: 'Whiteboard Walls Free for PeerLearn Sprints',
    updatedBy: 'Campus Schedule',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '9 mins ago'
  },
  {
    docId: 'room-22',
    roomId: 22,
    code: 'M-05',
    buildingName: 'Multimedia Lab',
    roomName: 'Video Production & Chroma Studio',
    roomType: 'Classroom',
    capacity: 20,
    status: 'Occupied',
    currentActivity: 'MOOC Lecture Recording in Progress',
    updatedBy: 'Studio Crew',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '50 mins ago'
  },

  // 5. Seminar Hall Complex (3 rooms)
  {
    docId: 'room-23',
    roomId: 23,
    code: 'AUD-01',
    buildingName: 'Seminar Hall Complex',
    roomName: 'Main Auditorium (Dayal Hall)',
    roomType: 'Classroom',
    capacity: 250,
    status: 'Occupied',
    currentActivity: 'Faculty Symposium on Sustainable Energy',
    updatedBy: 'Estate Office',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '1 hour ago'
  },
  {
    docId: 'room-24',
    roomId: 24,
    code: 'CONF-A',
    buildingName: 'Seminar Hall Complex',
    roomName: 'Executive Syndicate Room A',
    roomType: 'Reading Hall',
    capacity: 30,
    status: 'Available',
    currentActivity: 'Available for Debate Society & Seminar Prep',
    updatedBy: 'Campus Schedule',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '20 mins ago'
  },
  {
    docId: 'room-25',
    roomId: 25,
    code: 'CONF-B',
    buildingName: 'Seminar Hall Complex',
    roomName: 'Dean Advisory Board Room',
    roomType: 'Reading Hall',
    capacity: 25,
    status: 'Available',
    currentActivity: 'Vacant — Reserve via Time-Slot Booking',
    updatedBy: 'Estate Office',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '25 mins ago'
  },

  // 6. DEI Canteen & Campus Hub (4 rooms)
  {
    docId: 'room-26',
    roomId: 26,
    code: 'SOL-01',
    buildingName: 'DEI Canteen & Campus Hub',
    roomName: 'Solar Pavilion Study Kiosk',
    roomType: 'Reading Hall',
    capacity: 50,
    status: 'Available',
    currentActivity: 'Open-air collaborative tables with solar USB/AC outlets',
    updatedBy: 'Eco-Club DEI',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '12 mins ago'
  },
  {
    docId: 'room-27',
    roomId: 27,
    code: 'ECO-01',
    buildingName: 'DEI Canteen & Campus Hub',
    roomName: 'Organic Garden Refreshment Deck',
    roomType: 'Reading Hall',
    capacity: 60,
    status: 'Available',
    currentActivity: 'Shaded outdoor seating open for study circles',
    updatedBy: 'Eco-Club DEI',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '28 mins ago'
  },
  {
    docId: 'room-28',
    roomId: 28,
    code: 'DISC-01',
    buildingName: 'DEI Canteen & Campus Hub',
    roomName: 'Peer Discussion Pergola A',
    roomType: 'Reading Hall',
    capacity: 25,
    status: 'Occupied',
    currentActivity: 'PeerLearn Sitar & Music Theory Meet',
    updatedBy: 'Student Hub',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '15 mins ago'
  },
  {
    docId: 'room-29',
    roomId: 29,
    code: 'DISC-02',
    buildingName: 'DEI Canteen & Campus Hub',
    roomName: 'Student Innovation Gazebo B',
    roomType: 'Reading Hall',
    capacity: 25,
    status: 'Available',
    currentActivity: 'Free for Hackathon & Prototype Brainstorming',
    updatedBy: 'Student Hub',
    updatedByUid: 'system',
    visibility: 'campus',
    updatedAtText: '7 mins ago'
  }
];

export const INITIAL_BOOKINGS: RoomBooking[] = [
  {
    id: 'booking-1',
    roomId: 1,
    roomName: 'Lecture Hall E-204',
    buildingName: 'Faculty of Engineering',
    date: getTodayIsoDate(),
    startTime: '14:00',
    endTime: '15:00',
    purpose: 'PeerLearn Python Data Structures Workshop',
    bookedByUid: 'demo-aarav',
    bookedByName: 'Aarav Sharma',
    bookedByRole: 'student',
    status: 'Confirmed',
    visibility: 'campus',
    createdAtText: 'Today'
  },
  {
    id: 'booking-2',
    roomId: 18,
    roomName: 'Creative UI/UX & VR Suite M-01',
    buildingName: 'Multimedia Lab',
    date: getTodayIsoDate(),
    startTime: '16:00',
    endTime: '17:00',
    purpose: 'Figma Mobile Prototyping Group Session',
    bookedByUid: 'demo-rohan',
    bookedByName: 'Rohan Gupta',
    bookedByRole: 'student',
    status: 'Confirmed',
    visibility: 'campus',
    createdAtText: 'Today'
  },
  {
    id: 'booking-3',
    roomId: 9,
    roomName: 'Quantum Physics Room S-102',
    buildingName: 'Faculty of Science',
    date: getTodayIsoDate(),
    startTime: '11:00',
    endTime: '12:00',
    purpose: 'Wavefunction Tutorial & Exam Prep',
    bookedByUid: 'demo-priya',
    bookedByName: 'Priya Verma',
    bookedByRole: 'student',
    status: 'Confirmed',
    visibility: 'campus',
    createdAtText: 'Today'
  }
];

export const INITIAL_SKILLS: Skill[] = [
  {
    id: 'skill-1',
    userUid: 'demo-aarav',
    userName: 'Aarav Sharma',
    userDepartment: 'Faculty of Engineering',
    userRollNo: '220101',
    skillTitle: 'Python Data Structures & LeetCode Prep',
    category: 'Coding',
    description: 'Master Trees, Graphs, and Dynamic Programming with structured whiteboard walkthroughs aligned with DEI coursework.',
    availabilityTime: 'Mon & Thu: 5:00 PM - 7:00 PM',
    visibility: 'campus',
    createdAtText: '2 days ago'
  },
  {
    id: 'skill-2',
    userUid: 'demo-rohan',
    userName: 'Rohan Gupta',
    userDepartment: 'Multimedia Lab & Design',
    userRollNo: '220312',
    skillTitle: 'Figma UI/UX & Mobile App Prototyping',
    category: 'Design',
    description: 'Learn wireframing, auto-layout, interactive prototypes, and clean component systems for semester project demos.',
    availabilityTime: 'Tue & Sat: 4:30 PM - 6:30 PM',
    visibility: 'campus',
    createdAtText: '3 days ago'
  },
  {
    id: 'skill-3',
    userUid: 'demo-priya',
    userName: 'Priya Verma',
    userDepartment: 'Faculty of Science',
    userRollNo: '220205',
    skillTitle: 'Quantum Mechanics & Mathematical Physics',
    category: 'Academics',
    description: 'Step-by-step problem solving on Wavefunctions, Operators, and Dirac notation ahead of mid-semester exams.',
    availabilityTime: 'Wed & Fri: 3:00 PM - 5:00 PM',
    visibility: 'campus',
    createdAtText: '4 days ago'
  },
  {
    id: 'skill-4',
    userUid: 'demo-sunidhi',
    userName: 'Sunidhi Satsangi',
    userDepartment: 'Faculty of Social Sciences',
    userRollNo: '220419',
    skillTitle: 'Classical Sitar & Morning Ragas (DEI Tradition)',
    category: 'Music/Art',
    description: 'Hands-on beginner guidance in classical finger techniques, Swaras, and Raga Yaman fundamentals.',
    availabilityTime: 'Sunday: 10:00 AM - 12:00 PM',
    visibility: 'campus',
    createdAtText: '5 days ago'
  },
  {
    id: 'skill-5',
    userUid: 'demo-aarav',
    userName: 'Aarav Sharma',
    userDepartment: 'Faculty of Engineering',
    userRollNo: '220101',
    skillTitle: 'SolidWorks 3D Modeling & 3D Printing Prep',
    category: 'Design',
    description: 'Mechanical CAD assemblies, tolerance checks, and STL slicing for the DEI Engineering prototyping cell.',
    availabilityTime: 'Friday: 4:00 PM - 6:00 PM',
    visibility: 'campus',
    createdAtText: '6 days ago'
  },
  {
    id: 'skill-6',
    userUid: 'demo-priya',
    userName: 'Priya Verma',
    userDepartment: 'Faculty of Science',
    userRollNo: '220205',
    skillTitle: 'LaTeX Thesis & Research Paper Formatting',
    category: 'Academics',
    description: 'Typeset clean equations, BibTeX references, and IEEE figures in Overleaf without formatting headaches.',
    availabilityTime: 'Saturday: 2:00 PM - 4:00 PM',
    visibility: 'campus',
    createdAtText: '1 week ago'
  }
];

export const INITIAL_REPORTS: EcoReport[] = [
  {
    id: 'eco-1',
    userUid: 'demo-aarav',
    userName: 'Aarav Sharma',
    userDepartment: 'Faculty of Engineering',
    location: 'Faculty of Engineering, Corridor 2nd Floor (E-202)',
    issueCategory: 'Electrical/Fan',
    description: 'Fan regulator sparking in room E-202 and two ceiling fans left spinning in an empty classroom at noon.',
    mapX: 180,
    mapY: 115,
    lat: 27.2274,
    lng: 78.0112,
    status: 'Open',
    visibility: 'campus',
    createdAtText: '45 mins ago'
  },
  {
    id: 'eco-2',
    userUid: 'demo-priya',
    userName: 'Priya Verma',
    userDepartment: 'Faculty of Science',
    location: 'Faculty of Science, Near Botanical Garden Tap',
    issueCategory: 'Water Leakage',
    description: 'RO drinking water dispenser tap is dripping continuously; washer seal replacement needed.',
    mapX: 400,
    mapY: 105,
    lat: 27.2269,
    lng: 78.0126,
    status: 'Open',
    visibility: 'campus',
    createdAtText: '2 hours ago'
  },
  {
    id: 'eco-3',
    userUid: 'demo-rohan',
    userName: 'Rohan Gupta',
    userDepartment: 'Multimedia Lab & Design',
    location: 'Central Library Back Lawn',
    issueCategory: 'Cleanliness',
    description: 'Dry leaves and paper cups collected near outdoor reading benches after rehearsal.',
    mapX: 615,
    mapY: 125,
    lat: 27.2263,
    lng: 78.0135,
    status: 'Resolved',
    resolvedBy: 'Portal Administrator',
    resolutionNote: 'Cleared and placed two new waste segregation bins near reading benches.',
    visibility: 'campus',
    createdAtText: 'Yesterday'
  },
  {
    id: 'eco-4',
    userUid: 'demo-sunidhi',
    userName: 'Sunidhi Satsangi',
    userDepartment: 'Faculty of Social Sciences',
    location: 'DEI Canteen & Solar Courtyard',
    issueCategory: 'Green Initiative',
    description: 'Proposal for a 3-bin segregated composting station near canteen seating for organic waste.',
    mapX: 355,
    mapY: 315,
    lat: 27.2258,
    lng: 78.0124,
    status: 'Open',
    visibility: 'campus',
    createdAtText: '3 hours ago'
  }
];

export const INITIAL_NOTIFICATIONS: CampusNotification[] = [
  {
    id: 'notif-1',
    type: 'room_booking',
    title: 'Slot Reserved: Lecture Hall E-204',
    message: 'Aarav Sharma booked E-204 (14:00 - 15:00) for PeerLearn Python Workshop.',
    actorUid: 'demo-aarav',
    linkTab: 'smartspace',
    visibility: 'campus',
    timeText: '15 mins ago'
  },
  {
    id: 'notif-2',
    type: 'eco_report',
    title: 'New EcoPulse Report Logged',
    message: 'Priya Verma reported a dripping RO water tap near Faculty of Science Botanical Garden.',
    actorUid: 'demo-priya',
    linkTab: 'ecopulse',
    visibility: 'campus',
    timeText: '2 hours ago'
  }
];

export const DEI_TRIVIA = [
  {
    q: "What is Dayalbagh Educational Institute's foundational life philosophy?",
    a: "'Work is Worship' and the harmonious integration of Science with Spirituality."
  },
  {
    q: "Which faculty at DEI pioneered solar microgrids and electric vehicle R&D labs?",
    a: "The Faculty of Engineering, Dayalbagh."
  },
  {
    q: "What zero-waste agricultural and dairy model is practiced in Dayalbagh?",
    a: "The community-managed Gaushala & organic Dairy Farming Cooperative."
  },
  {
    q: "Which classical Indian music tradition is practiced during early morning hours in Dayalbagh?",
    a: "Hindustani morning Ragas such as Raga Bhairav and Raga Yaman."
  }
];
