import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  Building2,
  Users,
  Leaf,
  Download,
  Calendar
} from 'lucide-react';
import { Room, RoomBooking, Skill, SkillTransaction, EcoReport } from './types';

interface Props {
  rooms: Room[];
  bookings: RoomBooking[];
  skills: Skill[];
  transactions: SkillTransaction[];
  reports: EcoReport[];
}

function downloadCsv(filename: string, headers: string[], rows: (string | number)[][]) {
  const escapeCell = (val: string | number) => {
    const str = String(val ?? '');
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const csvContent = [
    headers.map(escapeCell).join(','),
    ...rows.map(row => row.map(escapeCell).join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const FacultyTrends: React.FC<Props> = ({
  rooms,
  bookings,
  skills,
  transactions,
  reports
}) => {
  const [selectedMetric, setSelectedMetric] = useState<'occupancy' | 'bookings' | 'skills' | 'eco'>('occupancy');

  const buildingStats = useMemo(() => {
    const buildings = Array.from(new Set(rooms.map(r => r.buildingName)));
    return buildings.map(bName => {
      const bRooms = rooms.filter(r => r.buildingName === bName);
      const totalRooms = bRooms.length;
      const availableRooms = bRooms.filter(r => r.status === 'Available').length;
      const occupiedRooms = totalRooms - availableRooms;
      const occupancyPct = totalRooms > 0 ? Math.round((occupiedRooms / totalRooms) * 100) : 0;
      const totalSeats = bRooms.reduce((sum, r) => sum + r.capacity, 0);
      const confirmedBookings = bookings.filter(
        bk => bk.buildingName === bName && bk.status === 'Confirmed'
      ).length;

      return {
        buildingName: bName,
        totalRooms,
        availableRooms,
        occupiedRooms,
        occupancyPct,
        totalSeats,
        confirmedBookings
      };
    });
  }, [rooms, bookings]);

  const skillCategoryStats = useMemo(() => {
    const categories: Array<'Coding' | 'Academics' | 'Design' | 'Music/Art'> = [
      'Coding',
      'Academics',
      'Design',
      'Music/Art'
    ];
    return categories.map(cat => {
      const offerings = skills.filter(s => s.category === cat).length;
      const completed = transactions.filter(t => t.category === cat && t.status === 'Completed').length;
      const requested = transactions.filter(t => t.category === cat && t.status === 'Requested').length;
      return { cat, offerings, completed, requested };
    });
  }, [skills, transactions]);

  const ecoCategoryStats = useMemo(() => {
    const cats: Array<'Electrical/Fan' | 'Water Leakage' | 'Cleanliness' | 'Green Initiative'> = [
      'Electrical/Fan',
      'Water Leakage',
      'Cleanliness',
      'Green Initiative'
    ];
    return cats.map(cat => {
      const total = reports.filter(r => r.issueCategory === cat).length;
      const open = reports.filter(r => r.issueCategory === cat && r.status === 'Open').length;
      const resolved = total - open;
      return { cat, total, open, resolved };
    });
  }, [reports]);

  const overallOccupancy = rooms.length > 0
    ? Math.round((rooms.filter(r => r.status === 'Occupied').length / rooms.length) * 100)
    : 0;
  const totalConfirmedBookings = bookings.filter(b => b.status === 'Confirmed').length;
  const resolvedEcoCount = reports.filter(r => r.status === 'Resolved').length;

  const handleExportRoomsCsv = () => {
    downloadCsv(
      'onecampus_rooms_live.csv',
      ['Code', 'Building', 'Room Name', 'Type', 'Capacity', 'Status', 'Current Activity', 'Updated By'],
      rooms.map(r => [r.code, r.buildingName, r.roomName, r.roomType, r.capacity, r.status, r.currentActivity, r.updatedBy])
    );
  };

  const handleExportBookingsCsv = () => {
    downloadCsv(
      'onecampus_bookings.csv',
      ['Room', 'Building', 'Date', 'Start', 'End', 'Purpose', 'Reserved By', 'Role', 'Status'],
      bookings.map(b => [b.roomName, b.buildingName, b.date, b.startTime, b.endTime, b.purpose, b.bookedByName, b.bookedByRole, b.status])
    );
  };

  const handleExportEcoCsv = () => {
    downloadCsv(
      'onecampus_ecopulse_reports.csv',
      ['Location', 'Category', 'Status', 'Reporter', 'Department', 'Map X', 'Map Y', 'Description'],
      reports.map(r => [r.location, r.issueCategory, r.status, r.userName, r.userDepartment, r.mapX, r.mapY, r.description])
    );
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-5 transition-colors">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span className="font-semibold text-blue-700 dark:text-cyan-400 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              Live Dataset Analytics
            </span>
            <span aria-hidden="true">·</span>
            <span>Computed from current Firestore records</span>
          </div>
          <h3 className="font-bold text-slate-900 dark:text-slate-100 text-lg font-heading">
            Campus Utilization, Bookings &amp; EcoPulse Breakdown
          </h3>
        </div>

        {/* CSV Export Controls */}
        <div className="grid grid-cols-3 sm:flex sm:flex-wrap items-center gap-2">
          <button
            onClick={handleExportRoomsCsv}
            className="min-h-[40px] sm:min-h-0 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] sm:text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-blue-700 dark:text-cyan-400 shrink-0" />
            <span>Rooms CSV</span>
          </button>
          <button
            onClick={handleExportBookingsCsv}
            className="min-h-[40px] sm:min-h-0 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] sm:text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-blue-700 dark:text-cyan-400 shrink-0" />
            <span>Bookings</span>
          </button>
          <button
            onClick={handleExportEcoCsv}
            className="min-h-[40px] sm:min-h-0 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] sm:text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-blue-700 dark:text-cyan-400 shrink-0" />
            <span>Eco CSV</span>
          </button>
        </div>
      </div>

      {/* Real KPI Summary Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
          <div className="text-slate-500 dark:text-slate-400 font-medium mb-1">Overall Campus Occupancy</div>
          <div className="text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            {overallOccupancy}%{' '}
            <span className="text-xs font-normal text-slate-500">
              ({rooms.filter(r => r.status === 'Occupied').length} of {rooms.length} rooms)
            </span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
          <div className="text-slate-500 dark:text-slate-400 font-medium mb-1">Confirmed Time-Slot Bookings</div>
          <div className="text-xl font-bold font-mono tabular-nums text-blue-700 dark:text-cyan-400">
            {totalConfirmedBookings}{' '}
            <span className="text-xs font-normal text-slate-500">active reservations</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
          <div className="text-slate-500 dark:text-slate-400 font-medium mb-1">EcoPulse Verified Resolutions</div>
          <div className="text-xl font-bold font-mono tabular-nums text-indigo-700 dark:text-indigo-400">
            {resolvedEcoCount} of {reports.length}{' '}
            <span className="text-xs font-normal text-slate-500">({resolvedEcoCount * 10} Karma awarded)</span>
          </div>
        </div>
      </div>

      {/* Chart Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 border-b border-slate-100 dark:border-slate-800 scrollbar-thin">
        <button
          onClick={() => setSelectedMetric('occupancy')}
          className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            selectedMetric === 'occupancy'
              ? 'bg-blue-700 text-white'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Occupancy by Building</span>
        </button>

        <button
          onClick={() => setSelectedMetric('bookings')}
          className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            selectedMetric === 'bookings'
              ? 'bg-blue-700 text-white'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Reservations by Building</span>
        </button>

        <button
          onClick={() => setSelectedMetric('skills')}
          className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            selectedMetric === 'skills'
              ? 'bg-amber-500 text-slate-950'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>PeerLearn Categories</span>
        </button>

        <button
          onClick={() => setSelectedMetric('eco')}
          className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            selectedMetric === 'eco'
              ? 'bg-indigo-700 text-white'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Leaf className="w-3.5 h-3.5" />
          <span>EcoPulse Resolution Mix</span>
        </button>
      </div>

      {/* Real Computed Bar Charts */}
      <div className="space-y-3">
        {(selectedMetric === 'occupancy' || selectedMetric === 'bookings') &&
          buildingStats.map(b => {
            const pct =
              selectedMetric === 'occupancy'
                ? b.occupancyPct
                : totalConfirmedBookings > 0
                  ? Math.round((b.confirmedBookings / totalConfirmedBookings) * 100)
                  : 0;

            return (
              <div key={b.buildingName} className="p-3 rounded-xl bg-slate-50/70 dark:bg-slate-800/40">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs mb-1.5 gap-0.5 sm:gap-2">
                  <span className="font-bold text-slate-800 dark:text-slate-200">{b.buildingName}</span>
                  <span className="font-mono tabular-nums text-[11px] sm:text-xs text-slate-600 dark:text-slate-300">
                    {selectedMetric === 'occupancy'
                      ? `${b.occupiedRooms}/${b.totalRooms} occupied (${b.occupancyPct}%) · ${b.availableRooms} free`
                      : `${b.confirmedBookings} active slot${b.confirmedBookings === 1 ? '' : 's'} · ${b.totalSeats} seats`}
                  </span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 overflow-hidden">
                  <div
                    className={`h-2.5 rounded-full transition-all duration-300 ${
                      selectedMetric === 'occupancy' ? 'bg-blue-700' : 'bg-cyan-600'
                    }`}
                    style={{ width: `${Math.max(pct, 4)}%` }}
                  />
                </div>
              </div>
            );
          })}

        {selectedMetric === 'skills' &&
          skillCategoryStats.map(item => {
            const maxOffer = Math.max(1, ...skillCategoryStats.map(s => s.offerings));
            const pct = Math.round((item.offerings / maxOffer) * 100);
            return (
              <div key={item.cat} className="p-3 rounded-xl bg-slate-50/70 dark:bg-slate-800/40">
                <div className="flex items-center justify-between text-xs mb-1.5 gap-2">
                  <span className="font-bold text-slate-800 dark:text-slate-200">{item.cat}</span>
                  <span className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    {item.offerings} listings · {item.completed} completed · {item.requested} pending
                  </span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 overflow-hidden">
                  <div
                    className="bg-amber-500 h-2.5 rounded-full transition-all duration-300"
                    style={{ width: `${Math.max(pct, item.offerings > 0 ? 12 : 3)}%` }}
                  />
                </div>
              </div>
            );
          })}

        {selectedMetric === 'eco' &&
          ecoCategoryStats.map(item => {
            const pct = item.total > 0 ? Math.round((item.resolved / item.total) * 100) : 0;
            return (
              <div key={item.cat} className="p-3 rounded-xl bg-slate-50/70 dark:bg-slate-800/40">
                <div className="flex items-center justify-between text-xs mb-1.5 gap-2">
                  <span className="font-bold text-slate-800 dark:text-slate-200">{item.cat}</span>
                  <span className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    {item.resolved}/{item.total} resolved ({item.open} open)
                  </span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 overflow-hidden">
                  <div
                    className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300"
                    style={{ width: `${Math.max(pct, item.total > 0 ? 8 : 3)}%` }}
                  />
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
};
