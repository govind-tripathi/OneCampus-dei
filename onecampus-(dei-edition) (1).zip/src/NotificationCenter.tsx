import React, { useState, useEffect, useRef } from 'react';
import {
  Bell,
  CheckCheck,
  Coins,
  Award,
  BookOpen,
  Calendar,
  Flame,
  DoorOpen
} from 'lucide-react';
import { CampusNotification } from './types';

interface Props {
  notifications: CampusNotification[];
  onNavigateTab: (tab: 'smartspace' | 'peerlearn' | 'ecopulse') => void;
}

export const NotificationCenter: React.FC<Props> = ({ notifications, onNavigateTab }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [readIds, setReadIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('onecampus_read_notif_ids');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      localStorage.setItem('onecampus_read_notif_ids', JSON.stringify(readIds));
    } catch {
      // ignore storage failure
    }
  }, [readIds]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unreadCount = notifications.filter(n => !readIds.includes(n.id)).length;

  const markAllAsRead = () => {
    setReadIds(notifications.map(n => n.id));
  };

  const handleNotificationClick = (notif: CampusNotification) => {
    if (!readIds.includes(notif.id)) {
      setReadIds(prev => [...prev, notif.id]);
    }
    if (notif.linkTab) {
      onNavigateTab(notif.linkTab);
      setIsOpen(false);
    }
  };

  return (
    <div ref={dropdownRef} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        title="Live Campus Activity Notifications"
        aria-label="Campus Notifications"
      >
        <Bell className="w-4 h-4" />
        {unreadCount > 0 && (
          <span className="absolute top-0.5 right-0.5 inline-flex rounded-full h-4 min-w-[16px] px-1 bg-blue-700 text-white text-[9px] font-bold items-center justify-center font-mono tabular-nums">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="fixed inset-x-3 top-16 sm:inset-auto sm:absolute sm:right-0 sm:top-full sm:mt-2 sm:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-3 z-50">
          <div className="flex items-center justify-between pb-2.5 mb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="font-bold text-xs text-slate-900 dark:text-slate-100">Campus Activity Feed</span>
              {unreadCount > 0 && (
                <span className="text-[11px] font-mono font-semibold text-blue-700 dark:text-cyan-400">
                  {unreadCount} new
                </span>
              )}
            </div>

            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="text-[11px] text-blue-700 dark:text-cyan-400 hover:underline flex items-center gap-1 font-medium"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                Mark all read
              </button>
            )}
          </div>

          {notifications.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              No campus activity events yet. Book a room, post a skill, or log a report to see live updates here.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-80 overflow-y-auto scrollbar-thin">
              {notifications.map(notif => {
                const isRead = readIds.includes(notif.id);
                let icon = <BookOpen className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
                let iconBg = 'bg-emerald-50 dark:bg-emerald-950/50';

                if (notif.type === 'room_booking') {
                  icon = <Calendar className="w-4 h-4 text-teal-600 dark:text-teal-400" />;
                  iconBg = 'bg-teal-50 dark:bg-teal-950/50';
                } else if (notif.type === 'room_status') {
                  icon = <DoorOpen className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
                  iconBg = 'bg-emerald-50 dark:bg-emerald-950/50';
                } else if (notif.type === 'peer_credit') {
                  icon = <Coins className="w-4 h-4 text-amber-500" />;
                  iconBg = 'bg-amber-50 dark:bg-amber-950/50';
                } else if (notif.type === 'eco_reward') {
                  icon = <Award className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
                  iconBg = 'bg-emerald-50 dark:bg-emerald-950/50';
                } else if (notif.type === 'eco_report') {
                  icon = <Flame className="w-4 h-4 text-rose-500" />;
                  iconBg = 'bg-rose-50 dark:bg-rose-950/50';
                }

                return (
                  <div
                    key={notif.id}
                    onClick={() => handleNotificationClick(notif)}
                    className={`p-2.5 rounded-xl cursor-pointer transition-colors flex items-start gap-3 ${
                      !isRead
                        ? 'bg-slate-50/90 dark:bg-slate-800/70 hover:bg-slate-100 dark:hover:bg-slate-800'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/40 opacity-75'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg ${iconBg} flex items-center justify-center shrink-0 mt-0.5`}>
                      {icon}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-0.5">
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                          {notif.title}
                        </span>
                        <span className="text-[10px] text-slate-400 shrink-0 font-mono">
                          {notif.timeText}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
                        {notif.message}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
