export type UserRole = 'student' | 'faculty' | 'admin';

export interface PublicProfile {
  uid: string;
  fullName: string;
  rollNo: string;
  department: string;
  role: UserRole;
  skillCredits: number;
  greenPoints: number;
  avatarSeed: string;
  visibility: 'campus';
  lastCreditTxnId?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Room {
  docId: string;
  roomId: number;
  code: string;
  buildingName: string;
  roomName: string;
  roomType: 'Classroom' | 'Computer Lab' | 'Reading Hall';
  capacity: number;
  status: 'Available' | 'Occupied';
  currentActivity: string;
  updatedBy: string;
  updatedByUid: string;
  visibility: 'campus';
  updatedAtText: string;
}

export interface RoomBooking {
  id: string;
  roomId: number;
  roomName: string;
  buildingName: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:MM (24h)
  endTime: string; // HH:MM (24h)
  purpose: string;
  bookedByUid: string;
  bookedByName: string;
  bookedByRole: UserRole;
  status: 'Confirmed' | 'Cancelled';
  visibility: 'campus';
  createdAtText: string;
}

export interface Skill {
  id: string;
  userUid: string;
  userName: string;
  userDepartment: string;
  userRollNo: string;
  skillTitle: string;
  category: 'Coding' | 'Academics' | 'Design' | 'Music/Art';
  description: string;
  availabilityTime: string;
  visibility: 'campus';
  createdAtText: string;
}

export interface SkillTransaction {
  id: string;
  skillId: string;
  skillTitle: string;
  category: string;
  learnerUid: string;
  learnerName: string;
  mentorUid: string;
  mentorName: string;
  participantUids: string[];
  status: 'Requested' | 'Completed';
  rating?: number;
  review?: string;
  createdAtText: string;
}

export interface EcoReport {
  id: string;
  userUid: string;
  userName: string;
  userDepartment: string;
  location: string;
  issueCategory: 'Electrical/Fan' | 'Water Leakage' | 'Cleanliness' | 'Green Initiative';
  description: string;
  imageData?: string;
  afterImageData?: string;
  resolutionNote?: string;
  mapX: number;
  mapY: number;
  lat?: number;
  lng?: number;
  gpsAccuracy?: number;
  status: 'Open' | 'Resolved';
  resolvedBy?: string;
  visibility: 'campus';
  createdAtText: string;
}

export interface CampusNotification {
  id: string;
  type: 'room_booking' | 'room_status' | 'peer_request' | 'peer_credit' | 'eco_report' | 'eco_reward' | 'new_skill';
  title: string;
  message: string;
  actorUid: string;
  linkTab: 'smartspace' | 'peerlearn' | 'ecopulse';
  visibility: 'campus';
  timeText: string;
}

export interface ToastMessage {
  id: string;
  text: string;
  type: 'success' | 'warning' | 'danger' | 'info';
}
