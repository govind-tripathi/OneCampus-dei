import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  writeBatch,
  serverTimestamp
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { INITIAL_ROOMS, INITIAL_SKILLS, INITIAL_REPORTS, INITIAL_BOOKINGS } from './initialData';

export const ADMIN_EMAIL = 'tripathig175@gmail.com';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration: client is offline.');
    }
    return false;
  }
}

export async function seedCampusBaselineToFirestore(adminUid: string, adminName: string): Promise<void> {
  const batch = writeBatch(db);

  // Seed / reset all 29 SmartSpace rooms idempotently
  for (const room of INITIAL_ROOMS) {
    const roomRef = doc(db, 'rooms', room.docId);
    batch.set(roomRef, {
      roomId: room.roomId,
      code: room.code,
      buildingName: room.buildingName,
      roomName: room.roomName,
      roomType: room.roomType,
      capacity: room.capacity,
      status: room.status,
      currentActivity: room.currentActivity,
      updatedBy: room.updatedBy,
      updatedByUid: adminUid,
      visibility: 'campus',
      updatedAt: serverTimestamp(),
    });
  }

  // Only create starter skills, reports, and bookings if missing so immutable createdAt/Resolved docs are preserved on re-sync
  const [skillSnaps, reportSnaps, bookingSnaps] = await Promise.all([
    Promise.all(INITIAL_SKILLS.map(s => getDoc(doc(db, 'skills', s.id)))),
    Promise.all(INITIAL_REPORTS.map(r => getDoc(doc(db, 'ecoReports', r.id)))),
    Promise.all(INITIAL_BOOKINGS.map(b => getDoc(doc(db, 'roomBookings', b.id))))
  ]);

  INITIAL_SKILLS.forEach((skill, idx) => {
    if (!skillSnaps[idx].exists()) {
      batch.set(doc(db, 'skills', skill.id), {
        userUid: adminUid,
        userName: skill.userName,
        userDepartment: skill.userDepartment,
        userRollNo: skill.userRollNo,
        skillTitle: skill.skillTitle,
        category: skill.category,
        description: skill.description,
        availabilityTime: skill.availabilityTime,
        visibility: 'campus',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  });

  INITIAL_REPORTS.forEach((rep, idx) => {
    if (!reportSnaps[idx].exists()) {
      batch.set(doc(db, 'ecoReports', rep.id), {
        userUid: adminUid,
        userName: rep.userName,
        userDepartment: rep.userDepartment,
        location: rep.location,
        issueCategory: rep.issueCategory,
        description: rep.description,
        mapX: rep.mapX,
        mapY: rep.mapY,
        ...(typeof rep.lat === 'number' ? { lat: rep.lat } : {}),
        ...(typeof rep.lng === 'number' ? { lng: rep.lng } : {}),
        status: rep.status,
        ...(rep.status === 'Resolved' ? { resolvedBy: adminName } : {}),
        ...(rep.resolutionNote ? { resolutionNote: rep.resolutionNote } : {}),
        visibility: 'campus',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  });

  INITIAL_BOOKINGS.forEach((bk, idx) => {
    if (!bookingSnaps[idx].exists()) {
      batch.set(doc(db, 'roomBookings', bk.id), {
        roomId: bk.roomId,
        roomName: bk.roomName,
        buildingName: bk.buildingName,
        date: bk.date,
        startTime: bk.startTime,
        endTime: bk.endTime,
        purpose: bk.purpose,
        bookedByUid: adminUid,
        bookedByName: bk.bookedByName,
        bookedByRole: bk.bookedByRole,
        status: bk.status,
        visibility: 'campus',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  });

  try {
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'seedCampusBaselineToFirestore');
  }
}
