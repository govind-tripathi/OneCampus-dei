// Adaptive JPEG compression keeping Data URLs strictly <= 200KB (Firestore limit is 250KB)

function compressCanvasToDataUrl(
  source: HTMLImageElement | HTMLVideoElement,
  srcWidth: number,
  srcHeight: number
): string {
  const attempts: Array<{ maxDim: number; quality: number }> = [
    { maxDim: 680, quality: 0.65 },
    { maxDim: 560, quality: 0.54 },
    { maxDim: 440, quality: 0.42 },
    { maxDim: 340, quality: 0.34 }
  ];

  for (const { maxDim, quality } of attempts) {
    const largestSide = Math.max(srcWidth, srcHeight);
    const scale = largestSide > maxDim ? maxDim / largestSide : 1;
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(srcWidth * scale));
    canvas.height = Math.max(1, Math.round(srcHeight * scale));
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Canvas context unavailable for image processing.');
    }
    ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
    const compressed = canvas.toDataURL('image/jpeg', quality);
    if (compressed.length <= 200000) {
      return compressed;
    }
  }

  throw new Error('Photo is still too large after compression. Please try another shot.');
}

export async function compressImageFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const result = compressCanvasToDataUrl(img, img.width, img.height);
        resolve(result);
      } catch (err) {
        reject(err instanceof Error ? err : new Error('Failed to compress image.'));
      } finally {
        URL.revokeObjectURL(objectUrl);
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Could not read the selected image file.'));
    };
    img.src = objectUrl;
  });
}

export function captureVideoFrameCompressed(video: HTMLVideoElement): string {
  const w = video.videoWidth || 640;
  const h = video.videoHeight || 480;
  return compressCanvasToDataUrl(video, w, h);
}

export function estimateDataUrlKb(dataUrl?: string): number {
  if (!dataUrl) return 0;
  const base64Part = dataUrl.split(',')[1] || '';
  return Math.max(1, Math.round((base64Part.length * 3) / 4 / 1024));
}
