import React, { useState } from 'react';
import { Room, RoomBooking } from './types';
import {
  Layers,
  Users,
  Sliders,
  Eye,
  EyeOff,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  CalendarPlus,
  RefreshCw
} from 'lucide-react';

interface Props {
  rooms: Room[];
  bookings: RoomBooking[];
  selectedBuilding: string;
  onSelectBuilding: (building: string) => void;
  onToggleRoom: (room: Room) => void;
  onBookRoom: (room: Room) => void;
  activeRoomId?: number;
  onSelectRoom?: (roomId: number) => void;
  canModify: boolean;
}

interface FloorRoomBlueprint {
  roomId: number;
  code: string;
  name: string;
  type: 'Classroom' | 'Computer Lab' | 'Reading Hall';
  capacity: number;
  x: number;
  y: number;
  w: number;
  h: number;
}

interface FacilityLayout {
  id: string;
  name: string;
  subtitle: string;
  dimensions: { width: number; height: number };
  corridors: { x: number; y: number; w: number; h: number; label?: string }[];
  entries: { x: number; y: number; label: string }[];
  rooms: FloorRoomBlueprint[];
}

const FACILITY_LAYOUTS: Record<string, FacilityLayout> = {
  'Faculty of Engineering': {
    id: 'Faculty of Engineering',
    name: 'Faculty of Engineering (Block A)',
    subtitle: 'Mechanical, Electrical & Advanced CAD/CAM Laboratories',
    dimensions: { width: 800, height: 460 },
    corridors: [
      { x: 50, y: 190, w: 700, h: 50, label: 'CENTRAL ENGG CORRIDOR & SOLAR BREEZEWAY' },
      { x: 380, y: 70, w: 40, h: 320 }
    ],
    entries: [
      { x: 400, y: 440, label: 'Main South Entrance' },
      { x: 400, y: 30, label: 'North Workshop Courtyard' }
    ],
    rooms: [
      { roomId: 1, code: 'E-204', name: 'Lecture Hall E-204', type: 'Classroom', capacity: 65, x: 60, y: 60, w: 180, h: 120 },
      { roomId: 2, code: 'CAD-01', name: 'Advanced CAD/CAM & Robotics Lab', type: 'Computer Lab', capacity: 40, x: 250, y: 60, w: 220, h: 120 },
      { roomId: 3, code: 'E-202', name: 'Mechatronics & IoT Workshop', type: 'Computer Lab', capacity: 35, x: 480, y: 60, w: 160, h: 120 },
      { roomId: 4, code: 'E-201', name: 'Faculty Conference & Seminar Room', type: 'Reading Hall', capacity: 25, x: 650, y: 60, w: 100, h: 120 },
      { roomId: 5, code: 'E-101', name: 'Thermodynamics Testing Hall', type: 'Classroom', capacity: 50, x: 60, y: 250, w: 180, h: 130 },
      { roomId: 6, code: 'E-102', name: 'Electrical Drives & EV Innovation Lab', type: 'Computer Lab', capacity: 45, x: 250, y: 250, w: 180, h: 130 },
      { roomId: 7, code: 'E-103', name: 'Student Capstone Project Studio', type: 'Reading Hall', capacity: 30, x: 440, y: 250, w: 170, h: 130 },
      { roomId: 8, code: 'E-104', name: 'Rapid Prototyping & 3D Print Cell', type: 'Computer Lab', capacity: 20, x: 620, y: 250, w: 130, h: 130 }
    ]
  },
  'Faculty of Science': {
    id: 'Faculty of Science',
    name: 'Faculty of Science Complex',
    subtitle: 'Physics, Chemistry & Mathematics Laboratories',
    dimensions: { width: 800, height: 460 },
    corridors: [
      { x: 60, y: 200, w: 680, h: 45, label: 'SCIENCE QUADRANGLE & ARCHWAY' },
      { x: 370, y: 80, w: 50, h: 300 }
    ],
    entries: [
      { x: 395, y: 440, label: 'Botanical Garden Portico' },
      { x: 395, y: 35, label: 'Science Walkway' }
    ],
    rooms: [
      { roomId: 9, code: 'S-102', name: 'Quantum Physics Room S-102', type: 'Classroom', capacity: 45, x: 70, y: 70, w: 200, h: 120 },
      { roomId: 10, code: 'S-OPT', name: 'Spectroscopy & Optics Research Lab', type: 'Classroom', capacity: 30, x: 280, y: 70, w: 210, h: 120 },
      { roomId: 11, code: 'S-104', name: 'Condensed Matter Computing Lab', type: 'Computer Lab', capacity: 35, x: 500, y: 70, w: 240, h: 120 },
      { roomId: 12, code: 'S-CHEM1', name: 'Organic Chemistry Analytical Lab', type: 'Classroom', capacity: 40, x: 70, y: 260, w: 210, h: 125 },
      { roomId: 13, code: 'S-MATH', name: 'Applied Mathematics & Statistics Lab', type: 'Computer Lab', capacity: 30, x: 290, y: 260, w: 220, h: 125 },
      { roomId: 14, code: 'S-BIO', name: 'Bio-Science & Botany Observation Lab', type: 'Reading Hall', capacity: 25, x: 520, y: 260, w: 220, h: 125 }
    ]
  },
  'Central Library': {
    id: 'Central Library',
    name: 'DEI Central Library & Research Commons',
    subtitle: 'Silent Reading Wings, Digital Archives & Scholar Carrels',
    dimensions: { width: 800, height: 460 },
    corridors: [
      { x: 270, y: 60, w: 260, h: 340, label: 'ATRIUM & DIGITAL ARCHIVE DESK' }
    ],
    entries: [
      { x: 400, y: 440, label: 'Main Library Entry' }
    ],
    rooms: [
      { roomId: 15, code: 'LIB-SR', name: 'Quiet Study Hall - 1st Floor', type: 'Reading Hall', capacity: 120, x: 60, y: 60, w: 200, h: 340 },
      { roomId: 16, code: 'LIB-RES', name: 'Scholars Research & Thesis Carrels', type: 'Reading Hall', capacity: 30, x: 540, y: 60, w: 200, h: 160 },
      { roomId: 17, code: 'LIB-E', name: 'E-Library & Digital Database Terminal', type: 'Computer Lab', capacity: 45, x: 540, y: 230, w: 200, h: 170 }
    ]
  },
  'Multimedia Lab': {
    id: 'Multimedia Lab',
    name: 'Multimedia & Digital Arts Center',
    subtitle: 'VR Suites, Sound Engineering, UI/UX Studio',
    dimensions: { width: 800, height: 460 },
    corridors: [
      { x: 70, y: 195, w: 660, h: 50, label: 'CREATIVE GALLERY & DISPLAY CORRIDOR' }
    ],
    entries: [
      { x: 400, y: 435, label: 'Design Wing Foyer' }
    ],
    rooms: [
      { roomId: 18, code: 'M-01', name: 'Creative UI/UX & VR Suite M-01', type: 'Computer Lab', capacity: 32, x: 70, y: 65, w: 220, h: 120 },
      { roomId: 19, code: 'M-02', name: 'Sound Engineering & Foley Suite', type: 'Computer Lab', capacity: 15, x: 300, y: 65, w: 200, h: 120 },
      { roomId: 20, code: 'M-03', name: 'Digital Animation & Render Farm', type: 'Computer Lab', capacity: 25, x: 510, y: 65, w: 220, h: 120 },
      { roomId: 21, code: 'M-04', name: 'Design Thinking Ideation Lounge', type: 'Reading Hall', capacity: 40, x: 70, y: 255, w: 320, h: 130 },
      { roomId: 22, code: 'M-05', name: 'Video Production & Chroma Studio', type: 'Classroom', capacity: 20, x: 400, y: 255, w: 330, h: 130 }
    ]
  },
  'Seminar Hall Complex': {
    id: 'Seminar Hall Complex',
    name: 'Seminar Hall & Convocation Complex',
    subtitle: 'Dayal Hall Auditorium & Executive Conference Suites',
    dimensions: { width: 800, height: 460 },
    corridors: [
      { x: 80, y: 350, w: 640, h: 40, label: 'CONVOCATION CONCOURSE & FOYER' }
    ],
    entries: [
      { x: 400, y: 435, label: 'Portico Entrance' }
    ],
    rooms: [
      { roomId: 23, code: 'AUD-01', name: 'Main Auditorium (Dayal Hall)', type: 'Classroom', capacity: 250, x: 80, y: 60, w: 420, h: 280 },
      { roomId: 24, code: 'CONF-A', name: 'Executive Syndicate Room A', type: 'Reading Hall', capacity: 30, x: 510, y: 60, w: 210, h: 135 },
      { roomId: 25, code: 'CONF-B', name: 'Dean Advisory Board Room', type: 'Reading Hall', capacity: 25, x: 510, y: 205, w: 210, h: 135 }
    ]
  },
  'DEI Canteen & Campus Hub': {
    id: 'DEI Canteen & Campus Hub',
    name: 'DEI Canteen & Solar Pavilion Hub',
    subtitle: 'Collaborative Tables, Solar Pavilion & Student Gazebos',
    dimensions: { width: 800, height: 460 },
    corridors: [
      { x: 70, y: 190, w: 660, h: 60, label: 'SHADED PROMENADE & SOLAR CANOPY' }
    ],
    entries: [
      { x: 400, y: 435, label: 'Lawn Gateway' }
    ],
    rooms: [
      { roomId: 26, code: 'SOL-01', name: 'Solar Pavilion Study Kiosk', type: 'Reading Hall', capacity: 50, x: 70, y: 60, w: 260, h: 120 },
      { roomId: 27, code: 'ECO-01', name: 'Organic Garden Refreshment Deck', type: 'Reading Hall', capacity: 60, x: 340, y: 60, w: 390, h: 120 },
      { roomId: 28, code: 'DISC-01', name: 'Peer Discussion Pergola A', type: 'Reading Hall', capacity: 25, x: 70, y: 260, w: 320, h: 130 },
      { roomId: 29, code: 'DISC-02', name: 'Student Innovation Gazebo B', type: 'Reading Hall', capacity: 25, x: 400, y: 260, w: 330, h: 130 }
    ]
  }
};

export const CampusFloorPlan: React.FC<Props> = ({
  rooms,
  bookings,
  selectedBuilding,
  onSelectBuilding,
  onToggleRoom,
  onBookRoom,
  activeRoomId,
  onSelectRoom,
  canModify
}) => {
  const [hoveredRoom, setHoveredRoom] = useState<Room | null>(null);
  const [minCapacity, setMinCapacity] = useState<number>(0);
  const [filterMode, setFilterMode] = useState<'dim' | 'hide'>('dim');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  const handleZoomIn = () => setZoomLevel(prev => Math.min(2.0, +(prev + 0.25).toFixed(2)));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(0.75, +(prev - 0.25).toFixed(2)));
  const handleResetZoom = () => setZoomLevel(1);

  const validBuildingKey = FACILITY_LAYOUTS[selectedBuilding]
    ? selectedBuilding
    : 'Faculty of Engineering';

  const layout = FACILITY_LAYOUTS[validBuildingKey];

  // Match 1:1 against real Firestore/state rooms array
  const getLiveRoom = (bp: FloorRoomBlueprint): Room => {
    const found = rooms.find(r => r.roomId === bp.roomId);
    if (found) return found;
    return {
      docId: `room-${bp.roomId}`,
      roomId: bp.roomId,
      code: bp.code,
      buildingName: validBuildingKey,
      roomName: bp.name,
      roomType: bp.type,
      capacity: bp.capacity,
      status: 'Available',
      currentActivity: 'Open for Study',
      updatedBy: 'Campus Schedule',
      updatedByUid: 'system',
      visibility: 'campus',
      updatedAtText: 'Synced'
    };
  };

  const facilityLiveRooms = layout.rooms.map(getLiveRoom);
  const availCount = facilityLiveRooms.filter(r => r.status === 'Available').length;
  const occCount = facilityLiveRooms.length - availCount;
  const totalCapacity = facilityLiveRooms.reduce((acc, r) => acc + r.capacity, 0);
  const matchingCount = facilityLiveRooms.filter(r => r.capacity >= minCapacity).length;

  const selectedLiveRoom = facilityLiveRooms.find(r => r.roomId === activeRoomId) || facilityLiveRooms[0];
  const selectedBookingsCount = bookings.filter(
    b => b.roomId === selectedLiveRoom.roomId && b.status === 'Confirmed'
  ).length;

  return (
    <div className="campus-floor-plan-container bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transition-colors">
      {/* Header */}
      <div className="p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span className="font-semibold text-blue-700 dark:text-cyan-400 flex items-center gap-1">
              <Layers className="w-3.5 h-3.5" />
              Interactive Blueprint
            </span>
            <span aria-hidden="true">·</span>
            <span>Click any room to inspect, toggle, or book a slot</span>
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-lg font-heading">{layout.name}</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{layout.subtitle}</p>
        </div>

        {/* Building Switcher */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full scrollbar-thin">
          {Object.keys(FACILITY_LAYOUTS).map(bName => {
            const isSelected = bName === validBuildingKey;
            return (
              <button
                key={bName}
                onClick={() => onSelectBuilding(bName)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                  isSelected
                    ? 'bg-blue-700 text-white'
                    : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 dark:hover:bg-slate-700'
                }`}
              >
                {bName.replace('Faculty of ', '')}
              </button>
            );
          })}
        </div>
      </div>

      {/* Metrics Strip */}
      <div className="px-5 py-3 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-4 font-medium text-slate-600 dark:text-slate-400">
          <span>
            Available: <strong className="text-emerald-600 dark:text-emerald-400 font-mono tabular-nums">{availCount}</strong>
          </span>
          <span className="inline-flex items-center gap-1.5">
            {occCount > 0 && (
              <span className="relative flex h-2 w-2" aria-hidden="true">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-600" />
              </span>
            )}
            <span>
              Occupied: <strong className="text-rose-600 dark:text-rose-400 font-mono tabular-nums">{occCount}</strong>
            </span>
          </span>
          <span className="flex items-center gap-1">
            <Users className="w-3.5 h-3.5" />
            Seats: <strong className="text-slate-800 dark:text-slate-200 font-mono tabular-nums">{totalCapacity}</strong>
          </span>
        </div>

        {/* Capacity Slider Bar */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-3.5 h-3.5 text-blue-700 dark:text-cyan-400" />
            <span className="font-semibold text-slate-700 dark:text-slate-300">Min Seats:</span>
            <input
              type="range"
              min="0"
              max="250"
              step="5"
              value={minCapacity}
              onChange={(e) => setMinCapacity(Number(e.target.value))}
              className="w-28 sm:w-36 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-700"
              aria-label="Filter by Capacity"
            />
            <span className="font-mono font-bold text-slate-800 dark:text-slate-200 tabular-nums w-16">
              {minCapacity === 0 ? 'All' : `≥ ${minCapacity}`}
            </span>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg">
            <button
              onClick={() => setFilterMode('dim')}
              className={`px-2 py-1 rounded-md text-[11px] font-medium flex items-center gap-1 transition-colors ${
                filterMode === 'dim'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Eye className="w-3 h-3" />
              <span>Dim</span>
            </button>
            <button
              onClick={() => setFilterMode('hide')}
              className={`px-2 py-1 rounded-md text-[11px] font-medium flex items-center gap-1 transition-colors ${
                filterMode === 'hide'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <EyeOff className="w-3 h-3" />
              <span>Hide</span>
            </button>
          </div>

          {minCapacity > 0 && (
            <span className="text-[11px] font-mono text-blue-700 dark:text-cyan-400">
              {matchingCount}/{facilityLiveRooms.length} match
            </span>
          )}
        </div>
      </div>

      {/* SVG Map Canvas */}
      <div className="p-4 sm:p-5 bg-slate-50/50 dark:bg-slate-950/50 relative">
        <div className="w-full bg-white dark:bg-slate-900 rounded-xl p-3 sm:p-4 border border-slate-200/80 dark:border-slate-800 relative overflow-hidden">
          {/* Zoom Controls */}
          <div className="absolute bottom-3 right-3 z-20 flex items-center gap-1 bg-white/95 dark:bg-slate-800/95 backdrop-blur-md px-2 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-md text-xs">
            <button
              onClick={handleZoomOut}
              disabled={zoomLevel <= 0.75}
              className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-35"
              title="Zoom Out"
              aria-label="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-1.5 font-mono text-[11px] font-bold text-slate-700 dark:text-slate-200 min-w-[38px] text-center tabular-nums">
              {Math.round(zoomLevel * 100)}%
            </span>
            <button
              onClick={handleZoomIn}
              disabled={zoomLevel >= 2.0}
              className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-35"
              title="Zoom In"
              aria-label="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            {zoomLevel !== 1 && (
              <button
                onClick={handleResetZoom}
                className="p-1.5 rounded-lg text-blue-700 dark:text-cyan-400 hover:bg-blue-50 dark:hover:bg-blue-950/60"
                title="Reset Zoom"
                aria-label="Reset Zoom"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="overflow-auto max-w-full rounded-lg scrollbar-thin">
            <div className="flex justify-center" style={{ minWidth: `${Math.round(620 * zoomLevel)}px` }}>
              <svg
                viewBox={`0 0 ${layout.dimensions.width} ${layout.dimensions.height}`}
                className="h-auto select-none transition-all duration-200"
                style={{
                  width: `${100 * zoomLevel}%`,
                  maxWidth: zoomLevel <= 1 ? '100%' : 'none'
                }}
              >
                <defs>
                  <pattern id="gridBlueprint" width="20" height="20" patternUnits="userSpaceOnUse">
                    <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#f1f5f9" strokeWidth="1" className="dark:stroke-slate-800" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#gridBlueprint)" rx="8" />
                <rect
                  x="30"
                  y="20"
                  width={layout.dimensions.width - 60}
                  height={layout.dimensions.height - 40}
                  fill="none"
                  stroke="#cbd5e1"
                  strokeWidth="2.5"
                  strokeDasharray="6 3"
                  rx="12"
                  className="dark:stroke-slate-700"
                />

                {layout.corridors.map((c, i) => (
                  <g key={`corridor-${i}`}>
                    <rect
                      x={c.x}
                      y={c.y}
                      width={c.w}
                      height={c.h}
                      fill="#f8fafc"
                      stroke="#e2e8f0"
                      strokeWidth="1.5"
                      rx="4"
                      className="dark:fill-slate-800/80 dark:stroke-slate-700"
                    />
                    {c.label && (
                      <text
                        x={c.x + c.w / 2}
                        y={c.y + c.h / 2 + 4}
                        textAnchor="middle"
                        fill="#94a3b8"
                        fontSize="10"
                        fontWeight="600"
                        letterSpacing="1.5"
                      >
                        {c.label}
                      </text>
                    )}
                  </g>
                ))}

                {layout.entries.map((e, i) => (
                  <g key={`entry-${i}`}>
                    <circle cx={e.x} cy={e.y} r="4.5" fill="#059669" />
                    <text
                      x={e.x}
                      y={e.y > 200 ? e.y - 10 : e.y + 15}
                      textAnchor="middle"
                      fill="#059669"
                      fontSize="10"
                      fontWeight="bold"
                    >
                      {e.label}
                    </text>
                  </g>
                ))}

                {layout.rooms.map((bp) => {
                  const live = getLiveRoom(bp);
                  const isAvail = live.status === 'Available';
                  const isHovered = hoveredRoom?.roomId === live.roomId;
                  const isSelected = selectedLiveRoom.roomId === live.roomId;
                  const isCapacityMatch = live.capacity >= minCapacity;

                  if (!isCapacityMatch && filterMode === 'hide') {
                    return null;
                  }

                  const isDimmed = !isCapacityMatch && filterMode === 'dim';
                  const fillColor = isAvail
                    ? isHovered ? '#d1fae5' : '#ecfdf5'
                    : isHovered ? '#fee2e2' : '#fff1f2';
                  const strokeColor = isSelected ? '#0f172a' : isAvail ? '#10b981' : '#f43f5e';
                  const roomBookingsCount = bookings.filter(
                    b => b.roomId === live.roomId && b.status === 'Confirmed'
                  ).length;

                  return (
                    <g
                      key={bp.roomId}
                      className={`transition-all ${isDimmed ? 'opacity-25 grayscale cursor-not-allowed' : 'cursor-pointer'}`}
                      onMouseEnter={() => setHoveredRoom(live)}
                      onMouseLeave={() => setHoveredRoom(null)}
                      onClick={() => {
                        if (isDimmed) return;
                        if (onSelectRoom) onSelectRoom(live.roomId);
                      }}
                    >
                      <rect
                        x={bp.x}
                        y={bp.y}
                        width={bp.w}
                        height={bp.h}
                        fill={fillColor}
                        stroke={isDimmed ? '#94a3b8' : strokeColor}
                        strokeWidth={isSelected ? 3 : isHovered ? 2.2 : 1.5}
                        strokeDasharray={isDimmed ? '5 3' : undefined}
                        rx="8"
                      />

                      {!isAvail && !isDimmed && (
                        <>
                          {/* Subtle pulsing border aura for busy/occupied rooms */}
                          <rect
                            x={bp.x - 1.5}
                            y={bp.y - 1.5}
                            width={bp.w + 3}
                            height={bp.h + 3}
                            fill="none"
                            stroke="#f43f5e"
                            strokeWidth="2"
                            rx="9"
                            className="animate-occupied-pulse pointer-events-none"
                          />
                          {/* Subtle pulsing occupied room pin */}
                          <g
                            transform={`translate(${bp.x + bp.w - 16}, ${bp.y + 17})`}
                            className="pointer-events-none"
                          >
                            <circle
                              cx="0"
                              cy="0"
                              r="7"
                              fill="#f43f5e"
                              opacity="0.35"
                              className="animate-ping-small"
                            />
                            <circle
                              cx="0"
                              cy="0"
                              r="4"
                              fill="#e11d48"
                              stroke="#ffffff"
                              strokeWidth="1.5"
                            />
                          </g>
                        </>
                      )}

                      <rect
                        x={bp.x + 8}
                        y={bp.y + 8}
                        width={46}
                        height={18}
                        fill={isAvail ? '#a7f3d0' : '#fecdd3'}
                        rx="4"
                      />
                      <text
                        x={bp.x + 31}
                        y={bp.y + 20.5}
                        textAnchor="middle"
                        fill={isAvail ? '#065f46' : '#881337'}
                        fontSize="9"
                        fontWeight="bold"
                      >
                        {live.code}
                      </text>

                      {roomBookingsCount > 0 && (
                        <text
                          x={!isAvail && !isDimmed ? bp.x + bp.w - 28 : bp.x + bp.w - 10}
                          y={bp.y + 20}
                          textAnchor="end"
                          fill="#0369a1"
                          fontSize="9"
                          fontWeight="700"
                        >
                          {roomBookingsCount} slot{roomBookingsCount > 1 ? 's' : ''}
                        </text>
                      )}

                      <text
                        x={bp.x + 10}
                        y={bp.y + 44}
                        fill="#0f172a"
                        fontSize={bp.w > 190 ? '11.5' : '10.5'}
                        fontWeight="700"
                      >
                        {live.roomName.length > 23 ? live.roomName.substring(0, 22) + '...' : live.roomName}
                      </text>

                      <text
                        x={bp.x + 10}
                        y={bp.y + 60}
                        fill={isCapacityMatch && minCapacity > 0 ? '#059669' : '#64748b'}
                        fontSize="10"
                        fontWeight={isCapacityMatch && minCapacity > 0 ? '700' : 'normal'}
                      >
                        {live.roomType} · {live.capacity} seats
                      </text>

                      <rect
                        x={bp.x + 10}
                        y={bp.y + bp.h - 28}
                        width={bp.w - 20}
                        height="19"
                        fill={isDimmed ? '#94a3b8' : isAvail ? '#059669' : '#e11d48'}
                        rx="4"
                      />
                      <text
                        x={bp.x + bp.w / 2}
                        y={bp.y + bp.h - 15}
                        textAnchor="middle"
                        fill="#ffffff"
                        fontSize="9.5"
                        fontWeight="bold"
                      >
                        {isDimmed ? `< ${minCapacity} SEATS` : live.status.toUpperCase()}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Selected Room Inspector & Direct Actions Bar */}
      <div className="p-4 sm:px-5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-0.5 min-w-0">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{selectedLiveRoom.code}</span>
            <span aria-hidden="true">·</span>
            <span className={selectedLiveRoom.status === 'Available' ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : 'text-rose-600 dark:text-rose-400 font-semibold'}>
              {selectedLiveRoom.status}
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{selectedLiveRoom.capacity} seats</span>
            <span aria-hidden="true">·</span>
            <span>{selectedBookingsCount} confirmed booking{selectedBookingsCount === 1 ? '' : 's'}</span>
          </div>
          <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
            {selectedLiveRoom.roomName}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
            {selectedLiveRoom.currentActivity}
          </div>
        </div>

        <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2 shrink-0 w-full sm:w-auto">
          <button
            onClick={() => onBookRoom(selectedLiveRoom)}
            className="min-h-[44px] sm:min-h-0 px-3 sm:px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <CalendarPlus className="w-3.5 h-3.5" />
            <span>Book Slot</span>
          </button>
          <button
            onClick={() => onToggleRoom(selectedLiveRoom)}
            className={`min-h-[44px] sm:min-h-0 px-3 sm:px-4 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition-colors whitespace-nowrap ${
              canModify
                ? 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                : 'bg-slate-50 dark:bg-slate-800/40 text-slate-400 border-slate-200 dark:border-slate-800'
            }`}
            title={canModify ? 'Toggle room live status in Firestore' : 'Sign in as Student, Faculty, or Admin to update live status'}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{selectedLiveRoom.status === 'Available' ? 'Mark Occupied' : 'Mark Available'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
