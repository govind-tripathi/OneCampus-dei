import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  User as FirebaseAuthUser
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  writeBatch,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import {
  DoorOpen,
  Users,
  Coins,
  Award,
  Clock,
  Plus,
  Camera,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Compass,
  Check,
  X,
  Flame,
  SlidersHorizontal,
  Map as MapIcon,
  LayoutGrid,
  Sun,
  Moon,
  TrendingUp,
  CalendarPlus,
  LogOut,
  LogIn,
  ShieldCheck,
  Trash2,
  Database,
  Leaf,
  Info,
  Star,
  CalendarCheck,
  MapPin
} from 'lucide-react';
import {
  PublicProfile,
  Room,
  RoomBooking,
  Skill,
  SkillTransaction,
  EcoReport,
  CampusNotification,
  ToastMessage,
  UserRole
} from './types';
import {
  INITIAL_PROFILES,
  INITIAL_ROOMS,
  INITIAL_BOOKINGS,
  INITIAL_SKILLS,
  INITIAL_REPORTS,
  INITIAL_NOTIFICATIONS,
  DEI_TRIVIA
} from './initialData';
import {
  db,
  auth,
  googleProvider,
  ADMIN_EMAIL,
  OperationType,
  handleFirestoreError,
  testConnection,
  seedCampusBaselineToFirestore
} from './firebase';
import { BrandLogo } from './components/BrandLogo';
import { LandingPortal } from './components/LandingPortal';
import { RoomBookingModal } from './components/RoomBookingModal';
import { ReportIssueModal } from './components/ReportIssueModal';
import { ResolveReportModal } from './components/ResolveReportModal';
import { AboutContactView } from './components/AboutContactView';
import { CampusFloorPlan } from './CampusFloorPlan';
import { GlobalSearchBar } from './GlobalSearchBar';
import { FacultyTrends } from './FacultyTrends';
import { NotificationCenter } from './NotificationCenter';
import { EcoPulseMap } from './EcoPulseMap';
import heroBannerImg from './assets/images/hero_campus_banner_1794583007730.jpg';

function formatFirestoreTime(ts: unknown): string {
  if (!ts) return 'Just now';
  if (ts instanceof Timestamp) {
    return ts.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  return 'Synced';
}

export default function App() {
  // Navigation & Landing Gate (restores EcoPulse report modal if mobile browser reloaded returning from camera)
  const [showLanding, setShowLanding] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('onecampus_reopen_report') !== '1';
    } catch {
      return true;
    }
  });
  const [activeTab, setActiveTab] = useState<'smartspace' | 'peerlearn' | 'ecopulse' | 'about'>(() => {
    try {
      return sessionStorage.getItem('onecampus_reopen_report') === '1' ? 'ecopulse' : 'smartspace';
    } catch {
      return 'smartspace';
    }
  });

  // Auth & Profile State
  const [authUser, setAuthUser] = useState<FirebaseAuthUser | null>(null);
  const [authReady, setAuthReady] = useState<boolean>(false);
  const [isSigningIn, setIsSigningIn] = useState<boolean>(false);
  const roleIntentRef = React.useRef<UserRole>('student');
  const [showOnboardingModal, setShowOnboardingModal] = useState<boolean>(false);
  const [onboardName, setOnboardName] = useState<string>('');
  const [onboardRollNo, setOnboardRollNo] = useState<string>('');
  const [onboardDept, setOnboardDept] = useState<string>('Faculty of Engineering');
  const [onboardRole, setOnboardRole] = useState<'student' | 'faculty'>('student');
  const [isAdminVerified, setIsAdminVerified] = useState<boolean>(false);
  const [dbConnected, setDbConnected] = useState<boolean>(true);

  // Live Firestore Collections (empty while cloud has not been seeded yet)
  const [fsProfiles, setFsProfiles] = useState<PublicProfile[]>([]);
  const [fsRooms, setFsRooms] = useState<Room[]>([]);
  const [fsBookings, setFsBookings] = useState<RoomBooking[]>([]);
  const [fsSkills, setFsSkills] = useState<Skill[]>([]);
  const [fsTransactions, setFsTransactions] = useState<SkillTransaction[]>([]);
  const [fsReports, setFsReports] = useState<EcoReport[]>([]);
  const [fsNotifications, setFsNotifications] = useState<CampusNotification[]>([]);
  const [roomsLoaded, setRoomsLoaded] = useState<boolean>(false);

  // Effective Lists (Use live Firestore once seeded; fall back cleanly to baseline demo dataset prior to first Admin seed)
  const isCloudSeeded = fsRooms.length > 0;
  const profiles = fsProfiles.length > 0 ? fsProfiles : INITIAL_PROFILES;
  const rooms = isCloudSeeded ? fsRooms : INITIAL_ROOMS;
  const bookings = isCloudSeeded ? fsBookings : INITIAL_BOOKINGS;
  const skills = fsSkills.length > 0 || isCloudSeeded ? fsSkills : INITIAL_SKILLS;
  const reports = fsReports.length > 0 || isCloudSeeded ? fsReports : INITIAL_REPORTS;
  const notifications = fsNotifications.length > 0 ? fsNotifications : INITIAL_NOTIFICATIONS;

  // Filters & View Modes
  const [buildingFilter, setBuildingFilter] = useState<string>('all');
  const [roomStatusFilter, setRoomStatusFilter] = useState<'all' | 'Available' | 'Occupied'>('all');
  const [smartSpaceView, setSmartSpaceView] = useState<'both' | 'map' | 'cards' | 'trends' | 'my_bookings'>('both');
  const [ecoView, setEcoView] = useState<'both' | 'map' | 'feed'>('both');
  const [selectedMapBuilding, setSelectedMapBuilding] = useState<string>('Faculty of Engineering');
  const [highlightedRoomId, setHighlightedRoomId] = useState<number | undefined>(undefined);
  const [globalSearchQuery, setGlobalSearchQuery] = useState<string>('');
  const [skillCategoryFilter, setSkillCategoryFilter] = useState<string>('all');
  const [peerSubTab, setPeerSubTab] = useState<'feed' | 'my_sessions'>('feed');
  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState<boolean>(false);

  // Dark Mode
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem('onecampus_theme') === 'dark';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      try {
        localStorage.setItem('onecampus_theme', 'dark');
      } catch {
        // ignore
      }
    } else {
      document.documentElement.classList.remove('dark');
      try {
        localStorage.setItem('onecampus_theme', 'light');
      } catch {
        // ignore
      }
    }
  }, [isDarkMode]);

  // Listen for Google Maps Platform quota/auth failure fallback event
  useEffect(() => {
    const onQuotaExceeded = () => setGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
  }, []);

  // Modals & Forms
  const [bookingRoomTarget, setBookingRoomTarget] = useState<Room | null>(null);
  const [resolveReportTarget, setResolveReportTarget] = useState<EcoReport | null>(null);
  const [sessionRatings, setSessionRatings] = useState<Record<string, number>>({});
  const [sessionReviews, setSessionReviews] = useState<Record<string, string>>({});
  const [isOfferSkillModalOpen, setIsOfferSkillModalOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('onecampus_reopen_report') === '1';
    } catch {
      return false;
    }
  });
  const [isSeeding, setIsSeeding] = useState<boolean>(false);

  useEffect(() => {
    try {
      if (isReportModalOpen) {
        sessionStorage.setItem('onecampus_reopen_report', '1');
      } else {
        sessionStorage.removeItem('onecampus_reopen_report');
      }
    } catch {
      // ignore
    }
  }, [isReportModalOpen]);

  const [newSkillTitle, setNewSkillTitle] = useState('');
  const [newSkillCat, setNewSkillCat] = useState<'Coding' | 'Academics' | 'Design' | 'Music/Art'>('Coding');
  const [newSkillDesc, setNewSkillDesc] = useState('');
  const [newSkillAvail, setNewSkillAvail] = useState('');

  // Heritage Quiz
  const [triviaIdx, setTriviaIdx] = useState(0);
  const [showTriviaAns, setShowTriviaAns] = useState(false);
  const [triviaEarned, setTriviaEarned] = useState(false);

  // Clock & Toasts
  const [timeStr, setTimeStr] = useState<string>('');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (text: string, type: 'success' | 'warning' | 'danger' | 'info' = 'success') => {
    const id = Date.now().toString() + Math.random().toString();
    setToasts(prev => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4200);
  };

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  // 1. Test Firebase Connection on Boot
  useEffect(() => {
    testConnection().then(ok => setDbConnected(ok));
  }, []);

  // 2. Auth Listener + Admin Lock Verification + Onboarding Check
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setAuthUser(user);
      setAuthReady(true);

      if (!user) {
        setIsAdminVerified(false);
        setShowOnboardingModal(false);
        return;
      }

      const isAdminEmail = user.emailVerified && user.email === ADMIN_EMAIL;
      setIsAdminVerified(isAdminEmail);

      // Ensure Admin registry doc exists for verified admin email
      if (isAdminEmail) {
        try {
          const adminDocRef = doc(db, 'admins', user.uid);
          const adminSnap = await getDoc(adminDocRef);
          if (!adminSnap.exists()) {
            await setDoc(adminDocRef, {
              uid: user.uid,
              grantedBy: user.email,
              createdAt: serverTimestamp()
            });
          }
        } catch (err) {
          console.error('Admin doc bootstrap check error:', err);
        }
      }

      // Ensure Private Email PII doc exists
      try {
        await setDoc(
          doc(db, 'userSecrets', user.uid),
          {
            uid: user.uid,
            email: user.email || '',
            updatedAt: serverTimestamp()
          },
          { merge: true }
        );
      } catch (err) {
        console.error('User secret sync error:', err);
      }

      // Check PublicProfile existence
      try {
        const profileRef = doc(db, 'publicProfiles', user.uid);
        const profileSnap = await getDoc(profileRef);
        if (!profileSnap.exists()) {
          if (isAdminEmail) {
            const rawName = (user.displayName || '').trim();
            const safeAdminName = rawName.length >= 2 ? rawName.slice(0, 80) : 'Portal Administrator';
            // Auto-provision Admin public profile immediately
            await setDoc(profileRef, {
              uid: user.uid,
              fullName: safeAdminName,
              rollNo: 'DEI-ADMIN-01',
              department: 'Portal Governance',
              role: 'admin',
              skillCredits: 5,
              greenPoints: 10,
              avatarSeed: user.uid.slice(0, 8),
              visibility: 'campus',
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            });
            setShowLanding(false);
          } else {
            // Pre-fill profile modal for Student / Faculty
            setOnboardName(user.displayName || 'DEI Campus Member');
            setOnboardRole(roleIntentRef.current === 'faculty' ? 'faculty' : 'student');
            setShowOnboardingModal(true);
            setShowLanding(false);
          }
        } else {
          setShowLanding(false);
        }
      } catch (err) {
        console.error('Profile fetch/provision error:', err);
      }
    });

    return () => unsub();
  }, []);

  // 3. Real-time Firestore Subscriptions (Strict Query Enforcer compliant)
  useEffect(() => {
    const qRooms = query(collection(db, 'rooms'), where('visibility', '==', 'campus'));
    const unsubRooms = onSnapshot(
      qRooms,
      (snap) => {
        const list: Room[] = snap.docs
          .map(d => {
            const data = d.data();
            return {
              docId: d.id,
              roomId: data.roomId,
              code: data.code,
              buildingName: data.buildingName,
              roomName: data.roomName,
              roomType: data.roomType,
              capacity: data.capacity,
              status: data.status,
              currentActivity: data.currentActivity,
              updatedBy: data.updatedBy,
              updatedByUid: data.updatedByUid,
              visibility: 'campus',
              updatedAtText: formatFirestoreTime(data.updatedAt)
            } as Room;
          })
          .sort((a, b) => a.roomId - b.roomId);
        setFsRooms(list);
        setRoomsLoaded(true);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'rooms');
      }
    );

    const qBookings = query(collection(db, 'roomBookings'), where('visibility', '==', 'campus'));
    const unsubBookings = onSnapshot(
      qBookings,
      (snap) => {
        const list: RoomBooking[] = snap.docs.map(d => {
          const data = d.data();
          return {
            id: d.id,
            roomId: data.roomId,
            roomName: data.roomName,
            buildingName: data.buildingName,
            date: data.date,
            startTime: data.startTime,
            endTime: data.endTime,
            purpose: data.purpose,
            bookedByUid: data.bookedByUid,
            bookedByName: data.bookedByName,
            bookedByRole: data.bookedByRole,
            status: data.status,
            visibility: 'campus',
            createdAtText: formatFirestoreTime(data.createdAt)
          };
        });
        setFsBookings(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'roomBookings');
      }
    );

    const qSkills = query(collection(db, 'skills'), where('visibility', '==', 'campus'));
    const unsubSkills = onSnapshot(
      qSkills,
      (snap) => {
        const list: Skill[] = snap.docs.map(d => {
          const data = d.data();
          return {
            id: d.id,
            userUid: data.userUid,
            userName: data.userName,
            userDepartment: data.userDepartment,
            userRollNo: data.userRollNo,
            skillTitle: data.skillTitle,
            category: data.category,
            description: data.description,
            availabilityTime: data.availabilityTime,
            visibility: 'campus',
            createdAtText: formatFirestoreTime(data.createdAt)
          };
        });
        setFsSkills(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'skills');
      }
    );

    const qReports = query(collection(db, 'ecoReports'), where('visibility', '==', 'campus'));
    const unsubReports = onSnapshot(
      qReports,
      (snap) => {
        const list: EcoReport[] = snap.docs.map(d => {
          const data = d.data();
          return {
            id: d.id,
            userUid: data.userUid,
            userName: data.userName,
            userDepartment: data.userDepartment,
            location: data.location,
            issueCategory: data.issueCategory,
            description: data.description,
            imageData: data.imageData,
            afterImageData: data.afterImageData,
            resolutionNote: data.resolutionNote,
            mapX: data.mapX ?? 380,
            mapY: data.mapY ?? 210,
            lat: typeof data.lat === 'number' ? data.lat : undefined,
            lng: typeof data.lng === 'number' ? data.lng : undefined,
            gpsAccuracy: typeof data.gpsAccuracy === 'number' ? data.gpsAccuracy : undefined,
            status: data.status,
            resolvedBy: data.resolvedBy,
            visibility: 'campus',
            createdAtText: formatFirestoreTime(data.createdAt)
          };
        });
        setFsReports(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'ecoReports');
      }
    );

    const qProfiles = query(collection(db, 'publicProfiles'), where('visibility', '==', 'campus'));
    const unsubProfiles = onSnapshot(
      qProfiles,
      (snap) => {
        const list: PublicProfile[] = snap.docs.map(d => d.data() as PublicProfile);
        setFsProfiles(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'publicProfiles');
      }
    );

    const qNotifs = query(collection(db, 'campusNotifications'), where('visibility', '==', 'campus'));
    const unsubNotifs = onSnapshot(
      qNotifs,
      (snap) => {
        const list: CampusNotification[] = snap.docs
          .map(d => {
            const data = d.data();
            return {
              id: d.id,
              type: data.type,
              title: data.title,
              message: data.message,
              actorUid: data.actorUid,
              linkTab: data.linkTab,
              visibility: 'campus' as const,
              timeText: formatFirestoreTime(data.createdAt),
              _ms: data.createdAt instanceof Timestamp ? data.createdAt.toMillis() : 0
            };
          })
          .sort((a, b) => b._ms - a._ms)
          .slice(0, 20)
          .map(({ _ms, ...rest }) => rest);
        setFsNotifications(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'campusNotifications');
      }
    );

    return () => {
      unsubRooms();
      unsubBookings();
      unsubSkills();
      unsubReports();
      unsubProfiles();
      unsubNotifs();
    };
  }, []);

  // Authenticated-only SkillTransactions listener
  useEffect(() => {
    if (!authReady || !authUser) {
      setFsTransactions([]);
      return;
    }

    const qTxns = isAdminVerified
      ? collection(db, 'skillTransactions')
      : query(
          collection(db, 'skillTransactions'),
          where('participantUids', 'array-contains', authUser.uid)
        );

    const unsubTxns = onSnapshot(
      qTxns,
      (snap) => {
        const list: SkillTransaction[] = snap.docs.map(d => {
          const data = d.data();
          return {
            id: d.id,
            skillId: data.skillId,
            skillTitle: data.skillTitle,
            category: data.category,
            learnerUid: data.learnerUid,
            learnerName: data.learnerName,
            mentorUid: data.mentorUid,
            mentorName: data.mentorName,
            participantUids: data.participantUids || [],
            status: data.status,
            rating: typeof data.rating === 'number' ? data.rating : undefined,
            review: typeof data.review === 'string' ? data.review : undefined,
            createdAtText: formatFirestoreTime(data.createdAt)
          };
        });
        setFsTransactions(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'skillTransactions');
      }
    );

    return () => unsubTxns();
  }, [authReady, authUser, isAdminVerified]);

  // Auto-seed cloud baseline once when verified Admin logs into an empty Firestore
  useEffect(() => {
    if (isAdminVerified && authUser && roomsLoaded && fsRooms.length === 0 && !isSeeding) {
      setIsSeeding(true);
      seedCampusBaselineToFirestore(authUser.uid, authUser.displayName || 'Portal Administrator')
        .then(() => {
          addToast('Synced all 29 SmartSpace rooms & starter campus records to live Firestore!', 'success');
        })
        .catch(() => {
          addToast('Could not auto-seed baseline dataset.', 'danger');
        })
        .finally(() => setIsSeeding(false));
    }
  }, [isAdminVerified, authUser, roomsLoaded, fsRooms.length, isSeeding]);

  // Active signed-in user's PublicProfile (or Visitor fallback)
  const currentUserProfile: PublicProfile | null = authUser
    ? fsProfiles.find(p => p.uid === authUser.uid) || {
        uid: authUser.uid,
        fullName: authUser.displayName || 'Campus Member',
        rollNo: 'DEI-MEMBER',
        department: 'Dayalbagh Educational Institute',
        role: isAdminVerified ? 'admin' : 'student',
        skillCredits: 5,
        greenPoints: 10,
        avatarSeed: authUser.uid.slice(0, 8),
        visibility: 'campus'
      }
    : null;

  const isAdmin = Boolean(authUser && isAdminVerified);

  // Push Live Campus Notification Event
  const pushCampusNotification = async (
    type: CampusNotification['type'],
    title: string,
    message: string,
    linkTab: CampusNotification['linkTab']
  ) => {
    if (!authUser) return;
    try {
      await addDoc(collection(db, 'campusNotifications'), {
        type,
        title: title.slice(0, 120),
        message: message.slice(0, 280),
        actorUid: authUser.uid,
        linkTab,
        visibility: 'campus',
        createdAt: serverTimestamp()
      });
    } catch (err) {
      console.error('Notification push failed:', err);
    }
  };

  // Sign-In Handlers
  const handleRoleSignIn = async (intent: UserRole) => {
    if (isSigningIn) return;
    roleIntentRef.current = intent;
    setIsSigningIn(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      if (intent === 'admin' && !(user.emailVerified && user.email === ADMIN_EMAIL)) {
        addToast(
          `Admin access restricted to ${ADMIN_EMAIL}. Signed in as standard campus member.`,
          'warning'
        );
      } else {
        addToast(`Signed in as ${user.displayName || user.email}`, 'success');
      }
      setShowLanding(false);
    } catch (err) {
      const errCode = (err as { code?: string })?.code;
      if (errCode === 'auth/popup-closed-by-user' || errCode === 'auth/cancelled-popup-request') {
        addToast('Google sign-in popup was closed before completing. Try again or continue as Visitor.', 'info');
      } else if (errCode === 'auth/popup-blocked') {
        addToast('Browser blocked the Google sign-in popup. Please allow popups for this site and try again.', 'warning');
      } else {
        addToast('Could not complete Google sign-in. Please check your connection and try again.', 'warning');
        console.warn('Google sign-in failed:', errCode || err);
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    setIsReportModalOpen(false);
    await signOut(auth);
    setShowLanding(true);
    addToast('Signed out cleanly. Switched to Visitor landing.', 'info');
  };

  const handleCompleteOnboarding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authUser || !onboardName.trim() || !onboardRollNo.trim() || !onboardDept.trim()) return;
    const assignedRole: UserRole =
      authUser.emailVerified && authUser.email === ADMIN_EMAIL ? 'admin' : onboardRole;

    try {
      await setDoc(doc(db, 'publicProfiles', authUser.uid), {
        uid: authUser.uid,
        fullName: onboardName.trim().slice(0, 80),
        rollNo: onboardRollNo.trim().slice(0, 32),
        department: onboardDept.trim().slice(0, 100),
        role: assignedRole,
        skillCredits: 5,
        greenPoints: 10,
        avatarSeed: authUser.uid.slice(0, 8),
        visibility: 'campus',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      setShowOnboardingModal(false);
      addToast('Campus profile created with 5 Skill Credits & 10 Eco Karma!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `publicProfiles/${authUser.uid}`);
    }
  };

  const requireSignedInAction = (): boolean => {
    if (!authUser) {
      addToast('Visitor mode is read-only. Please sign in with Google to make changes.', 'warning');
      return false;
    }
    if (!isCloudSeeded && !isAdmin) {
      addToast(
        'Cloud rooms are awaiting initial Admin sync. Signed-in Admin can initialize Firestore in 1 click.',
        'warning'
      );
      return false;
    }
    return true;
  };

  // Toggle Room Live Availability
  const handleToggleRoom = async (room: Room) => {
    if (!requireSignedInAction() || !authUser || !currentUserProfile) return;
    const nextStatus = room.status === 'Available' ? 'Occupied' : 'Available';
    const nextActivity =
      nextStatus === 'Available'
        ? 'Free for Self Study / Group Discussion'
        : `Occupied by ${currentUserProfile.fullName} (${currentUserProfile.role})`;

    try {
      await updateDoc(doc(db, 'rooms', room.docId), {
        status: nextStatus,
        currentActivity: nextActivity.slice(0, 220),
        updatedBy: currentUserProfile.fullName,
        updatedByUid: authUser.uid,
        updatedAt: serverTimestamp()
      });
      await pushCampusNotification(
        'room_status',
        `${room.code} marked ${nextStatus}`,
        `${currentUserProfile.fullName} updated ${room.roomName} (${room.buildingName}) to ${nextStatus}.`,
        'smartspace'
      );
      addToast(`${room.roomName} is now ${nextStatus} (Live Synced)`, 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `rooms/${room.docId}`);
    }
  };

  // Room Slot Booking Submission (with live Firestore race-condition clash guard)
  const handleConfirmRoomBooking = async (payload: {
    room: Room;
    date: string;
    startTime: string;
    endTime: string;
    purpose: string;
  }) => {
    if (!authUser || !currentUserProfile) return;
    try {
      const liveSnap = await getDocs(
        query(collection(db, 'roomBookings'), where('visibility', '==', 'campus'))
      );
      const liveClash = liveSnap.docs.find(d => {
        const b = d.data();
        return (
          b.status === 'Confirmed' &&
          b.roomId === payload.room.roomId &&
          b.date === payload.date &&
          payload.startTime < b.endTime &&
          payload.endTime > b.startTime
        );
      });
      if (liveClash) {
        const clashData = liveClash.data();
        addToast(
          `Slot clash detected: ${payload.room.code} is booked ${clashData.startTime}–${clashData.endTime} by ${clashData.bookedByName}. Pick a suggested slot or room.`,
          'danger'
        );
        throw new Error('Room booking clash detected');
      }

      await addDoc(collection(db, 'roomBookings'), {
        roomId: payload.room.roomId,
        roomName: payload.room.roomName,
        buildingName: payload.room.buildingName,
        date: payload.date,
        startTime: payload.startTime,
        endTime: payload.endTime,
        purpose: payload.purpose,
        bookedByUid: authUser.uid,
        bookedByName: currentUserProfile.fullName,
        bookedByRole: currentUserProfile.role,
        status: 'Confirmed',
        visibility: 'campus',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      await pushCampusNotification(
        'room_booking',
        `Slot Booked: ${payload.room.code}`,
        `${currentUserProfile.fullName} reserved ${payload.room.roomName} on ${payload.date} (${payload.startTime}-${payload.endTime}).`,
        'smartspace'
      );
      addToast(`Reserved ${payload.room.roomName} (${payload.startTime}–${payload.endTime})!`, 'success');
    } catch (err) {
      if ((err as Error)?.message === 'Room booking clash detected') {
        throw err;
      }
      handleFirestoreError(err, OperationType.CREATE, 'roomBookings');
    }
  };

  const handleCancelBooking = async (bk: RoomBooking) => {
    if (!authUser) return;
    try {
      await updateDoc(doc(db, 'roomBookings', bk.id), {
        status: 'Cancelled',
        updatedAt: serverTimestamp()
      });
      addToast(`Booking for ${bk.roomName} cancelled.`, 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `roomBookings/${bk.id}`);
    }
  };

  // PeerLearn: Create Skill
  const handleCreateSkill = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!requireSignedInAction() || !authUser || !currentUserProfile) return;
    if (newSkillDesc.trim().length < 10) {
      addToast('Please provide at least 10 characters in description.', 'warning');
      return;
    }
    try {
      await addDoc(collection(db, 'skills'), {
        userUid: authUser.uid,
        userName: currentUserProfile.fullName,
        userDepartment: currentUserProfile.department,
        userRollNo: currentUserProfile.rollNo,
        skillTitle: newSkillTitle.trim(),
        category: newSkillCat,
        description: newSkillDesc.trim(),
        availabilityTime: newSkillAvail.trim(),
        visibility: 'campus',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      await pushCampusNotification(
        'new_skill',
        `New Skill: ${newSkillTitle.trim()}`,
        `${currentUserProfile.fullName} listed a ${newSkillCat} mentoring skill in PeerLearn.`,
        'peerlearn'
      );
      setIsOfferSkillModalOpen(false);
      setNewSkillTitle('');
      setNewSkillDesc('');
      setNewSkillAvail('');
      addToast('Your skill listing is live in PeerLearn!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'skills');
    }
  };

  // PeerLearn: Book Skill
  const handleBookSkill = async (skill: Skill) => {
    if (!requireSignedInAction() || !authUser || !currentUserProfile) return;
    if (skill.userUid === authUser.uid) {
      addToast('You cannot book your own listing.', 'warning');
      return;
    }
    if (currentUserProfile.skillCredits < 1) {
      addToast('Insufficient Skill Credits. Teach a peer session first to earn credits.', 'danger');
      return;
    }
    try {
      await addDoc(collection(db, 'skillTransactions'), {
        skillId: skill.id,
        skillTitle: skill.skillTitle,
        category: skill.category,
        learnerUid: authUser.uid,
        learnerName: currentUserProfile.fullName,
        mentorUid: skill.userUid,
        mentorName: skill.userName,
        participantUids: [authUser.uid, skill.userUid],
        status: 'Requested',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      await pushCampusNotification(
        'peer_request',
        '1-Hr Skill Session Requested',
        `${currentUserProfile.fullName} requested "${skill.skillTitle}" with ${skill.userName}.`,
        'peerlearn'
      );
      addToast(`Session requested with ${skill.userName}! Complete it in 'My Sessions' to transfer 1 credit.`, 'success');
      setPeerSubTab('my_sessions');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'skillTransactions');
    }
  };

  // PeerLearn: Atomic Batch Credit Transfer (with optional 1-5 Star Rating & Review)
  const handleCompleteSession = async (txn: SkillTransaction) => {
    if (!authUser || !currentUserProfile || txn.status === 'Completed') return;
    if (txn.learnerUid !== authUser.uid && !isAdmin) {
      addToast('Only the Learner (or Admin) can confirm session completion and release payment.', 'warning');
      return;
    }

    const learnerProfile = fsProfiles.find(p => p.uid === txn.learnerUid);
    const mentorProfile = fsProfiles.find(p => p.uid === txn.mentorUid);
    if (!learnerProfile || !mentorProfile) {
      addToast('Member profile not found in cloud registry.', 'danger');
      return;
    }
    if (learnerProfile.skillCredits < 1) {
      addToast('Learner has insufficient credits.', 'danger');
      return;
    }

    const rawRating = sessionRatings[txn.id];
    const cleanRating =
      typeof rawRating === 'number' && rawRating >= 1 && rawRating <= 5
        ? Math.round(rawRating)
        : undefined;
    const cleanReview = (sessionReviews[txn.id] || '').trim().slice(0, 300);

    const batch = writeBatch(db);
    batch.update(doc(db, 'skillTransactions', txn.id), {
      status: 'Completed',
      ...(cleanRating ? { rating: cleanRating } : {}),
      ...(cleanReview ? { review: cleanReview } : {}),
      updatedAt: serverTimestamp()
    });
    batch.update(doc(db, 'publicProfiles', txn.learnerUid), {
      skillCredits: learnerProfile.skillCredits - 1,
      lastCreditTxnId: txn.id,
      updatedAt: serverTimestamp()
    });
    batch.update(doc(db, 'publicProfiles', txn.mentorUid), {
      skillCredits: mentorProfile.skillCredits + 1,
      lastCreditTxnId: txn.id,
      updatedAt: serverTimestamp()
    });

    try {
      await batch.commit();
      await pushCampusNotification(
        'peer_credit',
        '+1 Skill Credit Transferred',
        `${txn.learnerName} completed "${txn.skillTitle}" — 1 credit transferred to ${txn.mentorName}.`,
        'peerlearn'
      );
      confetti({ particleCount: 110, spread: 70, origin: { y: 0.6 } });
      addToast(`1 Credit transferred from ${txn.learnerName} to ${txn.mentorName}!`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `skillTransactions/${txn.id}`);
    }
  };

  // EcoPulse: Create Report with Image, GPS & Map Coordinates
  const handleCreateReport = async (payload: {
    location: string;
    issueCategory: 'Electrical/Fan' | 'Water Leakage' | 'Cleanliness' | 'Green Initiative';
    description: string;
    imageData?: string;
    mapX: number;
    mapY: number;
    lat?: number;
    lng?: number;
    gpsAccuracy?: number;
  }) => {
    if (!authUser || !currentUserProfile) return;
    try {
      await addDoc(collection(db, 'ecoReports'), {
        userUid: authUser.uid,
        userName: currentUserProfile.fullName,
        userDepartment: currentUserProfile.department,
        location: payload.location,
        issueCategory: payload.issueCategory,
        description: payload.description,
        ...(payload.imageData ? { imageData: payload.imageData } : {}),
        ...(typeof payload.lat === 'number' ? { lat: payload.lat } : {}),
        ...(typeof payload.lng === 'number' ? { lng: payload.lng } : {}),
        ...(typeof payload.gpsAccuracy === 'number' ? { gpsAccuracy: payload.gpsAccuracy } : {}),
        mapX: payload.mapX,
        mapY: payload.mapY,
        status: 'Open',
        visibility: 'campus',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      await pushCampusNotification(
        'eco_report',
        `EcoPulse Ticket: ${payload.issueCategory}`,
        `${currentUserProfile.fullName} pinned a new issue at ${payload.location}.`,
        'ecopulse'
      );
      addToast('Report submitted and pinned on the campus map!', 'success');
    } catch (err) {
      addToast('Could not submit EcoPulse report. Please check your photo size or connection.', 'danger');
      handleFirestoreError(err, OperationType.CREATE, 'ecoReports');
    }
  };

  // Open Admin Resolve Modal
  const handleOpenResolveModal = (report: EcoReport) => {
    if (!isAdmin || !currentUserProfile) {
      addToast('Only the authorized Portal Administrator can resolve EcoPulse tickets.', 'danger');
      return;
    }
    if (!isCloudSeeded) {
      addToast('Please sync the baseline dataset to Firestore before resolving starter tickets.', 'warning');
      return;
    }
    if (report.status === 'Resolved') return;
    setResolveReportTarget(report);
  };

  // EcoPulse: Admin Confirm Resolve (+10 Green Points + Optional After-Fix Photo & Note)
  const handleConfirmResolveReport = async (payload: {
    report: EcoReport;
    afterImageData?: string;
    resolutionNote?: string;
  }) => {
    if (!isAdmin || !currentUserProfile) return;
    const { report, afterImageData, resolutionNote } = payload;
    if (report.status === 'Resolved') return;

    const batch = writeBatch(db);
    batch.update(doc(db, 'ecoReports', report.id), {
      status: 'Resolved',
      resolvedBy: currentUserProfile.fullName,
      ...(afterImageData ? { afterImageData } : {}),
      ...(resolutionNote ? { resolutionNote: resolutionNote.slice(0, 300) } : {}),
      updatedAt: serverTimestamp()
    });

    const reporterProfile = fsProfiles.find(p => p.uid === report.userUid);
    if (reporterProfile) {
      batch.update(doc(db, 'publicProfiles', report.userUid), {
        greenPoints: reporterProfile.greenPoints + 10,
        updatedAt: serverTimestamp()
      });
    }

    try {
      await batch.commit();
      await pushCampusNotification(
        'eco_reward',
        '+10 Eco Karma Awarded',
        `${currentUserProfile.fullName} resolved "${report.location}" (+10 Karma to ${report.userName}).`,
        'ecopulse'
      );
      confetti({ particleCount: 80, spread: 60, colors: ['#1d4ed8', '#06b6d4', '#f59e0b'] });
      addToast(`Ticket resolved! ${report.userName} earned +10 Eco Karma.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `ecoReports/${report.id}`);
      throw err;
    }
  };

  // Admin: Delete Skill Moderation
  const handleDeleteSkill = async (skillId: string) => {
    try {
      await deleteDoc(doc(db, 'skills', skillId));
      addToast('Skill listing removed.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `skills/${skillId}`);
    }
  };

  // About/Contact Submit
  const handleSendContactMessage = async (payload: {
    senderName: string;
    senderEmail: string;
    subject: string;
    message: string;
  }) => {
    if (!authUser) return;
    try {
      await addDoc(collection(db, 'contactMessages'), {
        senderName: payload.senderName,
        senderEmail: payload.senderEmail,
        subject: payload.subject,
        message: payload.message,
        senderUid: authUser.uid,
        createdAt: serverTimestamp()
      });
      addToast('Feedback sent to Portal Administrator!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'contactMessages');
    }
  };

  // Heritage Quiz
  const spinTrivia = () => {
    setTriviaIdx((triviaIdx + 1) % DEI_TRIVIA.length);
    setShowTriviaAns(false);
    setTriviaEarned(false);
  };

  const revealTriviaAnswer = async () => {
    setShowTriviaAns(true);
    if (!triviaEarned && authUser && currentUserProfile) {
      setTriviaEarned(true);
      const profileExists = fsProfiles.some(p => p.uid === authUser.uid);
      if (profileExists) {
        try {
          await updateDoc(doc(db, 'publicProfiles', authUser.uid), {
            greenPoints: currentUserProfile.greenPoints + 1,
            updatedAt: serverTimestamp()
          });
          addToast('Heritage Quiz answered! Earned +1 Eco Karma.', 'success');
        } catch (err) {
          console.error('Quiz karma update failed:', err);
        }
      }
    }
  };

  // Search Jump Handlers
  const handleSelectRoomFromSearch = (roomId: number) => {
    setActiveTab('smartspace');
    setHighlightedRoomId(roomId);
    const room = rooms.find(r => r.roomId === roomId);
    if (room) {
      setSelectedMapBuilding(room.buildingName);
      addToast(`Focused on ${room.roomName} (${room.status})`, 'info');
    }
  };

  const handleSelectSkillFromSearch = () => {
    setActiveTab('peerlearn');
    setPeerSubTab('feed');
    setSkillCategoryFilter('all');
  };

  const handleSelectReportFromSearch = () => {
    setActiveTab('ecopulse');
  };

  // Computed Filters
  const searchLower = globalSearchQuery.trim().toLowerCase();
  const filteredRooms = rooms.filter(r => {
    const matchBuilding = buildingFilter === 'all' || r.buildingName === buildingFilter;
    const matchStatus = roomStatusFilter === 'all' || r.status === roomStatusFilter;
    const matchSearch =
      !searchLower ||
      r.roomName.toLowerCase().includes(searchLower) ||
      r.code.toLowerCase().includes(searchLower) ||
      r.buildingName.toLowerCase().includes(searchLower) ||
      r.roomType.toLowerCase().includes(searchLower) ||
      r.currentActivity.toLowerCase().includes(searchLower);
    return matchBuilding && matchStatus && matchSearch;
  });

  const availableRoomsCount = rooms.filter(r => r.status === 'Available').length;
  const occupiedRoomsCount = rooms.filter(r => r.status === 'Occupied').length;
  const confirmedBookings = bookings.filter(b => b.status === 'Confirmed');

  const filteredSkills = skills.filter(s => {
    const matchCat = skillCategoryFilter === 'all' || s.category === skillCategoryFilter;
    const matchSearch =
      !searchLower ||
      s.skillTitle.toLowerCase().includes(searchLower) ||
      s.description.toLowerCase().includes(searchLower) ||
      s.userName.toLowerCase().includes(searchLower) ||
      s.userDepartment.toLowerCase().includes(searchLower);
    return matchCat && matchSearch;
  });

  const filteredReports = reports.filter(r => {
    if (!searchLower) return true;
    return (
      r.location.toLowerCase().includes(searchLower) ||
      r.issueCategory.toLowerCase().includes(searchLower) ||
      r.description.toLowerCase().includes(searchLower) ||
      r.userName.toLowerCase().includes(searchLower)
    );
  });

  const ecoChampions = [...profiles]
    .sort((a, b) => b.greenPoints - a.greenPoints)
    .slice(0, 5);

  if (showLanding) {
    return (
      <LandingPortal
        onSelectRoleSignIn={handleRoleSignIn}
        onContinueAsVisitor={(tab = 'smartspace') => {
          setActiveTab(tab);
          setShowLanding(false);
        }}
        onOpenAbout={() => {
          setActiveTab('about');
          setShowLanding(false);
        }}
        isSigningIn={isSigningIn}
        stats={{
          totalRooms: rooms.length,
          availableRooms: availableRoomsCount,
          skillsCount: skills.length,
          openReports: reports.filter(r => r.status === 'Open').length
        }}
        isDarkMode={isDarkMode}
        onToggleDark={() => setIsDarkMode(!isDarkMode)}
        adminEmail={ADMIN_EMAIL}
      />
    );
  }

  const myCampusBookings = authUser
    ? isAdmin
      ? bookings
      : bookings.filter(b => b.bookedByUid === authUser.uid)
    : [];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col transition-colors duration-200">
      {/* Mandatory Case A Quota Exhaustion Banner (Google Maps Platform) */}
      {gmpQuotaExceeded && (
        <div className="sticky top-0 z-50 w-full bg-amber-100 border-b border-amber-300 text-amber-950 px-4 py-2 text-xs font-medium flex flex-wrap items-center justify-center gap-2 text-center">
          <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
          <span>
            Google Maps Platform quota reached. If you are the app owner,{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-bold hover:text-blue-900"
            >
              visit maps developer site
            </a>{' '}
            for instructions to update your account. Interactive SVG Blueprint map remains active below.
          </span>
        </div>
      )}

      {/* 1. CLEAN 3-ZONE TOP HEADER (Sticky on Desktop, Scrolls on Mobile for <=15% fixed chrome) */}
      <header className="md:sticky md:top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-3.5 sm:px-6 lg:px-8 h-14 md:h-16 flex items-center justify-between gap-3 sm:gap-4">
          {/* Zone 1: Brand Wordmark */}
          <button
            onClick={() => setShowLanding(true)}
            className="flex items-center gap-2 sm:gap-2.5 text-left whitespace-nowrap shrink-0 group min-h-[40px]"
            title="Return to Role Hub"
          >
            <BrandLogo className="w-7 h-7 sm:w-8 sm:h-8 transition-transform group-hover:scale-105" />
            <span className="text-base sm:text-lg font-extrabold tracking-tight font-heading text-slate-900 dark:text-white">
              ONECAMPUS
            </span>
          </button>

          {/* Zone 2: Clean Single-Line Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-400 shrink-0">
            {(
              [
                ['smartspace', 'SmartSpace'],
                ['peerlearn', 'PeerLearn'],
                ['ecopulse', 'EcoPulse'],
                ['about', 'About & Contact']
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                  activeTab === key
                    ? 'border-blue-700 dark:border-cyan-400 text-blue-700 dark:text-cyan-400 font-semibold'
                    : 'border-transparent hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {label}
              </button>
            ))}
          </nav>

          {/* Zone 3: Search, Alerts, Theme, Primary Account Action */}
          <div className="flex items-center gap-1.5 sm:gap-3 flex-1 md:flex-initial justify-end min-w-0">
            <div className="hidden lg:block w-64">
              <GlobalSearchBar
                rooms={rooms}
                skills={skills}
                reports={reports}
                onSelectRoom={handleSelectRoomFromSearch}
                onSelectSkill={handleSelectSkillFromSearch}
                onSelectReport={handleSelectReportFromSearch}
                globalQuery={globalSearchQuery}
                setGlobalQuery={setGlobalSearchQuery}
              />
            </div>

            <NotificationCenter
              notifications={notifications}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />

            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
              aria-label="Toggle color theme"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {authUser && currentUserProfile ? (
              <div className="flex items-center gap-2 shrink-0">
                <div className="hidden sm:flex flex-col text-right leading-tight">
                  <span className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[120px]">
                    {currentUserProfile.fullName}
                  </span>
                  <span className="text-[10px] font-semibold text-blue-700 dark:text-cyan-400 uppercase">
                    {isAdmin ? 'Admin' : currentUserProfile.role}
                  </span>
                </div>
                <button
                  onClick={handleSignOut}
                  className="min-h-[40px] sm:min-h-0 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 whitespace-nowrap shrink-0"
                  title="Sign out"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Sign Out</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleRoleSignIn('student')}
                disabled={isSigningIn}
                className="min-h-[40px] sm:min-h-0 px-3.5 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Mobile Search Strip (Thumb navigation sits at bottom of viewport) */}
      <div className="md:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-3.5 py-2.5">
        <GlobalSearchBar
          rooms={rooms}
          skills={skills}
          reports={reports}
          onSelectRoom={handleSelectRoomFromSearch}
          onSelectSkill={handleSelectSkillFromSearch}
          onSelectReport={handleSelectReportFromSearch}
          globalQuery={globalSearchQuery}
          setGlobalQuery={setGlobalSearchQuery}
        />
      </div>

      {/* 2. TOP ROYAL DARK BLUE WELCOME HERO & LIVE STATS STRIP */}
      <section className="relative overflow-hidden bg-gradient-to-br from-slate-950 via-blue-950 to-indigo-950 text-white border-b border-blue-900/60 py-5 sm:py-6">
        <img
          src={heroBannerImg}
          alt="DEI Campus Aerial Backdrop"
          className="absolute inset-0 w-full h-full object-cover opacity-20 mix-blend-luminosity pointer-events-none"
        />
        <div className="relative max-w-7xl mx-auto px-3.5 sm:px-6 lg:px-8 space-y-4 sm:space-y-5 animate-welcome">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3.5 sm:gap-4">
            <div>
              <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] sm:text-xs text-blue-200/80 mb-1">
                <span className="flex items-center gap-1 font-mono tabular-nums text-cyan-300">
                  <Clock className="w-3.5 h-3.5" />
                  {timeStr || '--:--:--'}
                </span>
                <span aria-hidden="true">·</span>
                <span>Dayalbagh Educational Institute, Agra</span>
                <span aria-hidden="true">·</span>
                <span className={isCloudSeeded ? 'text-emerald-300 font-semibold' : 'text-amber-300 font-semibold'}>
                  {isCloudSeeded ? (dbConnected ? 'Live Cloud Synced' : 'Offline Cache') : 'Demo Baseline Dataset'}
                </span>
              </div>
              <h1 className="text-xl sm:text-3xl font-extrabold tracking-tight text-white font-heading">
                {currentUserProfile
                  ? `Welcome, ${currentUserProfile.fullName}`
                  : 'DEI Campus Explorer (Visitor Mode)'}
              </h1>
              <p className="text-xs sm:text-sm text-blue-100/80 mt-0.5">
                {currentUserProfile
                  ? `${currentUserProfile.department} · Role: ${isAdmin ? 'Portal Administrator' : currentUserProfile.role}`
                  : 'Read-only live view across SmartSpace rooms, PeerLearn skills, and EcoPulse geo-map. Sign in to submit updates.'}
              </p>
            </div>

            {currentUserProfile ? (
              <div className="grid grid-cols-2 sm:flex items-center gap-2.5 sm:gap-3">
                <div className="bg-white/10 backdrop-blur-md border border-white/15 rounded-2xl px-3 py-2.5 sm:px-4 flex items-center gap-2.5 sm:gap-3">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0">
                    <Coins className="w-4 h-4 sm:w-5 sm:h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[11px] text-amber-300 font-bold truncate">Skill Credits</div>
                    <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-white">
                      {currentUserProfile.skillCredits}
                    </div>
                  </div>
                </div>

                <div className="bg-white/10 backdrop-blur-md border border-white/15 rounded-2xl px-3 py-2.5 sm:px-4 flex items-center gap-2.5 sm:gap-3">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-cyan-400 text-slate-950 flex items-center justify-center shrink-0">
                    <Award className="w-4 h-4 sm:w-5 sm:h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[11px] text-cyan-300 font-bold truncate">Eco Karma</div>
                    <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-white">
                      {currentUserProfile.greenPoints} pts
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setShowLanding(true)}
                className="min-h-[42px] sm:min-h-0 px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-xs font-bold text-slate-950 self-start md:self-auto transition-colors"
              >
                Switch Role / Sign In
              </button>
            )}
          </div>

          {/* 4-KPI Strip */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-white/10 backdrop-blur-md border border-white/15 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <span className="text-xs text-blue-100/80 block">Available Rooms</span>
                <span className="text-2xl font-bold text-emerald-300 font-mono tabular-nums">
                  {availableRoomsCount}
                </span>
                <span className="text-[11px] text-blue-200/70 block mt-0.5">Out of {rooms.length} mapped rooms</span>
              </div>
              <DoorOpen className="w-5 h-5 text-emerald-300" />
            </div>

            <div className="bg-white/10 backdrop-blur-md border border-white/15 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <span className="text-xs text-blue-100/80 block">Slot Bookings</span>
                <span className="text-2xl font-bold text-cyan-300 font-mono tabular-nums">
                  {confirmedBookings.length}
                </span>
                <span className="text-[11px] text-blue-200/70 block mt-0.5">{occupiedRoomsCount} currently occupied</span>
              </div>
              <CalendarPlus className="w-5 h-5 text-cyan-300" />
            </div>

            <div className="bg-white/10 backdrop-blur-md border border-white/15 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <span className="text-xs text-blue-100/80 block">PeerLearn Skills</span>
                <span className="text-2xl font-bold text-amber-300 font-mono tabular-nums">
                  {skills.length}
                </span>
                <span className="text-[11px] text-blue-200/70 block mt-0.5">1 Credit = 1 Hour Barter</span>
              </div>
              <Users className="w-5 h-5 text-amber-300" />
            </div>

            <div className="bg-white/10 backdrop-blur-md border border-white/15 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <span className="text-xs text-blue-100/80 block">Open Eco Tickets</span>
                <span className="text-2xl font-bold text-rose-300 font-mono tabular-nums">
                  {reports.filter(r => r.status === 'Open').length}
                </span>
                <span className="text-[11px] text-blue-200/70 block mt-0.5">
                  {reports.filter(r => r.status === 'Resolved').length} resolved tickets
                </span>
              </div>
              <Flame className="w-5 h-5 text-rose-300" />
            </div>
          </div>
        </div>
      </section>

      {/* 3. MAIN WORKSPACE */}
      <main className="max-w-7xl mx-auto px-3.5 sm:px-6 lg:px-8 py-5 sm:py-7 flex-1 w-full">
        {activeTab === 'about' ? (
          <AboutContactView
            isSignedIn={Boolean(authUser)}
            currentUserName={currentUserProfile?.fullName}
            currentUserEmail={authUser?.email || undefined}
            currentUserRole={currentUserProfile?.role}
            adminEmail={ADMIN_EMAIL}
            onSendMessage={handleSendContactMessage}
            onRequestSignIn={() => handleRoleSignIn('student')}
          />
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Main Column (8 cols) */}
            <div className="lg:col-span-8 space-y-6">
              {/* TAB 1: SMARTSPACE */}
              {activeTab === 'smartspace' && (
                <div className="space-y-6">
                  <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <h2 className="text-lg font-bold text-slate-900 dark:text-white font-heading">
                          SmartSpace Live Room Grid &amp; Slot Reservations
                        </h2>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          All 29 floor plan spaces synced 1:1 with room availability &amp; overlap-checked bookings.
                        </p>
                      </div>
                      <div className="flex items-center gap-2.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => setActiveTab('ecopulse')}
                          className="px-3 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-cyan-300 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap"
                        >
                          <MapPin className="w-3.5 h-3.5" />
                          <span>Campus Google Earth</span>
                        </button>
                        <span className="text-xs font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                          {filteredRooms.length} of {rooms.length} rooms
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row sm:flex-wrap sm:items-center justify-between gap-2.5 sm:gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                      <select
                        value={buildingFilter}
                        onChange={(e) => {
                          const val = e.target.value;
                          setBuildingFilter(val);
                          if (val !== 'all') setSelectedMapBuilding(val);
                        }}
                        className="w-full sm:flex-1 sm:min-w-[190px] min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-700 dark:text-slate-200 font-medium"
                      >
                        <option value="all">All 6 DEI Campus Blocks</option>
                        <option value="Faculty of Engineering">Faculty of Engineering</option>
                        <option value="Faculty of Science">Faculty of Science</option>
                        <option value="Central Library">Central Library</option>
                        <option value="Multimedia Lab">Multimedia Lab</option>
                        <option value="Seminar Hall Complex">Seminar Hall Complex</option>
                        <option value="DEI Canteen & Campus Hub">DEI Canteen &amp; Campus Hub</option>
                      </select>

                      <div className="grid grid-cols-3 sm:flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                        {(['all', 'Available', 'Occupied'] as const).map(st => (
                          <button
                            key={st}
                            onClick={() => setRoomStatusFilter(st)}
                            className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                              roomStatusFilter === st
                                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-2xs'
                                : 'text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            {st === 'all' ? 'All' : st}
                          </button>
                        ))}
                      </div>

                      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl overflow-x-auto max-w-full scrollbar-thin">
                        {(
                          [
                            ['both', 'Dual', SlidersHorizontal],
                            ['map', 'Blueprint', MapIcon],
                            ['cards', 'Cards', LayoutGrid],
                            ['my_bookings', `My Bookings (${myCampusBookings.filter(b => b.status === 'Confirmed').length})`, CalendarCheck],
                            ['trends', 'Analytics', TrendingUp]
                          ] as const
                        ).map(([mode, label, Icon]) => (
                          <button
                            key={mode}
                            onClick={() => setSmartSpaceView(mode)}
                            className={`min-h-[38px] sm:min-h-0 px-2.5 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                              smartSpaceView === mode
                                ? 'bg-blue-700 text-white shadow-2xs'
                                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                            }`}
                          >
                            <Icon className="w-3.5 h-3.5" />
                            <span>{label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {smartSpaceView === 'my_bookings' && (
                    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
                      <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                        <div>
                          <h3 className="font-bold text-slate-900 dark:text-white">
                            {isAdmin ? 'All Campus Slot Reservations' : 'My SmartSpace Reservations'}
                          </h3>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            Inspect active time slots and release rooms in one tap if plans change.
                          </p>
                        </div>
                        <span className="text-xs font-mono text-blue-700 dark:text-cyan-400 font-bold">
                          {myCampusBookings.filter(b => b.status === 'Confirmed').length} Active
                        </span>
                      </div>
                      {!authUser ? (
                        <div className="p-8 text-center text-xs text-slate-400">
                          Sign in with Google to reserve classroom slots and manage your bookings.
                        </div>
                      ) : myCampusBookings.length === 0 ? (
                        <div className="p-8 text-center text-xs text-slate-400">
                          No room reservations yet. Switch to Blueprint or Cards to book a slot!
                        </div>
                      ) : (
                        <div className="divide-y divide-slate-100 dark:divide-slate-800">
                          {myCampusBookings.map(bk => (
                            <div
                              key={bk.id}
                              className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                            >
                              <div className="space-y-0.5">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-sm text-slate-900 dark:text-white">
                                    {bk.roomName}
                                  </span>
                                  <span
                                    className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                                      bk.status === 'Confirmed'
                                        ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300'
                                        : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                                    }`}
                                  >
                                    {bk.status}
                                  </span>
                                </div>
                                <div className="text-xs text-slate-500 dark:text-slate-400">
                                  {bk.buildingName} ·{' '}
                                  <span className="font-mono font-semibold text-blue-700 dark:text-cyan-400">
                                    {bk.date} {bk.startTime}–{bk.endTime}
                                  </span>
                                </div>
                                <div className="text-xs text-slate-600 dark:text-slate-300">
                                  Purpose: {bk.purpose} · By {bk.bookedByName}
                                </div>
                              </div>
                              {bk.status === 'Confirmed' && (authUser.uid === bk.bookedByUid || isAdmin) && (
                                <button
                                  onClick={() => handleCancelBooking(bk)}
                                  className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-700 dark:text-rose-300 text-xs font-semibold border border-rose-200 dark:border-rose-800 shrink-0"
                                >
                                  Cancel Slot
                                </button>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {smartSpaceView === 'trends' && (
                    <FacultyTrends
                      rooms={rooms}
                      bookings={bookings}
                      skills={skills}
                      transactions={fsTransactions}
                      reports={reports}
                    />
                  )}

                  {(smartSpaceView === 'map' || smartSpaceView === 'both') && (
                    <CampusFloorPlan
                      rooms={rooms}
                      bookings={bookings}
                      selectedBuilding={buildingFilter === 'all' ? selectedMapBuilding : buildingFilter}
                      onSelectBuilding={(b) => {
                        setSelectedMapBuilding(b);
                        if (buildingFilter !== 'all') setBuildingFilter(b);
                      }}
                      onToggleRoom={handleToggleRoom}
                      onBookRoom={(rm) => {
                        if (!requireSignedInAction()) return;
                        setBookingRoomTarget(rm);
                      }}
                      activeRoomId={highlightedRoomId}
                      onSelectRoom={(id) => setHighlightedRoomId(id)}
                      canModify={Boolean(authUser)}
                    />
                  )}

                  {(smartSpaceView === 'cards' || smartSpaceView === 'both') && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-medium px-1">
                        <span>Room Occupancy &amp; Slot Schedule</span>
                        <span className="font-mono">{filteredRooms.length} rooms</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {filteredRooms.map((room) => {
                          const isAvail = room.status === 'Available';
                          const roomSlots = confirmedBookings.filter(b => b.roomId === room.roomId);

                          return (
                            <div
                              key={room.roomId}
                              className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between gap-4"
                            >
                              <div className="space-y-2.5">
                                <div className="flex items-center justify-between text-xs">
                                  <span className="font-mono font-bold text-slate-500 dark:text-slate-400">
                                    {room.code} · {room.roomType}
                                  </span>
                                  <span
                                    className={`font-semibold ${
                                      isAvail ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                                    }`}
                                  >
                                    {room.status}
                                  </span>
                                </div>

                                <div>
                                  <h3 className="font-bold text-slate-900 dark:text-white text-base font-heading">
                                    {room.roomName}
                                  </h3>
                                  <p className="text-xs text-slate-500 dark:text-slate-400">
                                    {room.buildingName} · {room.capacity} seats
                                  </p>
                                </div>

                                <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl">
                                  {room.currentActivity}
                                </p>

                                {roomSlots.length > 0 && (
                                  <div className="space-y-1 pt-1">
                                    <div className="text-[11px] font-semibold text-blue-700 dark:text-cyan-400">
                                      Upcoming Booked Slots ({roomSlots.length}):
                                    </div>
                                    {roomSlots.slice(0, 2).map(bk => (
                                      <div
                                        key={bk.id}
                                        className="text-[11px] flex items-center justify-between bg-blue-50/70 dark:bg-blue-950/30 px-2.5 py-1.5 rounded-lg text-slate-700 dark:text-slate-300"
                                      >
                                        <span className="truncate font-mono">
                                          {bk.date.slice(5)} {bk.startTime}–{bk.endTime} · {bk.bookedByName}
                                        </span>
                                        {(authUser?.uid === bk.bookedByUid || isAdmin) && (
                                          <button
                                            onClick={() => handleCancelBooking(bk)}
                                            className="text-rose-600 hover:underline ml-2 shrink-0"
                                          >
                                            Cancel
                                          </button>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>

                              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 sm:flex sm:items-center sm:justify-between gap-2">
                                <button
                                  onClick={() => {
                                    if (!requireSignedInAction()) return;
                                    setBookingRoomTarget(room);
                                  }}
                                  className="min-h-[42px] sm:min-h-0 px-3 py-2 sm:py-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
                                >
                                  <CalendarPlus className="w-3.5 h-3.5" />
                                  <span>Book Slot</span>
                                </button>
                                <button
                                  onClick={() => handleToggleRoom(room)}
                                  className="min-h-[42px] sm:min-h-0 px-3 py-2 sm:py-1.5 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap"
                                >
                                  {isAvail ? 'Mark Occupied' : 'Mark Available'}
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: PEERLEARN */}
              {activeTab === 'peerlearn' && (
                <div className="space-y-6">
                  <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <h2 className="text-lg font-bold text-slate-900 dark:text-white font-heading">
                          PeerLearn Skill Barter Marketplace
                        </h2>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          Teach 1 hour to earn 1 Skill Credit; spend 1 Credit to book peer mentoring sessions.
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          if (!requireSignedInAction()) return;
                          setIsOfferSkillModalOpen(true);
                        }}
                        className="min-h-[44px] sm:min-h-0 w-full sm:w-auto px-4 py-2.5 sm:py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Offer a Skill</span>
                      </button>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-slate-100 dark:border-slate-800">
                      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                        <button
                          onClick={() => setPeerSubTab('feed')}
                          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                            peerSubTab === 'feed'
                              ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white'
                              : 'text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          Marketplace ({skills.length})
                        </button>
                        <button
                          onClick={() => setPeerSubTab('my_sessions')}
                          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                            peerSubTab === 'my_sessions'
                              ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white'
                              : 'text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          My Sessions ({fsTransactions.length})
                        </button>
                      </div>

                      {peerSubTab === 'feed' && (
                        <div className="flex items-center gap-1 overflow-x-auto pb-1 max-w-full">
                          {['all', 'Coding', 'Academics', 'Design', 'Music/Art'].map(cat => (
                            <button
                              key={cat}
                              onClick={() => setSkillCategoryFilter(cat)}
                              className={`px-2.5 py-1 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                                skillCategoryFilter === cat
                                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                              }`}
                            >
                              {cat === 'all' ? 'All' : cat}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {peerSubTab === 'feed' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {filteredSkills.map(skill => {
                        const isOwner = authUser?.uid === skill.userUid;
                        return (
                          <div
                            key={skill.id}
                            className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between gap-4"
                          >
                            <div className="space-y-2.5">
                              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                                <span className="font-semibold text-slate-700 dark:text-slate-300">{skill.category}</span>
                                <span>{skill.createdAtText}</span>
                              </div>
                              <h3 className="font-bold text-slate-900 dark:text-white text-base font-heading">
                                {skill.skillTitle}
                              </h3>
                              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                                {skill.description}
                              </p>
                              <div className="text-xs text-slate-500 dark:text-slate-400">
                                Mentor: <strong className="text-slate-800 dark:text-slate-200">{skill.userName}</strong> · {skill.userDepartment}
                              </div>
                              <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                                <Clock className="w-3.5 h-3.5 shrink-0" />
                                <span>{skill.availabilityTime}</span>
                              </div>
                            </div>

                            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                              <span className="text-xs font-bold text-amber-700 dark:text-amber-400 font-mono">
                                1 Credit / hr
                              </span>
                              <div className="flex items-center gap-2">
                                {(isOwner || isAdmin) && isCloudSeeded && (
                                  <button
                                    onClick={() => handleDeleteSkill(skill.id)}
                                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                                    title="Remove listing"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                {isOwner ? (
                                  <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                                    Your Listing
                                  </span>
                                ) : (
                                  <button
                                    onClick={() => handleBookSkill(skill)}
                                    className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-blue-700 hover:bg-blue-800 text-white transition-colors whitespace-nowrap"
                                  >
                                    Book Session
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {peerSubTab === 'my_sessions' && (
                    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
                      <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                        <div>
                          <h3 className="font-bold text-slate-900 dark:text-white">Your Skill Barter Sessions</h3>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            Rate your mentor 1–5 stars and confirm completion after your 1-hour session to atomically transfer 1 Skill Credit.
                          </p>
                        </div>
                        <span className="text-xs font-mono text-slate-500">{fsTransactions.length} total</span>
                      </div>

                      {!authUser ? (
                        <div className="p-8 text-center text-xs text-slate-400">
                          Sign in with Google to book skills and view your live barter transactions.
                        </div>
                      ) : fsTransactions.length === 0 ? (
                        <div className="p-8 text-center text-xs text-slate-400">
                          No sessions booked yet. Pick a skill from the Marketplace to begin!
                        </div>
                      ) : (
                        <div className="divide-y divide-slate-100 dark:divide-slate-800">
                          {fsTransactions.map(txn => {
                            const isPending = txn.status === 'Requested';
                            const canComplete = isPending && (txn.learnerUid === authUser.uid || isAdmin);
                            const chosenRating = sessionRatings[txn.id] ?? 5;

                            return (
                              <div
                                key={txn.id}
                                className="p-4 space-y-3"
                              >
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                  <div>
                                    <div className="font-semibold text-slate-900 dark:text-white text-sm">
                                      {txn.skillTitle} · <span className="text-xs text-slate-500">{txn.category}</span>
                                    </div>
                                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                                      Mentor: <strong>{txn.mentorName}</strong> · Learner: <strong>{txn.learnerName}</strong>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-3">
                                    <span
                                      className={`text-xs font-semibold ${
                                        txn.status === 'Completed'
                                          ? 'text-emerald-600 dark:text-emerald-400'
                                          : 'text-amber-600 dark:text-amber-400'
                                      }`}
                                    >
                                      {txn.status}
                                    </span>
                                    {txn.status === 'Completed' ? (
                                      <span className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                                        <Check className="w-3.5 h-3.5" /> Settled
                                      </span>
                                    ) : !canComplete ? (
                                      <span className="text-xs text-slate-400">Awaiting learner confirmation</span>
                                    ) : null}
                                  </div>
                                </div>

                                {canComplete && (
                                  <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center gap-2.5">
                                    <div className="flex items-center gap-1 shrink-0" title="Rate mentor session">
                                      {[1, 2, 3, 4, 5].map(num => (
                                        <button
                                          key={num}
                                          type="button"
                                          onClick={() =>
                                            setSessionRatings(prev => ({ ...prev, [txn.id]: num }))
                                          }
                                          className="p-0.5"
                                          aria-label={`Rate ${num} star`}
                                        >
                                          <Star
                                            className={`w-4 h-4 ${
                                              num <= chosenRating
                                                ? 'fill-amber-400 text-amber-400'
                                                : 'text-slate-300 dark:text-slate-600'
                                            }`}
                                          />
                                        </button>
                                      ))}
                                    </div>
                                    <input
                                      type="text"
                                      maxLength={200}
                                      value={sessionReviews[txn.id] || ''}
                                      onChange={(e) =>
                                        setSessionReviews(prev => ({ ...prev, [txn.id]: e.target.value }))
                                      }
                                      placeholder="Quick feedback note (optional)..."
                                      className="flex-1 text-xs rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-slate-800 dark:text-white"
                                    />
                                    <button
                                      onClick={() => handleCompleteSession(txn)}
                                      className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-blue-700 hover:bg-blue-800 text-white transition-colors whitespace-nowrap shrink-0"
                                    >
                                      Complete &amp; Transfer 1 Credit
                                    </button>
                                  </div>
                                )}

                                {txn.status === 'Completed' && (txn.rating || txn.review) && (
                                  <div className="bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200/70 dark:border-blue-900/50 rounded-xl px-3 py-2 flex flex-wrap items-center gap-2 text-xs">
                                    {typeof txn.rating === 'number' && (
                                      <span className="flex items-center gap-0.5 font-bold text-amber-500">
                                        {Array.from({ length: txn.rating }).map((_, i) => (
                                          <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                                        ))}
                                      </span>
                                    )}
                                    {txn.review && (
                                      <span className="text-slate-700 dark:text-slate-300">
                                        &ldquo;{txn.review}&rdquo;
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: ECOPULSE */}
              {activeTab === 'ecopulse' && (
                <div className="space-y-6">
                  <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <h2 className="text-lg font-bold text-slate-900 dark:text-white font-heading">
                          EcoPulse Campus Care &amp; Satellite Geo-Map
                        </h2>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          Capture live camera proof, lock exact standing GPS location, and earn +10 Eco Karma on Admin verification.
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          if (!requireSignedInAction()) return;
                          setIsReportModalOpen(true);
                        }}
                        className="min-h-[44px] sm:min-h-0 w-full sm:w-auto px-4 py-2.5 sm:py-2 rounded-xl bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-800 hover:to-indigo-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap shadow-sm"
                      >
                        <Camera className="w-4 h-4" />
                        <span>Log Campus Report</span>
                      </button>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                        {(
                          [
                            ['both', 'Dual View'],
                            ['map', 'Satellite Map'],
                            ['feed', 'Feed List']
                          ] as const
                        ).map(([mode, label]) => (
                          <button
                            key={mode}
                            onClick={() => setEcoView(mode)}
                            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                              ecoView === mode
                                ? 'bg-blue-700 text-white'
                                : 'text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            {label}
                          </button>
                        ))}
                      </div>
                      <span className="text-xs font-mono text-slate-500">
                        {reports.filter(r => r.status === 'Open').length} Open · {reports.length} Total
                      </span>
                    </div>
                  </div>

                  {(ecoView === 'map' || ecoView === 'both') && (
                    <EcoPulseMap
                      reports={reports}
                      onResolveReport={handleOpenResolveModal}
                      isAdmin={isAdmin}
                      gmpQuotaExceeded={gmpQuotaExceeded}
                    />
                  )}

                  {(ecoView === 'feed' || ecoView === 'both') && (
                    <div className="space-y-4">
                      {filteredReports.map(rep => {
                        const isOpen = rep.status === 'Open';
                        return (
                          <div
                            key={rep.id}
                            className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 flex flex-col gap-3"
                          >
                            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                              <div className="flex items-center gap-2">
                                <span
                                  className={`font-bold ${
                                    isOpen ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'
                                  }`}
                                >
                                  {rep.status}
                                </span>
                                <span aria-hidden="true">·</span>
                                <span className="font-semibold text-blue-700 dark:text-cyan-400">{rep.issueCategory}</span>
                              </div>
                              <span className="text-[11px] text-slate-400">
                                {rep.userName} ({rep.userDepartment}) · {rep.createdAtText}
                              </span>
                            </div>

                            <h3 className="font-bold text-slate-900 dark:text-white text-base">{rep.location}</h3>
                            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{rep.description}</p>

                            {(rep.imageData || rep.afterImageData) && (
                              <div className={`grid gap-3 ${rep.imageData && rep.afterImageData ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1'}`}>
                                {rep.imageData && (
                                  <div className="space-y-1">
                                    {rep.afterImageData && (
                                      <span className="text-[11px] font-bold text-slate-500">Before (Reported Evidence):</span>
                                    )}
                                    <img
                                      src={rep.imageData}
                                      alt={rep.location}
                                      className="w-full max-w-md h-44 object-cover rounded-xl border border-slate-200 dark:border-slate-700"
                                    />
                                  </div>
                                )}
                                {rep.afterImageData && (
                                  <div className="space-y-1">
                                    <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                                      After Fix (Admin Verified):
                                    </span>
                                    <img
                                      src={rep.afterImageData}
                                      alt="After resolution verification"
                                      className="w-full max-w-md h-44 object-cover rounded-xl border border-emerald-300 dark:border-emerald-800"
                                    />
                                  </div>
                                )}
                              </div>
                            )}

                            {rep.resolutionNote && (
                              <div className="p-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-200">
                                <strong>Resolution Note:</strong> {rep.resolutionNote}
                              </div>
                            )}

                            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                              <span className="text-xs text-slate-500 dark:text-slate-400 font-mono flex items-center gap-1">
                                <MapPin className="w-3.5 h-3.5 text-blue-700 dark:text-cyan-400" />
                                {typeof rep.lat === 'number' && typeof rep.lng === 'number'
                                  ? `GPS: ${rep.lat.toFixed(5)}, ${rep.lng.toFixed(5)}`
                                  : `Map Pin: (${rep.mapX}, ${rep.mapY})`}
                              </span>
                              {isOpen ? (
                                isAdmin ? (
                                  <button
                                    onClick={() => handleOpenResolveModal(rep)}
                                    className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-blue-700 hover:bg-blue-800 text-white flex items-center gap-1.5 transition-colors"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    <span>Verify &amp; Resolve (+10 Karma)</span>
                                  </button>
                                ) : (
                                  <span className="text-xs text-slate-400">Pending Administrator verification</span>
                                )
                              ) : (
                                <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                                  <CheckCircle2 className="w-4 h-4" />
                                  Resolved {rep.resolvedBy ? `by ${rep.resolvedBy}` : ''}
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* SIDEBAR (4 cols) */}
            <aside className="lg:col-span-4 space-y-6">
              {/* Admin Controls Panel (Only visible to authenticated Admin tripathig175@gmail.com) */}
              {isAdmin && (
                <div className="bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 rounded-2xl p-5 space-y-3">
                  <div className="flex items-center gap-2 font-bold text-sm text-amber-950 dark:text-amber-300">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Portal Administrator Controls</span>
                  </div>
                  <p className="text-xs text-amber-900/80 dark:text-amber-300/80 leading-relaxed">
                    Authenticated as owner-locked Admin ({ADMIN_EMAIL}). You can verify EcoPulse tickets, moderate bookings/skills, and re-seed baseline rooms.
                  </p>
                  <button
                    onClick={async () => {
                      if (!authUser) return;
                      setIsSeeding(true);
                      try {
                        await seedCampusBaselineToFirestore(
                          authUser.uid,
                          currentUserProfile?.fullName || 'Portal Administrator'
                        );
                        addToast('Synced all 29 campus rooms & starter data to Firestore.', 'success');
                      } finally {
                        setIsSeeding(false);
                      }
                    }}
                    disabled={isSeeding}
                    className="w-full py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
                  >
                    <Database className="w-3.5 h-3.5" />
                    <span>{isSeeding ? 'Syncing Dataset...' : 'Sync / Reset Baseline Dataset'}</span>
                  </button>
                </div>
              )}

              {/* DEI Campus Heritage Quiz */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm font-heading">
                    DEI Heritage Quiz
                  </h3>
                  <span className="text-xs font-mono font-semibold text-blue-700 dark:text-cyan-400">
                    +1 Karma
                  </span>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-3">
                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 leading-relaxed">
                    {DEI_TRIVIA[triviaIdx].q}
                  </p>
                  {showTriviaAns ? (
                    <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-blue-200 dark:border-blue-800 text-xs text-blue-900 dark:text-cyan-300 font-medium">
                      {DEI_TRIVIA[triviaIdx].a}
                    </div>
                  ) : (
                    <button
                      onClick={revealTriviaAnswer}
                      className="w-full py-2 px-3 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      Reveal Answer
                    </button>
                  )}
                  <button
                    onClick={spinTrivia}
                    className="w-full py-2 px-3 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                    <span>Next Question</span>
                  </button>
                </div>
                <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5" />
                  <span>Dayalbagh ethos: Work is Worship</span>
                </div>
              </div>

              {/* DEI Eco-Champions Leaderboard */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm font-heading">
                    Eco-Champions Leaderboard
                  </h3>
                  <span className="text-xs text-slate-400 font-mono">Top 5</span>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {ecoChampions.map((champ, index) => (
                    <div key={champ.uid} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                      <div className="min-w-0">
                        <div className="font-bold text-slate-800 dark:text-slate-200 truncate">
                          {index + 1}. {champ.fullName}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate">{champ.department}</div>
                      </div>
                      <span className="font-bold font-mono text-blue-700 dark:text-cyan-400 tabular-nums shrink-0">
                        {champ.greenPoints} pts
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </aside>
          </div>
        )}
      </main>

      {/* MODALS */}
      {showOnboardingModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden max-h-[92vh] flex flex-col">
            <div className="pt-2.5 pb-1 sm:hidden flex justify-center shrink-0">
              <div className="w-10 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" />
            </div>
            <div className="p-5 sm:p-6 space-y-4 overflow-y-auto">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-lg font-heading">
                  Complete Campus Profile
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Set your DEI Roll No / ID and department to activate Skill Credits &amp; Room Bookings.
                </p>
              </div>
              <form onSubmit={handleCompleteOnboarding} className="space-y-3">
                <div>
                  <label className="text-xs font-semibold block mb-1">Full Name</label>
                  <input
                    type="text"
                    value={onboardName}
                    onChange={(e) => setOnboardName(e.target.value)}
                    minLength={2}
                    maxLength={80}
                    className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold block mb-1">Role</label>
                  <select
                    value={onboardRole}
                    onChange={(e) => setOnboardRole(e.target.value as 'student' | 'faculty')}
                    className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2"
                  >
                    <option value="student">Student</option>
                    <option value="faculty">Faculty</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold block mb-1">Roll No / Faculty ID</label>
                  <input
                    type="text"
                    value={onboardRollNo}
                    onChange={(e) => setOnboardRollNo(e.target.value)}
                    minLength={2}
                    maxLength={32}
                    placeholder="e.g. 220101 or DEI-FAC-12"
                    className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold block mb-1">Department / Faculty</label>
                  <select
                    value={onboardDept}
                    onChange={(e) => setOnboardDept(e.target.value)}
                    className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2"
                  >
                    <option value="Faculty of Engineering">Faculty of Engineering</option>
                    <option value="Faculty of Science">Faculty of Science</option>
                    <option value="Multimedia Lab & Design">Multimedia Lab &amp; Design</option>
                    <option value="Faculty of Social Sciences">Faculty of Social Sciences</option>
                    <option value="Faculty of Arts">Faculty of Arts</option>
                    <option value="Faculty of Commerce">Faculty of Commerce</option>
                  </select>
                </div>
                <button
                  type="submit"
                  className="w-full min-h-[44px] sm:min-h-0 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold transition-colors"
                >
                  Save Profile &amp; Enter Portal
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      <RoomBookingModal
        room={bookingRoomTarget}
        allRooms={rooms}
        bookings={bookings}
        isOpen={Boolean(bookingRoomTarget)}
        onClose={() => setBookingRoomTarget(null)}
        onSelectAlternativeRoom={(alt) => {
          setBookingRoomTarget(alt);
          addToast(`Switched to ${alt.code} · ${alt.roomName}`, 'info');
        }}
        onConfirmBooking={handleConfirmRoomBooking}
      />

      {isOfferSkillModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden max-h-[92vh] flex flex-col">
            <div className="pt-2.5 pb-1 sm:hidden flex justify-center shrink-0">
              <div className="w-10 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" />
            </div>
            <div className="p-5 sm:p-6 overflow-y-auto">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">Offer a Skill in PeerLearn</h3>
                <button
                  onClick={() => setIsOfferSkillModalOpen(false)}
                  className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white"
                  aria-label="Close offer skill modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <form onSubmit={handleCreateSkill} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold block mb-1">Skill Title</label>
                  <input
                    type="text"
                    value={newSkillTitle}
                    onChange={(e) => setNewSkillTitle(e.target.value)}
                    minLength={3}
                    maxLength={140}
                    placeholder="e.g. AutoCAD 3D Drafting"
                    className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold block mb-1">Category</label>
                  <select
                    value={newSkillCat}
                    onChange={(e) => setNewSkillCat(e.target.value as typeof newSkillCat)}
                    className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2"
                  >
                    <option value="Coding">Coding</option>
                    <option value="Academics">Academics</option>
                    <option value="Design">Design</option>
                    <option value="Music/Art">Music/Art</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold block mb-1">Description</label>
                  <textarea
                    value={newSkillDesc}
                    onChange={(e) => setNewSkillDesc(e.target.value)}
                    minLength={10}
                    maxLength={600}
                    rows={3}
                    placeholder="What will you cover in a 1-hour session?"
                    className="w-full text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold block mb-1">Availability Time</label>
                  <input
                    type="text"
                    value={newSkillAvail}
                    onChange={(e) => setNewSkillAvail(e.target.value)}
                    minLength={3}
                    maxLength={120}
                    placeholder="e.g. Wed & Fri: 4:00 PM - 6:00 PM"
                    className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2"
                    required
                  />
                </div>
                <div className="pt-2 pb-1 sm:pb-0 flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsOfferSkillModalOpen(false)}
                    className="min-h-[44px] sm:min-h-0 px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="min-h-[44px] sm:min-h-0 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-xl"
                  >
                    Publish Skill
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      <ReportIssueModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        gmpQuotaExceeded={gmpQuotaExceeded}
        onSubmitReport={handleCreateReport}
      />

      <ResolveReportModal
        report={resolveReportTarget}
        isOpen={Boolean(resolveReportTarget)}
        onClose={() => setResolveReportTarget(null)}
        onConfirmResolve={handleConfirmResolveReport}
      />

      {/* Toast Notifications (Positioned above fixed bottom nav on mobile) */}
      <div className="fixed bottom-20 md:bottom-4 left-3 right-3 sm:left-auto sm:right-4 z-50 space-y-2 pointer-events-none">
        {toasts.map(t => (
          <div
            key={t.id}
            className={`pointer-events-auto px-4 py-3 rounded-xl shadow-lg border text-xs font-semibold flex items-center gap-2 ${
              t.type === 'success'
                ? 'bg-blue-950 text-white border-blue-700'
                : t.type === 'danger'
                  ? 'bg-rose-900 text-white border-rose-700'
                  : t.type === 'warning'
                    ? 'bg-amber-900 text-white border-amber-700'
                    : 'bg-slate-900 text-white border-slate-700'
            }`}
          >
            {t.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            <span>{t.text}</span>
          </div>
        ))}
      </div>

      {/* Quiet Footer (With bottom clearance for mobile thumb nav) */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 pt-5 pb-24 md:pb-5 text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <span className="font-semibold text-slate-700 dark:text-slate-200">ONECAMPUS (DEI Edition)</span>
            <span className="mx-2">·</span>
            <span>Dayalbagh Educational Institute, Agra</span>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => setShowLanding(true)} className="hover:text-blue-700 dark:hover:text-cyan-400">
              Role Hub
            </button>
            <button onClick={() => setActiveTab('about')} className="hover:text-blue-700 dark:hover:text-cyan-400">
              About &amp; Contact
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Thumb-Zone Navigation Bar */}
      <nav
        aria-label="Mobile navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 grid grid-cols-4 px-1"
      >
        {(
          [
            ['smartspace', 'Rooms', DoorOpen],
            ['peerlearn', 'Skills', Users],
            ['ecopulse', 'EcoMap', Leaf],
            ['about', 'About', Info]
          ] as const
        ).map(([key, label, Icon]) => {
          const isActive = activeTab === key;
          return (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 text-[11px] font-semibold whitespace-nowrap shrink-0 transition-colors ${
                isActive
                  ? 'text-blue-700 dark:text-cyan-400'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.2]' : ''}`} />
              <span>{label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
