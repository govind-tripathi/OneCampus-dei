import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  X,
  DoorOpen,
  Users,
  Flame,
  ArrowRight,
  CornerDownLeft
} from 'lucide-react';
import { Room, Skill, EcoReport } from './types';

interface Props {
  rooms: Room[];
  skills: Skill[];
  reports: EcoReport[];
  onSelectRoom: (roomId: number) => void;
  onSelectSkill: (skillId: string) => void;
  onSelectReport: (reportId: string) => void;
  globalQuery: string;
  setGlobalQuery: (q: string) => void;
}

export const GlobalSearchBar: React.FC<Props> = ({
  rooms,
  skills,
  reports,
  onSelectRoom,
  onSelectSkill,
  onSelectReport,
  globalQuery,
  setGlobalQuery
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        (e.key === '/' &&
          document.activeElement?.tagName !== 'INPUT' &&
          document.activeElement?.tagName !== 'TEXTAREA') ||
        ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k')
      ) {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
      }
      if (e.key === 'Escape') {
        setIsOpen(false);
        inputRef.current?.blur();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const q = globalQuery.trim().toLowerCase();

  const matchedRooms = q
    ? rooms
        .filter(
          r =>
            r.roomName.toLowerCase().includes(q) ||
            r.buildingName.toLowerCase().includes(q) ||
            r.code.toLowerCase().includes(q) ||
            r.roomType.toLowerCase().includes(q) ||
            r.currentActivity.toLowerCase().includes(q)
        )
        .slice(0, 4)
    : [];

  const matchedSkills = q
    ? skills
        .filter(
          s =>
            s.skillTitle.toLowerCase().includes(q) ||
            s.category.toLowerCase().includes(q) ||
            s.description.toLowerCase().includes(q) ||
            s.userName.toLowerCase().includes(q) ||
            s.userDepartment.toLowerCase().includes(q)
        )
        .slice(0, 4)
    : [];

  const matchedReports = q
    ? reports
        .filter(
          r =>
            r.location.toLowerCase().includes(q) ||
            r.issueCategory.toLowerCase().includes(q) ||
            r.description.toLowerCase().includes(q) ||
            r.userName.toLowerCase().includes(q)
        )
        .slice(0, 4)
    : [];

  const totalResults = matchedRooms.length + matchedSkills.length + matchedReports.length;

  return (
    <div ref={containerRef} className="relative flex-1 sm:max-w-sm">
      <div className="relative flex items-center">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          value={globalQuery}
          onChange={(e) => {
            setGlobalQuery(e.target.value);
            if (!isOpen) setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder="Search rooms, skills, reports..."
          className="w-full min-h-[42px] sm:min-h-0 pl-9 pr-12 py-2 sm:py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/70 dark:hover:bg-slate-700/80 focus:bg-white dark:focus:bg-slate-800 text-sm sm:text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 rounded-xl sm:rounded-lg border border-slate-200 dark:border-slate-700 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 transition-all"
        />

        <div className="absolute right-2.5 flex items-center gap-1">
          {globalQuery ? (
            <button
              onClick={() => {
                setGlobalQuery('');
                inputRef.current?.focus();
              }}
              className="p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <kbd className="hidden sm:inline-flex items-center text-[10px] font-mono text-slate-400 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded px-1.5 py-0.5">
              /
            </kbd>
          )}
        </div>
      </div>

      {isOpen && q.length > 0 && (
        <div className="absolute left-0 right-0 top-full mt-2 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-3 z-50 max-h-[70vh] overflow-y-auto">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 font-medium">
            <span>
              {totalResults > 0 ? `${totalResults} campus matches` : `No results for "${globalQuery}"`}
            </span>
            <span className="text-[10px]">Esc to close</span>
          </div>

          {totalResults === 0 ? (
            <div className="py-6 text-center text-xs text-slate-400">
              Try searching &ldquo;CAD&rdquo;, &ldquo;Python&rdquo;, &ldquo;Physics&rdquo;, &ldquo;Library&rdquo;, or &ldquo;Fan&rdquo;.
            </div>
          ) : (
            <div className="space-y-3">
              {matchedRooms.length > 0 && (
                <div>
                  <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 px-2 mb-1 flex items-center gap-1.5">
                    <DoorOpen className="w-3.5 h-3.5 text-emerald-600" />
                    <span>SmartSpace Rooms ({matchedRooms.length})</span>
                  </div>
                  <div className="space-y-1">
                    {matchedRooms.map(room => (
                      <button
                        key={room.roomId}
                        onClick={() => {
                          onSelectRoom(room.roomId);
                          setIsOpen(false);
                        }}
                        className="w-full text-left p-2 rounded-xl text-xs hover:bg-emerald-50/70 dark:hover:bg-emerald-950/40 transition-colors flex items-center justify-between group"
                      >
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-800 dark:text-slate-100 truncate">
                            {room.roomName} ·{' '}
                            <span className={room.status === 'Available' ? 'text-emerald-600' : 'text-rose-600'}>
                              {room.status}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 truncate">
                            {room.buildingName} · {room.capacity} seats
                          </div>
                        </div>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-emerald-600 shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {matchedSkills.length > 0 && (
                <div>
                  <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 px-2 mb-1 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-amber-500" />
                    <span>PeerLearn Skills ({matchedSkills.length})</span>
                  </div>
                  <div className="space-y-1">
                    {matchedSkills.map(skill => (
                      <button
                        key={skill.id}
                        onClick={() => {
                          onSelectSkill(skill.id);
                          setIsOpen(false);
                        }}
                        className="w-full text-left p-2 rounded-xl text-xs hover:bg-amber-50/70 dark:hover:bg-amber-950/30 transition-colors flex items-center justify-between group"
                      >
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-800 dark:text-slate-100 truncate">
                            {skill.skillTitle} · <span className="text-slate-500">{skill.category}</span>
                          </div>
                          <div className="text-[11px] text-slate-400 truncate">
                            Mentor: {skill.userName} ({skill.userDepartment})
                          </div>
                        </div>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-amber-600 shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {matchedReports.length > 0 && (
                <div>
                  <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 px-2 mb-1 flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-rose-500" />
                    <span>EcoPulse Reports ({matchedReports.length})</span>
                  </div>
                  <div className="space-y-1">
                    {matchedReports.map(rep => (
                      <button
                        key={rep.id}
                        onClick={() => {
                          onSelectReport(rep.id);
                          setIsOpen(false);
                        }}
                        className="w-full text-left p-2 rounded-xl text-xs hover:bg-rose-50/70 dark:hover:bg-rose-950/30 transition-colors flex items-center justify-between group"
                      >
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-800 dark:text-slate-100 truncate">
                            {rep.location} ·{' '}
                            <span className={rep.status === 'Open' ? 'text-rose-600' : 'text-emerald-600'}>
                              {rep.status}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 truncate">
                            {rep.issueCategory} · {rep.description}
                          </div>
                        </div>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-rose-600 shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
            <span>Select to jump directly to module</span>
            <span className="flex items-center gap-1">
              <CornerDownLeft className="w-3 h-3" /> Select
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
