import React, { useState, useEffect } from 'react';
import {
  MapPin,
  CheckCircle2,
  X,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Lock,
  Satellite,
  Map as MapLayerIcon,
  Maximize2,
  Minimize2,
  Navigation,
  Globe,
  Compass,
  Eye
} from 'lucide-react';
import {
  APIProvider,
  Map as GoogleMap,
  AdvancedMarker,
  Pin,
  InfoWindow,
  useAdvancedMarkerRef,
  useMap
} from '@vis.gl/react-google-maps';
import { EcoReport } from './types';
import { DEI_CAMPUS_CENTER, CAMPUS_ZONES_GEO } from './initialData';

interface Props {
  reports: EcoReport[];
  onResolveReport: (report: EcoReport) => void;
  isAdmin: boolean;
  gmpQuotaExceeded?: boolean;
}

const MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

// Map normalized SVG coords fallback to DEI Agra GPS if a report has no explicit lat/lng
function resolveLatLng(rep: EcoReport): { lat: number; lng: number } {
  if (typeof rep.lat === 'number' && typeof rep.lng === 'number') {
    return { lat: rep.lat, lng: rep.lng };
  }
  const lat = Number((27.2285 - ((rep.mapY || 210) / 420) * (27.2285 - 27.2245)).toFixed(6));
  const lng = Number((78.0095 + ((rep.mapX || 380) / 760) * (78.0155 - 78.0095)).toFixed(6));
  return { lat, lng };
}

function getCategoryColors(cat: EcoReport['issueCategory']) {
  if (cat === 'Water Leakage') return { bg: '#2563eb', border: '#1e3a8a' };
  if (cat === 'Cleanliness') return { bg: '#ea580c', border: '#9a3412' };
  if (cat === 'Green Initiative') return { bg: '#059669', border: '#065f46' };
  return { bg: '#f59e0b', border: '#b45309' };
}

const ReportMarkerWithWindow: React.FC<{
  report: EcoReport;
  isSelected: boolean;
  onSelect: (id: string) => void;
  onClose: () => void;
  isAdmin: boolean;
  onResolve: (rep: EcoReport) => void;
}> = ({ report, isSelected, onSelect, onClose, isAdmin, onResolve }) => {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const pos = resolveLatLng(report);
  const colors = getCategoryColors(report.issueCategory);
  const isResolved = report.status === 'Resolved';

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={pos}
        onClick={() => onSelect(report.id)}
        title={`${report.location} (${report.status})`}
      >
        <Pin
          background={isResolved ? '#10b981' : colors.bg}
          borderColor={isResolved ? '#065f46' : colors.border}
          glyphColor="#ffffff"
          scale={isSelected ? 1.25 : 1.0}
        />
      </AdvancedMarker>

      {isSelected && marker && (
        <InfoWindow anchor={marker} maxWidth={290} onCloseClick={onClose}>
          <div className="text-slate-900 space-y-2 p-0.5 max-w-[260px]">
            <div className="flex items-center justify-between gap-2 text-[11px] font-bold">
              <span className="text-blue-800">{report.issueCategory}</span>
              <span className={report.status === 'Open' ? 'text-rose-600' : 'text-emerald-600'}>
                {report.status}
              </span>
            </div>
            <div className="font-bold text-xs text-slate-900 leading-snug">{report.location}</div>
            {report.imageData && (
              <img
                src={report.imageData}
                alt={report.location}
                className="w-full h-24 object-cover rounded-lg border border-slate-200"
              />
            )}
            {report.afterImageData && (
              <div className="space-y-1">
                <div className="text-[10px] font-bold text-emerald-700">After Fix:</div>
                <img
                  src={report.afterImageData}
                  alt="Resolved verification"
                  className="w-full h-20 object-cover rounded-lg border border-emerald-300"
                />
              </div>
            )}
            <p className="text-[11px] text-slate-600 leading-relaxed">{report.description}</p>
            <div className="text-[10px] font-mono text-slate-400">
              {pos.lat.toFixed(5)}, {pos.lng.toFixed(5)} · By {report.userName}
            </div>
            {report.status === 'Open' && isAdmin && (
              <button
                type="button"
                onClick={() => onResolve(report)}
                className="w-full py-1.5 px-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-[11px] font-bold transition-colors"
              >
                Mark Resolved (+10 Karma)
              </button>
            )}
          </div>
        </InfoWindow>
      )}
    </>
  );
};

const MapCameraController: React.FC<{
  targetCenter: { lat: number; lng: number; zoom?: number } | null;
  streetViewRequestSeq: number;
  onStreetViewStatus: (active: boolean, note?: string) => void;
}> = ({ targetCenter, streetViewRequestSeq, onStreetViewStatus }) => {
  const map = useMap();

  useEffect(() => {
    if (!map || !targetCenter) return;
    const sv = map.getStreetView();
    if (sv && sv.getVisible()) {
      sv.setVisible(false);
      onStreetViewStatus(false);
    }
    map.panTo({ lat: targetCenter.lat, lng: targetCenter.lng });
    if (targetCenter.zoom) {
      map.setZoom(targetCenter.zoom);
    } else if ((map.getZoom() || 17) < 17) {
      map.setZoom(18);
    }
  }, [map, targetCenter]);

  useEffect(() => {
    if (!map || streetViewRequestSeq === 0) return;
    const sv = map.getStreetView();
    if (!sv) return;

    if (sv.getVisible()) {
      sv.setVisible(false);
      onStreetViewStatus(false);
      return;
    }

    const gmaps = (window as unknown as {
      google?: {
        maps?: {
          StreetViewService?: new () => {
            getPanorama: (
              req: { location: { lat: number; lng: number }; radius: number },
              cb: (data: { location?: { latLng?: unknown } } | null, status: string) => void
            ) => void;
          };
        };
      };
    }).google?.maps;

    const currentCenter = map.getCenter();
    const lookupCenter = currentCenter
      ? { lat: currentCenter.lat(), lng: currentCenter.lng() }
      : DEI_CAMPUS_CENTER;

    if (gmaps?.StreetViewService) {
      const svService = new gmaps.StreetViewService();
      svService.getPanorama({ location: lookupCenter, radius: 500 }, (data, status) => {
        if (status === 'OK' && data?.location?.latLng) {
          sv.setPosition(data.location.latLng as never);
          sv.setPov({ heading: 34, pitch: 5 });
          sv.setVisible(true);
          onStreetViewStatus(true);
        } else {
          // Try Dayalbagh Road entrance coordinates nearby
          svService.getPanorama({ location: DEI_CAMPUS_CENTER, radius: 1500 }, (fallbackData, fallbackStatus) => {
            if (fallbackStatus === 'OK' && fallbackData?.location?.latLng) {
              sv.setPosition(fallbackData.location.latLng as never);
              sv.setPov({ heading: 34, pitch: 5 });
              sv.setVisible(true);
              onStreetViewStatus(true, 'Showing nearest DEI Agra 360° Street View road.');
            } else {
              onStreetViewStatus(false, 'Street View panorama unavailable here. Drag the yellow Pegman icon onto a nearby blue road.');
            }
          });
        }
      });
    } else {
      sv.setPosition(lookupCenter);
      sv.setVisible(true);
      onStreetViewStatus(true);
    }
  }, [map, streetViewRequestSeq]);

  return null;
};

export const EcoPulseMap: React.FC<Props> = ({
  reports,
  onResolveReport,
  isAdmin,
  gmpQuotaExceeded = false
}) => {
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'Open' | 'Resolved'>('all');
  const [selectedPinId, setSelectedPinId] = useState<string | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const canRenderGoogleMaps = Boolean(MAPS_API_KEY) && !gmpQuotaExceeded;
  const [viewMode, setViewMode] = useState<'hybrid' | 'satellite' | 'roadmap' | 'svg'>(
    canRenderGoogleMaps ? 'hybrid' : 'svg'
  );
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [panTarget, setPanTarget] = useState<{ lat: number; lng: number; zoom?: number; seq: number } | null>(null);
  const [activeZoneLabel, setActiveZoneLabel] = useState<string>('DEI Campus');
  const [userPosition, setUserPosition] = useState<{ lat: number; lng: number } | null>(null);
  const [streetViewReqSeq, setStreetViewReqSeq] = useState<number>(0);
  const [streetViewActive, setStreetViewActive] = useState<boolean>(false);
  const [streetViewNote, setStreetViewNote] = useState<string | null>(null);

  const handleZoomIn = () => setZoomLevel((prev) => Math.min(2.0, +(prev + 0.25).toFixed(2)));
  const handleZoomOut = () => setZoomLevel((prev) => Math.max(0.75, +(prev - 0.25).toFixed(2)));
  const handleResetZoom = () => setZoomLevel(1);

  const handleLocateMe = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const next = {
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6))
        };
        setUserPosition(next);
        setActiveZoneLabel('My GPS');
        setPanTarget({ ...next, zoom: 19, seq: Date.now() });
      },
      () => {
        setActiveZoneLabel('DEI Campus');
        setPanTarget({ ...DEI_CAMPUS_CENTER, zoom: 17, seq: Date.now() });
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleCenterDei = () => {
    setActiveZoneLabel('DEI Campus');
    setPanTarget({ ...DEI_CAMPUS_CENTER, zoom: 17, seq: Date.now() });
  };

  const handleFlyToZone = (label: string, lat: number, lng: number) => {
    setActiveZoneLabel(label);
    if (viewMode === 'svg' && canRenderGoogleMaps) {
      setViewMode('hybrid');
    }
    setPanTarget({ lat, lng, zoom: 18, seq: Date.now() });
  };

  const filteredPins = reports.filter((rep) => {
    const matchCat = categoryFilter === 'all' || rep.issueCategory === categoryFilter;
    const matchStat = statusFilter === 'all' || rep.status === statusFilter;
    return matchCat && matchStat;
  });

  const selectedPin = reports.find((r) => r.id === selectedPinId) || null;
  const openCount = reports.filter((p) => p.status === 'Open').length;
  const resolvedCount = reports.filter((p) => p.status === 'Resolved').length;

  const activeGoogleMapMode = canRenderGoogleMaps && viewMode !== 'svg';

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transition-colors">
      {/* Header */}
      <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/40 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-0.5">
            <span className="font-semibold text-blue-700 dark:text-cyan-400 flex items-center gap-1">
              <Satellite className="w-3.5 h-3.5" />
              DEI Agra Google Earth · Satellite &amp; Street View
            </span>
            <span aria-hidden="true">·</span>
            <span>Real-time campus coordinates &amp; issue pins</span>
          </div>
          <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base sm:text-lg font-heading">
            EcoPulse Live Campus Geo-Map
          </h3>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-3 text-xs font-mono tabular-nums mr-1">
            <span className="text-rose-600 dark:text-rose-400 font-bold">{openCount} Open</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold">{resolvedCount} Resolved</span>
          </div>

          {canRenderGoogleMaps && (
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg text-[11px] overflow-x-auto max-w-full">
              <button
                type="button"
                onClick={() => setViewMode('hybrid')}
                className={`px-2.5 py-1 rounded-md font-semibold flex items-center gap-1 whitespace-nowrap transition-colors ${
                  viewMode === 'hybrid'
                    ? 'bg-blue-700 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <Globe className="w-3 h-3" />
                <span>Earth + Labels</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('satellite')}
                className={`px-2 py-1 rounded-md font-semibold flex items-center gap-1 whitespace-nowrap transition-colors ${
                  viewMode === 'satellite'
                    ? 'bg-blue-700 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <Satellite className="w-3 h-3" />
                <span>Pure Earth</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('roadmap')}
                className={`px-2 py-1 rounded-md font-semibold flex items-center gap-1 whitespace-nowrap transition-colors ${
                  viewMode === 'roadmap'
                    ? 'bg-blue-700 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <MapLayerIcon className="w-3 h-3" />
                <span>Road Map</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('svg')}
                className={`px-2 py-1 rounded-md font-semibold flex items-center gap-1 whitespace-nowrap transition-colors ${
                  viewMode === 'svg'
                    ? 'bg-blue-700 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <MapPin className="w-3 h-3" />
                <span>Blueprint</span>
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={() => setIsExpanded((prev) => !prev)}
            className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-1"
            title={isExpanded ? 'Compact map size' : 'Expand map size'}
          >
            {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span>{isExpanded ? 'Compact' : 'Expand'}</span>
          </button>
        </div>
      </div>

      {/* Filters & Live Earth Controls */}
      <div className="px-4 sm:px-5 py-2.5 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 max-w-full scrollbar-thin">
          {['all', 'Electrical/Fan', 'Water Leakage', 'Cleanliness', 'Green Initiative'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap shrink-0 transition-colors ${
                categoryFilter === cat
                  ? 'bg-blue-800 text-white font-semibold'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat === 'all' ? 'All Categories' : cat}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {activeGoogleMapMode && (
            <>
              <button
                type="button"
                onClick={() => {
                  setStreetViewNote(null);
                  setStreetViewReqSeq((s) => s + 1);
                }}
                className={`px-2.5 py-1 rounded-lg border text-[11px] font-semibold flex items-center gap-1 transition-colors ${
                  streetViewActive
                    ? 'bg-amber-500 border-amber-500 text-slate-950'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
                title="Launch 360° Google Street View panorama near DEI Campus"
              >
                <Eye className="w-3 h-3" />
                <span>{streetViewActive ? 'Exit Street View' : '360° Street View'}</span>
              </button>
              <button
                type="button"
                onClick={handleCenterDei}
                className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-semibold flex items-center gap-1 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              >
                <Compass className="w-3 h-3" />
                <span>DEI Campus</span>
              </button>
              <button
                type="button"
                onClick={handleLocateMe}
                className="px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-cyan-300 text-[11px] font-semibold flex items-center gap-1 hover:bg-blue-100 transition-colors"
              >
                <Navigation className="w-3 h-3" />
                <span>My GPS</span>
              </button>
            </>
          )}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg">
            {(['all', 'Open', 'Resolved'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2 py-1 rounded-md text-[11px] font-medium transition-colors ${
                  statusFilter === st
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 font-semibold'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {st === 'all' ? 'All' : st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Campus Zone Fly-To Bar */}
      {canRenderGoogleMaps && (
        <div className="px-4 sm:px-5 py-2 bg-slate-50/70 dark:bg-slate-950/40 border-b border-slate-100 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto scrollbar-thin text-[11px]">
          <span className="font-semibold text-slate-500 dark:text-slate-400 shrink-0 mr-1">Fly To:</span>
          <button
            type="button"
            onClick={handleCenterDei}
            className={`px-2.5 py-1 rounded-lg whitespace-nowrap shrink-0 font-semibold transition-colors ${
              activeZoneLabel === 'DEI Campus'
                ? 'bg-blue-700 text-white'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
            }`}
          >
            DEI Overview
          </button>
          {CAMPUS_ZONES_GEO.map((zone) => {
            const shortName = zone.label
              .replace('Faculty of ', '')
              .replace(' & Botanical Garden', '')
              .replace(' (Dayal Hall)', '')
              .replace(' & Solar Pavilion', '');
            return (
              <button
                key={zone.label}
                type="button"
                onClick={() => handleFlyToZone(zone.label, zone.lat, zone.lng)}
                className={`px-2.5 py-1 rounded-lg whitespace-nowrap shrink-0 font-semibold transition-colors ${
                  activeZoneLabel === zone.label
                    ? 'bg-blue-700 text-white'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                }`}
              >
                {shortName}
              </button>
            );
          })}
        </div>
      )}

      {streetViewNote && (
        <div className="px-4 py-2 bg-amber-50 dark:bg-amber-950/50 border-b border-amber-200 dark:border-amber-800 text-[11px] text-amber-900 dark:text-amber-200 flex items-center justify-between gap-2">
          <span>{streetViewNote}</span>
          <button type="button" onClick={() => setStreetViewNote(null)} className="text-amber-700 dark:text-amber-300 font-bold">
            Dismiss
          </button>
        </div>
      )}

      {/* Map Canvas (Google Earth Satellite Map OR Interactive SVG Blueprint) */}
      <div className="p-3 sm:p-4 bg-slate-50/50 dark:bg-slate-950/40 relative">
        {activeGoogleMapMode ? (
          <div
            className={`w-full rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden transition-all duration-300 ${
              isExpanded ? 'h-[460px] sm:h-[540px]' : 'h-72 sm:h-[360px]'
            }`}
          >
            <APIProvider apiKey={MAPS_API_KEY} libraries={['marker']}>
              <GoogleMap
                mapId="DEMO_MAP_ID"
                defaultCenter={DEI_CAMPUS_CENTER}
                defaultZoom={17}
                mapTypeId={viewMode === 'roadmap' ? 'roadmap' : viewMode === 'satellite' ? 'satellite' : 'hybrid'}
                mapTypeControl={true}
                streetViewControl={true}
                rotateControl={true}
                fullscreenControl={true}
                gestureHandling="greedy"
                internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                style={{ width: '100%', height: '100%' }}
                className="w-full h-full"
              >
                <MapCameraController
                  targetCenter={panTarget ? { lat: panTarget.lat, lng: panTarget.lng, zoom: panTarget.zoom } : null}
                  streetViewRequestSeq={streetViewReqSeq}
                  onStreetViewStatus={(active, note) => {
                    setStreetViewActive(active);
                    if (note) setStreetViewNote(note);
                  }}
                />

                {filteredPins.map((pin) => (
                  <ReportMarkerWithWindow
                    key={pin.id}
                    report={pin}
                    isSelected={selectedPinId === pin.id}
                    onSelect={(id) => setSelectedPinId(id)}
                    onClose={() => setSelectedPinId(null)}
                    isAdmin={isAdmin}
                    onResolve={onResolveReport}
                  />
                ))}

                {userPosition && (
                  <AdvancedMarker position={userPosition} title="Your Live Standing Location">
                    <div className="w-4 h-4 rounded-full bg-cyan-400 border-2 border-white shadow-lg ring-4 ring-blue-500/40" />
                  </AdvancedMarker>
                )}
              </GoogleMap>
            </APIProvider>
          </div>
        ) : (
          <div className="w-full bg-white dark:bg-slate-900 rounded-xl p-3 border border-slate-200 dark:border-slate-800 relative overflow-hidden">
            {/* Floating Zoom Controls */}
            <div className="absolute top-3 right-3 z-20 flex items-center gap-1 bg-white/95 dark:bg-slate-800/95 backdrop-blur-md px-2 py-1 rounded-xl border border-slate-200 dark:border-slate-700 shadow-md text-xs">
              <button
                onClick={handleZoomOut}
                disabled={zoomLevel <= 0.75}
                className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-35"
                title="Zoom Out"
                aria-label="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="px-1.5 font-mono text-[11px] font-bold text-slate-700 dark:text-slate-200 min-w-[38px] text-center tabular-nums">
                {Math.round(zoomLevel * 100)}%
              </span>
              <button
                onClick={handleZoomIn}
                disabled={zoomLevel >= 2.0}
                className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-35"
                title="Zoom In"
                aria-label="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              {zoomLevel !== 1 && (
                <button
                  onClick={handleResetZoom}
                  className="p-1.5 rounded-lg text-blue-700 dark:text-cyan-400 hover:bg-blue-50 dark:hover:bg-blue-950/60"
                  title="Reset Zoom"
                  aria-label="Reset Zoom"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className={`overflow-auto max-w-full rounded-lg scrollbar-thin ${isExpanded ? 'max-h-[460px]' : 'max-h-72'}`}>
              <div className="flex justify-center" style={{ minWidth: `${Math.round(580 * zoomLevel)}px` }}>
                <svg
                  viewBox="0 0 760 420"
                  className="h-auto select-none transition-all duration-200"
                  style={{
                    width: `${100 * zoomLevel}%`,
                    maxWidth: zoomLevel <= 1 ? '100%' : 'none'
                  }}
                >
                  <defs>
                    <pattern id="campusLawnMap" width="30" height="30" patternUnits="userSpaceOnUse">
                      <circle cx="15" cy="15" r="1" fill="#2563eb" opacity="0.14" />
                    </pattern>
                  </defs>

                  <rect width="100%" height="100%" fill="#f8fafc" className="dark:fill-slate-900" rx="8" />
                  <rect width="100%" height="100%" fill="url(#campusLawnMap)" rx="8" />

                  <path d="M 50 210 Q 380 200 710 210" stroke="#e2e8f0" className="dark:stroke-slate-800" strokeWidth="24" strokeLinecap="round" fill="none" />
                  <path d="M 380 40 L 380 380" stroke="#e2e8f0" className="dark:stroke-slate-800" strokeWidth="20" strokeLinecap="round" fill="none" />
                  <text x="380" y="214" textAnchor="middle" fill="#94a3b8" fontSize="10" fontWeight="bold" letterSpacing="2">
                    DAYALBAGH MEMORIAL AVENUE
                  </text>

                  <rect x="70" y="50" width="220" height="120" fill="#e2e8f0" stroke="#cbd5e1" className="dark:fill-slate-800 dark:stroke-slate-700" strokeWidth="1.5" rx="8" />
                  <text x="180" y="105" textAnchor="middle" fill="#334155" className="dark:fill-slate-300" fontSize="12" fontWeight="bold">Faculty of Engineering</text>
                  <text x="180" y="122" textAnchor="middle" fill="#64748b" fontSize="9">Mechanical · Electrical · CAD Labs</text>

                  <rect x="310" y="50" width="180" height="120" fill="#dbeafe" stroke="#93c5fd" className="dark:fill-blue-950/40 dark:stroke-blue-800" strokeWidth="1.5" rx="8" />
                  <text x="400" y="105" textAnchor="middle" fill="#1e3a8a" className="dark:fill-blue-300" fontSize="12" fontWeight="bold">Faculty of Science</text>
                  <text x="400" y="122" textAnchor="middle" fill="#2563eb" fontSize="9">Physics &amp; Botanical Gardens</text>

                  <rect x="510" y="50" width="200" height="120" fill="#e2e8f0" stroke="#cbd5e1" className="dark:fill-slate-800 dark:stroke-slate-700" strokeWidth="1.5" rx="8" />
                  <text x="610" y="105" textAnchor="middle" fill="#334155" className="dark:fill-slate-300" fontSize="12" fontWeight="bold">Central Library</text>
                  <text x="610" y="122" textAnchor="middle" fill="#64748b" fontSize="9">Silent Reading &amp; Digital Archive</text>

                  <rect x="70" y="260" width="160" height="110" fill="#fef3c7" stroke="#fde68a" className="dark:fill-amber-950/30 dark:stroke-amber-800" strokeWidth="1.5" rx="8" />
                  <text x="150" y="310" textAnchor="middle" fill="#78350f" className="dark:fill-amber-300" fontSize="11" fontWeight="bold">DEI Girls Hostel</text>
                  <text x="150" y="325" textAnchor="middle" fill="#92400e" fontSize="9">Solar Thermal System</text>

                  <rect x="250" y="260" width="210" height="110" fill="#f1f5f9" stroke="#cbd5e1" className="dark:fill-slate-800 dark:stroke-slate-700" strokeWidth="1.5" rx="8" />
                  <text x="355" y="310" textAnchor="middle" fill="#334155" className="dark:fill-slate-300" fontSize="11" fontWeight="bold">DEI Canteen &amp; Pavilion</text>
                  <text x="355" y="325" textAnchor="middle" fill="#64748b" fontSize="9">Composting &amp; Solar Hub</text>

                  <rect x="480" y="260" width="230" height="110" fill="#e2e8f0" stroke="#cbd5e1" className="dark:fill-slate-800 dark:stroke-slate-700" strokeWidth="1.5" rx="8" />
                  <text x="595" y="310" textAnchor="middle" fill="#334155" className="dark:fill-slate-300" fontSize="11" fontWeight="bold">Seminar Hall Complex</text>
                  <text x="595" y="325" textAnchor="middle" fill="#64748b" fontSize="9">Dayal Hall Auditorium</text>

                  {filteredPins.map((pin) => {
                    const isOpen = pin.status === 'Open';
                    const isSelected = selectedPin?.id === pin.id;
                    const { bg } = getCategoryColors(pin.issueCategory);

                    return (
                      <g
                        key={pin.id}
                        onClick={() => setSelectedPinId(pin.id)}
                        className="cursor-pointer group"
                        transform={`translate(${pin.mapX || 380}, ${pin.mapY || 210})`}
                      >
                        {isOpen && (
                          <circle cx="0" cy="0" r="14" fill={bg} opacity="0.25" className="animate-ping-small" />
                        )}
                        <circle
                          cx="0"
                          cy="0"
                          r={isSelected ? '13' : '10'}
                          fill={bg}
                          stroke="#ffffff"
                          strokeWidth="2.5"
                        />
                        <circle cx="0" cy="0" r="3.5" fill="#ffffff" />
                        <rect
                          x="-48"
                          y="14"
                          width="96"
                          height="18"
                          fill="#0f172a"
                          rx="4"
                          opacity={isSelected ? '1' : '0.85'}
                        />
                        <text
                          x="0"
                          y="26"
                          textAnchor="middle"
                          fill="#ffffff"
                          fontSize="8.5"
                          fontWeight="bold"
                        >
                          {pin.issueCategory.split('/')[0]} · {pin.status}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>
            </div>

            {selectedPin && (
              <div className="mt-3 sm:mt-0 sm:absolute sm:bottom-3 sm:right-3 sm:w-80 bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xl z-20 space-y-2.5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                      {selectedPin.issueCategory} ·{' '}
                      <span className={selectedPin.status === 'Open' ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'}>
                        {selectedPin.status}
                      </span>
                    </div>
                    <h4 className="font-bold text-slate-900 dark:text-slate-100 text-sm mt-0.5">{selectedPin.location}</h4>
                  </div>
                  <button
                    onClick={() => setSelectedPinId(null)}
                    className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {selectedPin.imageData && (
                  <img
                    src={selectedPin.imageData}
                    alt={selectedPin.location}
                    className="w-full h-28 object-cover rounded-xl border border-slate-200 dark:border-slate-700"
                  />
                )}

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {selectedPin.description}
                </p>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <span>By {selectedPin.userName}</span>
                  <span>{selectedPin.createdAtText}</span>
                </div>

                {selectedPin.status === 'Open' && (
                  isAdmin ? (
                    <button
                      onClick={() => onResolveReport(selectedPin)}
                      className="w-full py-2 px-3 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Mark Resolved (+10 Karma Points)</span>
                    </button>
                  ) : (
                    <div className="text-[11px] text-slate-400 flex items-center gap-1.5 pt-1">
                      <Lock className="w-3 h-3" />
                      <span>Awaiting verified Administrator resolution</span>
                    </div>
                  )
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Legend Footer */}
      <div className="px-4 py-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
        <div className="flex flex-wrap items-center gap-3.5">
          <span className="font-semibold text-slate-700 dark:text-slate-200">Legend:</span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Electrical
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600" /> Water Leakage
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500" /> Cleanliness
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Green / Resolved
          </span>
        </div>
        <span>Tap any pin for live photo &amp; GPS details</span>
      </div>
    </div>
  );
};
