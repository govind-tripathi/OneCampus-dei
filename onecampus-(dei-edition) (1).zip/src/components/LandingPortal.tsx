import React, { useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  ShieldCheck,
  Compass,
  ArrowRight,
  DoorOpen,
  Users,
  Leaf,
  Lock,
  CheckCircle2,
  Sun,
  Moon,
  MapPin,
  Camera
} from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { UserRole } from '../types';
import heroBannerImg from '../assets/images/hero_campus_banner_1794583007730.jpg';
import smartspacePosterImg from '../assets/images/smartspace_poster_1794583007972.jpg';
import ecopulsePosterImg from '../assets/images/ecopulse_campus_poster_1794583008419.jpg';

interface Props {
  onSelectRoleSignIn: (roleIntent: UserRole) => Promise<void>;
  onContinueAsVisitor: (initialTab?: 'smartspace' | 'peerlearn' | 'ecopulse') => void;
  onOpenAbout: () => void;
  isSigningIn: boolean;
  stats: {
    totalRooms: number;
    availableRooms: number;
    skillsCount: number;
    openReports: number;
  };
  isDarkMode: boolean;
  onToggleDark: () => void;
  adminEmail: string;
}

export const LandingPortal: React.FC<Props> = ({
  onSelectRoleSignIn,
  onContinueAsVisitor,
  onOpenAbout,
  isSigningIn,
  stats,
  isDarkMode,
  onToggleDark,
  adminEmail
}) => {
  const [activeIntent, setActiveIntent] = useState<string | null>(null);

  const handleRoleAction = async (role: UserRole) => {
    setActiveIntent(role);
    try {
      await onSelectRoleSignIn(role);
    } finally {
      setActiveIntent(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors">
      {/* Clean 3-Zone Top Bar */}
      <header className="border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-6">
          <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
            <BrandLogo className="w-8 h-8" />
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg font-extrabold tracking-tight font-heading text-slate-900 dark:text-white">
                ONECAMPUS
              </span>
              <span className="hidden sm:inline text-[11px] font-semibold text-blue-700 dark:text-cyan-400">
                DEI Agra
              </span>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600 dark:text-slate-400">
            <button onClick={() => onContinueAsVisitor('smartspace')} className="hover:text-blue-700 dark:hover:text-cyan-400 whitespace-nowrap shrink-0 transition-colors">
              Explore Campus
            </button>
            <button onClick={() => onContinueAsVisitor('ecopulse')} className="hover:text-blue-700 dark:hover:text-cyan-400 whitespace-nowrap shrink-0 transition-colors">
              Google Earth Map
            </button>
            <button onClick={onOpenAbout} className="hover:text-blue-700 dark:hover:text-cyan-400 whitespace-nowrap shrink-0 transition-colors">
              About &amp; Contact
            </button>
          </nav>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              onClick={onToggleDark}
              className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Toggle color theme"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              onClick={() => onContinueAsVisitor('smartspace')}
              className="min-h-[40px] sm:min-h-0 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-blue-800 to-indigo-700 hover:from-blue-900 hover:to-indigo-800 rounded-lg transition-all shadow-xs whitespace-nowrap shrink-0"
            >
              Open Portal
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 sm:px-6 py-7 sm:py-12 space-y-12">
        {/* Hero Banner + Royal Navy Atmosphere */}
        <section className="relative overflow-hidden rounded-3xl border border-blue-900/20 dark:border-blue-800/40 bg-gradient-to-br from-slate-950 via-blue-950 to-indigo-950 text-white shadow-xl">
          {/* Subtle animated ambient aura */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 -right-20 w-80 h-80 rounded-full bg-cyan-500/20 blur-3xl animate-aura"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -bottom-24 -left-16 w-72 h-72 rounded-full bg-indigo-500/25 blur-3xl animate-aura"
          />

          <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 p-6 sm:p-8 lg:p-10 items-center">
            <div className="lg:col-span-6 space-y-5 animate-welcome">
              <p className="text-xs font-semibold tracking-wider text-cyan-300 uppercase">
                Dayalbagh Educational Institute · Smart Utility Portal
              </p>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-heading text-white leading-[1.12] [text-wrap:balance]">
                Classrooms, Peer Skills &amp; Campus Care in One Live Portal
              </h1>
              <p className="text-sm sm:text-base text-blue-100/85 leading-relaxed max-w-xl">
                Built for DEI Agra with real-time SmartSpace booking, PeerLearn skill barter, live in-browser camera reporting, and Satellite Google Maps GPS tagging.
              </p>
              <div className="grid grid-cols-1 sm:flex sm:flex-wrap items-center gap-3 pt-1">
                <button
                  onClick={() => handleRoleAction('student')}
                  disabled={isSigningIn}
                  className="min-h-[46px] sm:min-h-0 px-5 py-3 sm:py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-sm font-bold flex items-center justify-center gap-2 transition-colors disabled:opacity-60 whitespace-nowrap shadow-md"
                >
                  <span>Sign in with Google</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onContinueAsVisitor('smartspace')}
                  className="min-h-[46px] sm:min-h-0 px-5 py-3 sm:py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/20 text-sm font-semibold transition-colors whitespace-nowrap backdrop-blur-xs"
                >
                  Explore as Visitor
                </button>
                <button
                  onClick={() => onContinueAsVisitor('ecopulse')}
                  className="min-h-[46px] sm:min-h-0 px-4 py-3 sm:py-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-400/30 text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
                >
                  <MapPin className="w-4 h-4" />
                  <span>Google Earth View</span>
                </button>
              </div>
            </div>

            {/* Hero Visual Campus Banner Image */}
            <div className="lg:col-span-6 animate-welcome-delay">
              <div className="relative rounded-2xl overflow-hidden border border-white/15 shadow-2xl aspect-[16/10] bg-slate-900">
                <img
                  src={heroBannerImg}
                  alt="ONECAMPUS DEI Agra smart campus digital architecture"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent" />
                <div className="absolute bottom-3 left-3 right-3 grid grid-cols-4 gap-2 text-center">
                  <div className="bg-slate-950/75 backdrop-blur-md border border-white/10 rounded-xl p-2">
                    <div className="text-sm sm:text-lg font-bold font-mono tabular-nums text-emerald-400">
                      {stats.availableRooms}/{stats.totalRooms}
                    </div>
                    <div className="text-[10px] text-slate-300 truncate">Rooms Free</div>
                  </div>
                  <div className="bg-slate-950/75 backdrop-blur-md border border-white/10 rounded-xl p-2">
                    <div className="text-sm sm:text-lg font-bold font-mono tabular-nums text-amber-300">
                      {stats.skillsCount}
                    </div>
                    <div className="text-[10px] text-slate-300 truncate">Peer Skills</div>
                  </div>
                  <div className="bg-slate-950/75 backdrop-blur-md border border-white/10 rounded-xl p-2">
                    <div className="text-sm sm:text-lg font-bold font-mono tabular-nums text-cyan-300">
                      {stats.openReports}
                    </div>
                    <div className="text-[10px] text-slate-300 truncate">Open Pins</div>
                  </div>
                  <div className="bg-slate-950/75 backdrop-blur-md border border-white/10 rounded-xl p-2">
                    <div className="text-xs sm:text-sm font-bold text-white pt-0.5 truncate">
                      Satellite GPS
                    </div>
                    <div className="text-[10px] text-cyan-300 truncate">Maps Ready</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Visual Posters Highlight Row */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="group bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs hover:border-blue-400 dark:hover:border-blue-700 transition-colors flex flex-col sm:flex-row">
            <div className="sm:w-48 aspect-[4/3] sm:aspect-auto shrink-0 overflow-hidden bg-slate-900">
              <img
                src={smartspacePosterImg}
                alt="SmartSpace blueprint and clash detection showcase"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
            <div className="p-5 flex flex-col justify-between gap-3">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-blue-700 dark:text-cyan-400">
                  <DoorOpen className="w-4 h-4" />
                  <span>SmartSpace &amp; PeerLearn</span>
                </div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white font-heading">
                  Zero-Clash Room Booking &amp; Cashless Skill Barter
                </h2>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  Browse 29 synced rooms across 6 DEI blocks, manage active reservations, and exchange 1-credit mentoring sessions with ratings.
                </p>
              </div>
              <button
                onClick={() => onContinueAsVisitor('smartspace')}
                className="text-xs font-bold text-blue-700 dark:text-cyan-400 hover:underline flex items-center gap-1 self-start"
              >
                <span>Open SmartSpace</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="group bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs hover:border-cyan-500 dark:hover:border-cyan-700 transition-colors flex flex-col sm:flex-row">
            <div className="sm:w-48 aspect-[4/3] sm:aspect-auto shrink-0 overflow-hidden bg-slate-900">
              <img
                src={ecopulsePosterImg}
                alt="EcoPulse live camera and satellite map reporting"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
            <div className="p-5 flex flex-col justify-between gap-3">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 dark:text-cyan-400">
                  <Camera className="w-4 h-4" />
                  <span>EcoPulse Live Camera + Satellite Map</span>
                </div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white font-heading">
                  Snap Live Photos &amp; Pin Exact Campus GPS Coordinates
                </h2>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  Capture campus issues straight from your browser viewfinder, auto-tag your GPS standing spot, and track before/after fixes on Google Satellite Maps.
                </p>
              </div>
              <button
                onClick={() => onContinueAsVisitor('ecopulse')}
                className="text-xs font-bold text-indigo-700 dark:text-cyan-400 hover:underline flex items-center gap-1 self-start"
              >
                <MapPin className="w-3.5 h-3.5" />
                <span>Inspect Campus Satellite Map</span>
              </button>
            </div>
          </div>
        </section>

        {/* 4 Role Access Cards */}
        <section className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold font-heading text-slate-900 dark:text-white">
                Select Your Portal Access
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                Sign in with Google for Student, Faculty, or Owner-Locked Admin capabilities, or explore freely as a Visitor.
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <CheckCircle2 className="w-4 h-4 text-blue-700 dark:text-cyan-400" />
              <span>Real-time Firebase Cloud Sync</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Role 1: Student */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between gap-4 hover:border-blue-500 dark:hover:border-blue-600 transition-colors">
              <div className="space-y-2.5">
                <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/70 text-blue-700 dark:text-cyan-400 flex items-center justify-center">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white font-heading">Student</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Reserve study slots with clash checking, barter skills with 5 welcome credits, and submit live camera + GPS EcoPulse tickets.
                </p>
              </div>
              <button
                onClick={() => handleRoleAction('student')}
                disabled={isSigningIn}
                className="w-full min-h-[44px] sm:min-h-0 py-2.5 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors disabled:opacity-60"
              >
                <span>{activeIntent === 'student' ? 'Signing in...' : 'Student Login'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Role 2: Faculty */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between gap-4 hover:border-indigo-500 dark:hover:border-indigo-600 transition-colors">
              <div className="space-y-2.5">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/70 text-indigo-700 dark:text-indigo-300 flex items-center justify-center">
                  <BookOpen className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white font-heading">Faculty</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Update live classroom &amp; lab occupancy, reserve seminar halls, export analytics CSVs, and guide peer sessions.
                </p>
              </div>
              <button
                onClick={() => handleRoleAction('faculty')}
                disabled={isSigningIn}
                className="w-full min-h-[44px] sm:min-h-0 py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 dark:hover:bg-indigo-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors disabled:opacity-60"
              >
                <span>{activeIntent === 'faculty' ? 'Signing in...' : 'Faculty Login'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Role 3: Administrator (Owner-Locked) */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between gap-4 hover:border-amber-400 dark:hover:border-amber-700 transition-colors">
              <div className="space-y-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-base font-bold text-slate-900 dark:text-white font-heading">Administrator</h3>
                  <Lock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Protected governance ({adminEmail}). Resolve EcoPulse tickets with after-fix photos (+10 Karma) &amp; sync campus records.
                </p>
              </div>
              <button
                onClick={() => handleRoleAction('admin')}
                disabled={isSigningIn}
                className="w-full min-h-[44px] sm:min-h-0 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors disabled:opacity-60"
              >
                <span>{activeIntent === 'admin' ? 'Verifying...' : 'Admin Google Auth'}</span>
                <Lock className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Role 4: Visitor */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between gap-4 hover:border-cyan-500 dark:hover:border-cyan-700 transition-colors">
              <div className="space-y-2.5">
                <div className="w-10 h-10 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-400 flex items-center justify-center">
                  <Compass className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white font-heading">Visitor</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Read-only exploration for evaluators, faculty, and guests. Inspect floor plans, live analytics charts, skills, and Satellite map pins.
                </p>
              </div>
              <button
                onClick={() => onContinueAsVisitor('smartspace')}
                className="w-full min-h-[44px] sm:min-h-0 py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Continue as Visitor</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-5 px-4 text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Users className="w-3.5 h-3.5 text-blue-700 dark:text-cyan-400" />
            <span>ONECAMPUS · Dayalbagh Educational Institute, Agra</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="hidden sm:flex items-center gap-1 text-slate-400">
              <Leaf className="w-3.5 h-3.5 text-emerald-600" /> Sustainability + Smart Campus
            </span>
            <button onClick={onOpenAbout} className="hover:text-blue-700 dark:hover:text-cyan-400 font-medium">
              Project Scope, Architecture &amp; Contact
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
