import React, { useState, useMemo } from 'react';
import {
  X,
  Calendar,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Users,
  Sparkles,
  ArrowRightLeft,
  Info
} from 'lucide-react';
import { Room, RoomBooking } from '../types';
import { getTodayIsoDate } from '../initialData';

interface Props {
  room: Room | null;
  allRooms: Room[];
  bookings: RoomBooking[];
  isOpen: boolean;
  onClose: () => void;
  onSelectAlternativeRoom: (room: Room) => void;
  onConfirmBooking: (payload: {
    room: Room;
    date: string;
    startTime: string;
    endTime: string;
    purpose: string;
  }) => Promise<void>;
}

const PRESET_SLOTS = [
  { label: '09:00 - 10:00', start: '09:00', end: '10:00' },
  { label: '10:00 - 11:00', start: '10:00', end: '11:00' },
  { label: '11:00 - 12:00', start: '11:00', end: '12:00' },
  { label: '14:00 - 15:00', start: '14:00', end: '15:00' },
  { label: '15:00 - 16:00', start: '15:00', end: '16:00' },
  { label: '16:00 - 17:00', start: '16:00', end: '17:00' }
];

const TIMELINE_START_MIN = 8 * 60; // 08:00
const TIMELINE_END_MIN = 19 * 60; // 19:00
const TIMELINE_SPAN = TIMELINE_END_MIN - TIMELINE_START_MIN;

function toMinutes(hhmm: string): number {
  const [hStr, mStr] = hhmm.split(':');
  const h = Number(hStr);
  const m = Number(mStr);
  if (Number.isNaN(h) || Number.isNaN(m)) return 0;
  return h * 60 + m;
}

function fromMinutes(totalMins: number): string {
  const clamped = Math.max(0, Math.min(23 * 60 + 59, totalMins));
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export const RoomBookingModal: React.FC<Props> = ({
  room,
  allRooms,
  bookings,
  isOpen,
  onClose,
  onSelectAlternativeRoom,
  onConfirmBooking
}) => {
  const [date, setDate] = useState<string>(getTodayIsoDate());
  const [startTime, setStartTime] = useState<string>('15:00');
  const [endTime, setEndTime] = useState<string>('16:00');
  const [purpose, setPurpose] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const roomBookingsForDate = useMemo(() => {
    if (!room) return [];
    return bookings
      .filter(b => b.roomId === room.roomId && b.date === date && b.status === 'Confirmed')
      .sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [room, bookings, date]);

  const isInvalidRange = !startTime || !endTime || startTime >= endTime;

  const conflictingBookings = useMemo(() => {
    if (isInvalidRange) return [];
    return roomBookingsForDate.filter(b => startTime < b.endTime && endTime > b.startTime);
  }, [roomBookingsForDate, startTime, endTime, isInvalidRange]);

  const primaryConflict = conflictingBookings[0] || null;

  // Overlap duration in minutes for crisp conflict reporting
  const overlapMinutes = useMemo(() => {
    if (!primaryConflict || isInvalidRange) return 0;
    const s1 = toMinutes(startTime);
    const e1 = toMinutes(endTime);
    const s2 = toMinutes(primaryConflict.startTime);
    const e2 = toMinutes(primaryConflict.endTime);
    return Math.max(0, Math.min(e1, e2) - Math.max(s1, s2));
  }, [primaryConflict, startTime, endTime, isInvalidRange]);

  // Tight back-to-back buffer warning (< 10 mins turnaround) when there is no hard clash
  const tightTurnaroundBooking = useMemo(() => {
    if (isInvalidRange || primaryConflict) return null;
    const s = toMinutes(startTime);
    const e = toMinutes(endTime);
    return (
      roomBookingsForDate.find(b => {
        const bs = toMinutes(b.startTime);
        const be = toMinutes(b.endTime);
        const gapBefore = s - be;
        const gapAfter = bs - e;
        return (gapBefore >= 0 && gapBefore < 10) || (gapAfter >= 0 && gapAfter < 10);
      }) || null
    );
  }, [roomBookingsForDate, startTime, endTime, isInvalidRange, primaryConflict]);

  // Smart Suggestion A: Next conflict-free slots in the SAME room preserving requested duration
  const suggestedTimeSlots = useMemo(() => {
    if (!room || isInvalidRange || !primaryConflict) return [];
    const reqDuration = Math.max(30, Math.min(240, toMinutes(endTime) - toMinutes(startTime)));
    const suggestions: Array<{ start: string; end: string }> = [];

    for (let t = 8 * 60; t + reqDuration <= 19 * 60; t += 30) {
      const candStart = fromMinutes(t);
      const candEnd = fromMinutes(t + reqDuration);
      if (candStart === startTime && candEnd === endTime) continue;

      const hasClash = roomBookingsForDate.some(
        b => candStart < b.endTime && candEnd > b.startTime
      );
      if (!hasClash) {
        suggestions.push({ start: candStart, end: candEnd });
        if (suggestions.length >= 3) break;
      }
    }
    return suggestions;
  }, [room, roomBookingsForDate, startTime, endTime, isInvalidRange, primaryConflict]);

  // Smart Suggestion B: Alternative rooms with ZERO booking clashes at the EXACT selected date + time
  const suggestedAlternativeRooms = useMemo(() => {
    if (!room || isInvalidRange || !primaryConflict) return [];
    const minNeededSeats = Math.max(10, Math.floor(room.capacity * 0.65));

    const freeRooms = allRooms.filter(candidate => {
      if (candidate.roomId === room.roomId) return false;
      const candidateDayBookings = bookings.filter(
        b => b.roomId === candidate.roomId && b.date === date && b.status === 'Confirmed'
      );
      const hasClash = candidateDayBookings.some(
        b => startTime < b.endTime && endTime > b.startTime
      );
      return !hasClash;
    });

    return freeRooms
      .sort((a, b) => {
        const score = (r: Room) => {
          let s = 0;
          if (r.buildingName === room.buildingName) s += 40;
          if (r.roomType === room.roomType) s += 25;
          if (r.capacity >= minNeededSeats) s += 20;
          if (r.status === 'Available') s += 15;
          return s;
        };
        return score(b) - score(a);
      })
      .slice(0, 3);
  }, [room, allRooms, bookings, date, startTime, endTime, isInvalidRange, primaryConflict]);

  if (!isOpen || !room) return null;

  const selectedStartPct = Math.max(
    0,
    Math.min(100, ((toMinutes(startTime) - TIMELINE_START_MIN) / TIMELINE_SPAN) * 100)
  );
  const selectedEndPct = Math.max(
    selectedStartPct,
    Math.min(100, ((toMinutes(endTime) - TIMELINE_START_MIN) / TIMELINE_SPAN) * 100)
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isInvalidRange || primaryConflict || !purpose.trim()) return;
    setIsSubmitting(true);
    try {
      await onConfirmBooking({
        room,
        date,
        startTime,
        endTime,
        purpose: purpose.trim()
      });
      setPurpose('');
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-xs p-0 sm:p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-lg overflow-hidden max-h-[92vh] flex flex-col">
        {/* Mobile bottom-sheet grab handle */}
        <div className="pt-2.5 pb-1 sm:hidden flex justify-center shrink-0">
          <div className="w-10 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" />
        </div>

        <div className="px-5 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="min-w-0 pr-2">
            <h3 className="font-bold text-slate-900 dark:text-white text-base font-heading truncate">
              Book Slot · {room.roomName}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
              {room.buildingName} · {room.roomType} · {room.capacity} seats
            </p>
          </div>
          <button
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
            aria-label="Close booking modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 mb-1">
                <Calendar className="w-3.5 h-3.5 text-blue-700 dark:text-cyan-400" />
                <span>Date</span>
              </label>
              <input
                type="date"
                value={date}
                min={getTodayIsoDate()}
                onChange={(e) => setDate(e.target.value)}
                className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white font-mono"
                required
              />
            </div>

            <div className="grid grid-cols-2 sm:contents gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 mb-1">
                  <Clock className="w-3.5 h-3.5 text-blue-700 dark:text-cyan-400" />
                  <span>Start</span>
                </label>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white font-mono"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 mb-1">
                  <Clock className="w-3.5 h-3.5 text-blue-700 dark:text-cyan-400" />
                  <span>End</span>
                </label>
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white font-mono"
                  required
                />
              </div>
            </div>
          </div>

          {/* Visual Daily Timeline Bar (08:00 – 19:00) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold">Day Timeline (08:00 – 19:00)</span>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-xs bg-rose-500 inline-block" /> Booked
                </span>
                <span className="flex items-center gap-1">
                  <span className={`w-2 h-2 rounded-xs inline-block ${primaryConflict ? 'bg-amber-500' : 'bg-emerald-500'}`} /> Selected
                </span>
              </div>
            </div>
            <div className="relative h-6 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 overflow-hidden">
              {/* Existing confirmed bookings */}
              {roomBookingsForDate.map(bk => {
                const left = Math.max(0, Math.min(100, ((toMinutes(bk.startTime) - TIMELINE_START_MIN) / TIMELINE_SPAN) * 100));
                const right = Math.max(left, Math.min(100, ((toMinutes(bk.endTime) - TIMELINE_START_MIN) / TIMELINE_SPAN) * 100));
                return (
                  <div
                    key={bk.id}
                    title={`${bk.startTime}–${bk.endTime} · ${bk.bookedByName}`}
                    style={{ left: `${left}%`, width: `${Math.max(2, right - left)}%` }}
                    className="absolute top-0 bottom-0 bg-rose-500/75 dark:bg-rose-500/60 border-x border-rose-700/30"
                  />
                );
              })}

              {/* Selected range overlay */}
              {!isInvalidRange && (
                <div
                  style={{
                    left: `${selectedStartPct}%`,
                    width: `${Math.max(2, selectedEndPct - selectedStartPct)}%`
                  }}
                  className={`absolute top-0.5 bottom-0.5 rounded-sm transition-all duration-150 border-2 ${
                    primaryConflict
                      ? 'bg-amber-400/70 border-rose-600'
                      : 'bg-emerald-500/75 border-emerald-700'
                  }`}
                />
              )}
            </div>
            <div className="flex justify-between text-[10px] font-mono text-slate-400 tabular-nums">
              <span>08:00</span>
              <span>11:00</span>
              <span>14:00</span>
              <span>17:00</span>
              <span>19:00</span>
            </div>
          </div>

          {/* Quick DEI Slot Presets */}
          <div>
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1.5">
              Quick Campus Slots:
            </span>
            <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-1.5">
              {PRESET_SLOTS.map(slot => {
                const isBooked = roomBookingsForDate.some(
                  b => slot.start < b.endTime && slot.end > b.startTime
                );
                const isSelected = startTime === slot.start && endTime === slot.end;
                return (
                  <button
                    key={slot.label}
                    type="button"
                    disabled={isBooked}
                    onClick={() => {
                      setStartTime(slot.start);
                      setEndTime(slot.end);
                    }}
                    className={`min-h-[38px] sm:min-h-0 px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-semibold transition-colors ${
                      isBooked
                        ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-400 line-through cursor-not-allowed border border-rose-200/60 dark:border-rose-900/50'
                        : isSelected
                          ? 'bg-blue-700 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {slot.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Smart Clash Detection & Auto-Resolution Suggestions */}
          {isInvalidRange ? (
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-xs text-amber-800 dark:text-amber-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>End time must be after start time.</span>
            </div>
          ) : primaryConflict ? (
            <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs space-y-3">
              <div className="flex items-start gap-2 text-rose-800 dark:text-rose-300">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <div className="font-bold">
                    Smart Clash Detected ({overlapMinutes} min overlap)
                  </div>
                  <div className="leading-relaxed">
                    Overlaps with <strong className="font-mono">{primaryConflict.startTime}–{primaryConflict.endTime}</strong> reserved by{' '}
                    <strong>{primaryConflict.bookedByName}</strong> ({primaryConflict.purpose}).
                  </div>
                </div>
              </div>

              {/* 1-Click Free Slots in Same Room */}
              {suggestedTimeSlots.length > 0 && (
                <div className="pt-2 border-t border-rose-200/70 dark:border-rose-900/60 space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Next Clash-Free Slots in {room.code}:</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {suggestedTimeSlots.map(slot => (
                      <button
                        key={`${slot.start}-${slot.end}`}
                        type="button"
                        onClick={() => {
                          setStartTime(slot.start);
                          setEndTime(slot.end);
                        }}
                        className="min-h-[36px] sm:min-h-0 px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 font-mono text-[11px] font-bold transition-colors"
                      >
                        Use {slot.start}–{slot.end}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* 1-Click Alternative Free Rooms at Same Time */}
              {suggestedAlternativeRooms.length > 0 && (
                <div className="pt-2 border-t border-rose-200/70 dark:border-rose-900/60 space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <ArrowRightLeft className="w-3.5 h-3.5 text-teal-600" />
                    <span>Available Rooms at {startTime}–{endTime}:</span>
                  </div>
                  <div className="space-y-1.5">
                    {suggestedAlternativeRooms.map(alt => (
                      <button
                        key={alt.roomId}
                        type="button"
                        onClick={() => onSelectAlternativeRoom(alt)}
                        className="w-full min-h-[42px] px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-emerald-500 text-left flex items-center justify-between gap-2 transition-colors"
                      >
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 dark:text-white text-[11px] truncate">
                            {alt.code} · {alt.roomName}
                          </div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                            {alt.buildingName} · {alt.capacity} seats
                          </div>
                        </div>
                        <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 shrink-0">
                          Switch
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-2">
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>No clash detected for {date} ({startTime}–{endTime}). Slot is free to book!</span>
              </div>
              {tightTurnaroundBooking && (
                <div className="p-2.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-[11px] text-amber-800 dark:text-amber-300 flex items-center gap-2">
                  <Info className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    Back-to-back note: adjacent to {tightTurnaroundBooking.startTime}–{tightTurnaroundBooking.endTime} reservation.
                  </span>
                </div>
              )}
            </div>
          )}

          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Purpose / Session Title
            </label>
            <input
              type="text"
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              placeholder="e.g. B.Tech Group Study, PeerLearn Tutorial, Seminar Practice"
              minLength={2}
              maxLength={180}
              className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2.5 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              required
            />
          </div>

          {/* Schedule for Selected Date */}
          <div className="border-t border-slate-100 dark:border-slate-800 pt-3">
            <div className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center justify-between">
              <span>Reserved Slots on {date}</span>
              <span className="font-mono text-slate-400">{roomBookingsForDate.length} booked</span>
            </div>
            {roomBookingsForDate.length === 0 ? (
              <p className="text-xs text-slate-400 py-1">No reservations yet for this date.</p>
            ) : (
              <div className="space-y-1.5 max-h-28 overflow-y-auto scrollbar-thin">
                {roomBookingsForDate.map(bk => (
                  <div
                    key={bk.id}
                    className="px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800/70 text-xs flex items-center justify-between gap-2"
                  >
                    <div className="truncate">
                      <span className="font-mono font-bold text-slate-800 dark:text-slate-200 mr-2">
                        {bk.startTime}–{bk.endTime}
                      </span>
                      <span className="text-slate-600 dark:text-slate-300">{bk.purpose}</span>
                    </div>
                    <span className="text-[11px] text-slate-400 flex items-center gap-1 shrink-0">
                      <Users className="w-3 h-3" /> {bk.bookedByName}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-2 pb-2 sm:pb-0 flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] sm:min-h-0 px-4 py-2.5 sm:py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isInvalidRange || Boolean(primaryConflict) || isSubmitting}
              className="min-h-[44px] sm:min-h-0 px-5 py-2.5 sm:py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl transition-colors"
            >
              {isSubmitting ? 'Confirming...' : 'Confirm Slot Booking'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
