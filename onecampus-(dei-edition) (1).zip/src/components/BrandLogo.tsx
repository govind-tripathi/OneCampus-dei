import React from 'react';

interface Props {
  className?: string;
}

export const BrandLogo: React.FC<Props> = ({ className = 'w-9 h-9' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="oneCampusRoyalGrad" x1="6" y1="4" x2="58" y2="60" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#1e3a8a" />
        <stop offset="55%" stopColor="#2563eb" />
        <stop offset="100%" stopColor="#0891b2" />
      </linearGradient>
    </defs>
    <rect x="4" y="4" width="56" height="56" rx="16" fill="url(#oneCampusRoyalGrad)" />
    <rect x="7" y="7" width="50" height="50" rx="13" stroke="#93c5fd" strokeOpacity="0.28" strokeWidth="1.2" />
    <path
      d="M17 45V25L32 15L47 25V45"
      stroke="#ffffff"
      strokeWidth="3.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M25.5 45V33C25.5 29.4101 28.4101 26.5 32 26.5C35.5899 26.5 38.5 29.4101 38.5 33V45"
      stroke="#fbbf24"
      strokeWidth="3.4"
      strokeLinecap="round"
    />
    <circle cx="32" cy="11.5" r="2.8" fill="#fbbf24" />
  </svg>
);
