import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Camera,
  MapPin,
  Image as ImageIcon,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Navigation,
  SwitchCamera,
  Aperture,
  Loader2
} from 'lucide-react';
import { APIProvider, Map as GoogleMap, AdvancedMarker, Pin, useMap } from '@vis.gl/react-google-maps';
import { CAMPUS_ZONES_GEO, DEI_CAMPUS_CENTER } from '../initialData';
import {
  compressImageFile,
  captureVideoFrameCompressed,
  estimateDataUrlKb
} from '../utils/imageCompression';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  gmpQuotaExceeded?: boolean;
  onSubmitReport: (payload: {
    location: string;
    issueCategory: 'Electrical/Fan' | 'Water Leakage' | 'Cleanliness' | 'Green Initiative';
    description: string;
    imageData?: string;
    mapX: number;
    mapY: number;
    lat?: number;
    lng?: number;
    gpsAccuracy?: number;
  }) => Promise<void>;
}

const DRAFT_STORAGE_KEY = 'onecampus_eco_report_draft';
const MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

// Convert DEI area GPS coordinates back into approximate 760x420 schematic pin coordinates
function latLngToSvg(lat: number, lng: number): { x: number; y: number } {
  // Campus bounding box roughly [27.2245..27.2285] x [78.0095..78.0155]
  const normX = (lng - 78.0095) / (78.0155 - 78.0095);
  const normY = 1 - (lat - 27.2245) / (27.2285 - 27.2245);
  const x = Math.round(Math.max(40, Math.min(720, normX * 760)));
  const y = Math.round(Math.max(40, Math.min(380, normY * 420)));
  return { x, y };
}

const MiniMapPanSync: React.FC<{ coords: { lat: number; lng: number } }> = ({ coords }) => {
  const map = useMap();
  useEffect(() => {
    if (!map) return;
    map.panTo(coords);
  }, [map, coords]);
  return null;
};

export const ReportIssueModal: React.FC<Props> = ({
  isOpen,
  onClose,
  gmpQuotaExceeded = false,
  onSubmitReport
}) => {
  const [selectedZone, setSelectedZone] = useState<string>('Faculty of Engineering');
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState<
    'Electrical/Fan' | 'Water Leakage' | 'Cleanliness' | 'Green Initiative'
  >('Electrical/Fan');
  const [description, setDescription] = useState('');
  const [imageData, setImageData] = useState<string | undefined>(undefined);
  const [mapCoords, setMapCoords] = useState<{ x: number; y: number }>({ x: 180, y: 115 });
  const [gpsCoords, setGpsCoords] = useState<{ lat: number; lng: number; accuracy?: number }>({
    lat: 27.2274,
    lng: 78.0112
  });
  const [isLocatingGps, setIsLocatingGps] = useState(false);

  // Live In-Browser Camera State
  const [cameraActive, setCameraActive] = useState(false);
  const [videoReady, setVideoReady] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [miniMapType, setMiniMapType] = useState<'hybrid' | 'roadmap'>('hybrid');
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [isProcessingImg, setIsProcessingImg] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const stopCameraStream = () => {
    setVideoReady(false);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  // Start / flip camera stream whenever cameraActive or facingMode changes
  useEffect(() => {
    if (!isOpen || !cameraActive) {
      stopCameraStream();
      return;
    }

    let cancelled = false;
    setCameraError(null);
    setVideoReady(false);

    const startStream = async () => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError('Live camera preview is not supported on this browser. Use "Phone Cam" or "Gallery".');
        setCameraActive(false);
        return;
      }
      try {
        stopCameraStream();
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
          if (!cancelled && videoRef.current.readyState >= 2) {
            setVideoReady(true);
          }
        }
      } catch {
        setCameraError('Camera access was blocked or unavailable. Use "Phone Cam" or upload from Gallery.');
        setCameraActive(false);
      }
    };

    startStream();

    return () => {
      cancelled = true;
      stopCameraStream();
    };
  }, [isOpen, cameraActive, facingMode]);

  // Restore draft once when modal opens
  useEffect(() => {
    if (!isOpen) return;
    try {
      const raw = sessionStorage.getItem(DRAFT_STORAGE_KEY);
      if (raw) {
        const draft = JSON.parse(raw);
        if (typeof draft.selectedZone === 'string') setSelectedZone(draft.selectedZone);
        if (typeof draft.location === 'string') setLocation(draft.location);
        if (typeof draft.category === 'string') setCategory(draft.category);
        if (typeof draft.description === 'string') setDescription(draft.description);
        if (typeof draft.imageData === 'string') setImageData(draft.imageData);
        if (draft.mapCoords && typeof draft.mapCoords.x === 'number' && typeof draft.mapCoords.y === 'number') {
          setMapCoords(draft.mapCoords);
        }
        if (draft.gpsCoords && typeof draft.gpsCoords.lat === 'number' && typeof draft.gpsCoords.lng === 'number') {
          setGpsCoords(draft.gpsCoords);
        }
      }
    } catch {
      // ignore invalid draft
    }
  }, [isOpen]);

  // Sync draft while modal is open
  useEffect(() => {
    if (!isOpen) return;
    try {
      sessionStorage.setItem(
        DRAFT_STORAGE_KEY,
        JSON.stringify({ selectedZone, location, category, description, imageData, mapCoords, gpsCoords })
      );
    } catch {
      // ignore storage quota
    }
  }, [isOpen, selectedZone, location, category, description, imageData, mapCoords, gpsCoords]);

  if (!isOpen) return null;

  const clearDraftAndReset = () => {
    stopCameraStream();
    setCameraActive(false);
    setCameraError(null);
    setLocation('');
    setDescription('');
    setImageData(undefined);
    setFormError(null);
    try {
      sessionStorage.removeItem(DRAFT_STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  const handleCloseCleanly = () => {
    clearDraftAndReset();
    onClose();
  };

  const handleCaptureSnapshot = () => {
    if (!videoRef.current) return;
    if (videoRef.current.readyState < 2 || videoRef.current.videoWidth === 0) {
      setFormError('Camera stream is still warming up. Wait a moment and tap Capture again.');
      return;
    }
    setIsProcessingImg(true);
    setFormError(null);
    try {
      const dataUrl = captureVideoFrameCompressed(videoRef.current);
      setImageData(dataUrl);
      setCameraActive(false);
      stopCameraStream();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Snapshot failed. Please try again.');
    } finally {
      setIsProcessingImg(false);
    }
  };

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setFormError(null);
    setIsProcessingImg(true);
    try {
      const dataUrl = await compressImageFile(file);
      setImageData(dataUrl);
      setCameraActive(false);
      stopCameraStream();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to process photo. Try selecting from gallery.');
    } finally {
      setIsProcessingImg(false);
    }
  };

  const handleCaptureExactGps = () => {
    if (!navigator.geolocation) {
      setFormError('GPS geolocation is not supported on this device. Tap the map to place your pin manually.');
      return;
    }
    setIsLocatingGps(true);
    setFormError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(6));
        const lng = Number(pos.coords.longitude.toFixed(6));
        const accuracy = Math.round(pos.coords.accuracy || 15);
        setGpsCoords({ lat, lng, accuracy });
        setMapCoords(latLngToSvg(lat, lng));
        setIsLocatingGps(false);
      },
      () => {
        setIsLocatingGps(false);
        setFormError('Could not access GPS location. Please allow location permission or tap directly on the campus map.');
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const handleMiniMapClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const svg = e.currentTarget;
    const rect = svg.getBoundingClientRect();
    const x = Math.round(((e.clientX - rect.left) / rect.width) * 760);
    const y = Math.round(((e.clientY - rect.top) / rect.height) * 420);
    const clampedX = Math.max(20, Math.min(740, x));
    const clampedY = Math.max(20, Math.min(400, y));
    setMapCoords({ x: clampedX, y: clampedY });

    // Approximate real GPS coordinates inside DEI Agra bounds
    const lat = Number((27.2285 - (clampedY / 420) * (27.2285 - 27.2245)).toFixed(6));
    const lng = Number((78.0095 + (clampedX / 760) * (78.0155 - 78.0095)).toFixed(6));
    setGpsCoords({ lat, lng });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const trimmedLocation = location.trim();
    const trimmedDesc = description.trim();

    if (trimmedLocation.length < 2) {
      setFormError('Please enter Exact Location / Room Name (at least 2 characters).');
      return;
    }
    if (trimmedDesc.length < 5) {
      setFormError('Please enter Issue Description (at least 5 characters).');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmitReport({
        location: trimmedLocation,
        issueCategory: category,
        description: trimmedDesc,
        imageData,
        mapX: mapCoords.x,
        mapY: mapCoords.y,
        lat: gpsCoords.lat,
        lng: gpsCoords.lng,
        gpsAccuracy: gpsCoords.accuracy
      });
      clearDraftAndReset();
      onClose();
    } catch (err) {
      setFormError(
        err instanceof Error && !err.message.startsWith('{')
          ? err.message
          : 'Could not save report to cloud. Please check your connection and try again.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const photoKb = estimateDataUrlKb(imageData);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/70 backdrop-blur-xs p-0 sm:p-4">
      <div className="bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-xl overflow-hidden max-h-[94vh] flex flex-col">
        <div className="pt-2.5 pb-1 sm:hidden flex justify-center shrink-0">
          <div className="w-10 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" />
        </div>

        <div className="px-5 sm:px-6 py-3 sm:py-4 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-900 text-white flex items-center justify-between shrink-0">
          <div className="min-w-0 pr-2">
            <h3 className="font-bold text-base font-heading">
              EcoPulse Advanced Care Report
            </h3>
            <p className="text-xs text-blue-100/80">
              Snap a live photo, lock exact GPS coordinates, and earn +10 Karma on fix.
            </p>
          </div>
          <button
            type="button"
            onClick={handleCloseCleanly}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-blue-100 hover:text-white hover:bg-white/10 shrink-0"
            aria-label="Close report modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <form
          id="eco-report-form"
          onSubmit={handleSubmit}
          noValidate
          className="p-5 sm:p-6 space-y-4 overflow-y-auto flex-1"
        >
          {formError && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-200 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{formError}</span>
            </div>
          )}

          {/* Photo Section: Live Viewfinder OR Attached Preview OR 3 Options */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Photo Evidence (Live Camera or Upload)
              </label>
              {imageData && (
                <span className="text-[11px] font-mono text-emerald-700 dark:text-emerald-400 font-semibold">
                  {photoKb} KB Ready
                </span>
              )}
            </div>

            {cameraActive ? (
              <div className="rounded-2xl overflow-hidden border-2 border-blue-600 bg-slate-950 relative">
                <video
                  ref={videoRef}
                  playsInline
                  muted
                  autoPlay
                  onLoadedData={() => setVideoReady(true)}
                  className="w-full h-56 object-cover"
                />
                <div className="p-3 bg-slate-900/95 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setFacingMode((m) => (m === 'environment' ? 'user' : 'environment'))}
                    className="min-h-[40px] px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <SwitchCamera className="w-4 h-4" />
                    <span>Flip</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleCaptureSnapshot}
                    disabled={!videoReady || isProcessingImg}
                    className="min-h-[42px] px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-md"
                  >
                    <Aperture className="w-4 h-4" />
                    <span>{videoReady ? 'Capture Photo' : 'Starting...'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setCameraActive(false);
                      stopCameraStream();
                    }}
                    className="min-h-[40px] px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-700 text-slate-200 text-xs font-semibold"
                  >
                    Close
                  </button>
                </div>
              </div>
            ) : imageData ? (
              <div className="rounded-xl overflow-hidden border border-blue-300 dark:border-blue-800 bg-slate-50 dark:bg-slate-800/80">
                <div className="relative">
                  <img
                    src={imageData}
                    alt="EcoPulse report preview"
                    className="w-full h-40 object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => setImageData(undefined)}
                    className="absolute top-2 right-2 min-h-[36px] px-2.5 py-1.5 rounded-lg bg-slate-900/85 text-white hover:bg-rose-600 transition-colors text-xs flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove</span>
                  </button>
                </div>
                <div className="px-3 py-2 flex items-center justify-between text-[11px] bg-blue-50/90 dark:bg-blue-950/50 text-blue-900 dark:text-cyan-300 font-semibold">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    Photo attached ({photoKb} KB) · Saved cleanly
                  </span>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setCameraActive(true)}
                      className="underline cursor-pointer"
                    >
                      Retake
                    </button>
                    <label className="underline cursor-pointer">
                      Gallery
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoChange}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                {cameraError && (
                  <p className="text-[11px] text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-lg px-2.5 py-1.5">
                    {cameraError}
                  </p>
                )}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setCameraActive(true)}
                    disabled={isProcessingImg}
                    className="min-h-[54px] flex flex-col sm:flex-row items-center justify-center gap-1.5 px-2.5 py-2 rounded-xl border border-dashed border-blue-500 dark:border-cyan-600 bg-blue-50/80 dark:bg-blue-950/40 hover:bg-blue-100/80 dark:hover:bg-blue-950/70 transition-colors text-[11px] sm:text-xs font-bold text-blue-900 dark:text-cyan-300"
                  >
                    <Aperture className="w-4 h-4 shrink-0" />
                    <span>Live Camera</span>
                  </button>

                  <label className="min-h-[54px] flex flex-col sm:flex-row items-center justify-center gap-1.5 px-2.5 py-2 rounded-xl border border-dashed border-indigo-400 dark:border-indigo-700 bg-indigo-50/60 dark:bg-indigo-950/30 hover:bg-indigo-100/70 cursor-pointer transition-colors text-[11px] sm:text-xs font-semibold text-indigo-800 dark:text-indigo-300">
                    <Camera className="w-4 h-4 shrink-0" />
                    <span>{isProcessingImg ? 'Wait...' : 'Phone Cam'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handlePhotoChange}
                      className="hidden"
                    />
                  </label>

                  <label className="min-h-[54px] flex flex-col sm:flex-row items-center justify-center gap-1.5 px-2.5 py-2 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors text-[11px] sm:text-xs font-semibold text-slate-700 dark:text-slate-200">
                    <ImageIcon className="w-4 h-4 shrink-0" />
                    <span>{isProcessingImg ? 'Wait...' : 'Gallery'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Campus Zone / Quick Pin
              </label>
              <select
                value={selectedZone}
                onChange={(e) => {
                  const val = e.target.value;
                  setSelectedZone(val);
                  const zone = CAMPUS_ZONES_GEO.find((z) => z.label === val);
                  if (zone) {
                    setMapCoords({ x: zone.x, y: zone.y });
                    setGpsCoords({ lat: zone.lat, lng: zone.lng });
                    if (!location.trim()) setLocation(zone.label);
                  }
                }}
                className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white"
              >
                {CAMPUS_ZONES_GEO.map((z) => (
                  <option key={z.label} value={z.label}>
                    {z.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as typeof category)}
                className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white"
              >
                <option value="Electrical/Fan">Electrical / Fan Left Running</option>
                <option value="Water Leakage">Water Leakage / Tap Dripping</option>
                <option value="Cleanliness">Cleanliness &amp; Waste Segregation</option>
                <option value="Green Initiative">Green Initiative / Solar Idea</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Exact Location / Room Name *
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => {
                setLocation(e.target.value);
                if (formError) setFormError(null);
              }}
              placeholder="e.g. Faculty of Engineering, Room E-202"
              minLength={2}
              maxLength={140}
              className="w-full min-h-[44px] sm:min-h-0 text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white"
              required
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Issue Description *
            </label>
            <textarea
              value={description}
              onChange={(e) => {
                setDescription(e.target.value);
                if (formError) setFormError(null);
              }}
              rows={2}
              minLength={5}
              maxLength={580}
              placeholder="Describe the maintenance issue, water drip, or sustainability idea..."
              className="w-full text-sm sm:text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white"
              required
            />
          </div>

          {/* Live GPS + Interactive Satellite / Campus Pin Picker */}
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-blue-700 dark:text-cyan-400" />
                Tap Map or Lock Standing GPS
              </span>
              <div className="flex items-center gap-2">
                <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 tabular-nums">
                  {gpsCoords.lat.toFixed(5)}, {gpsCoords.lng.toFixed(5)}
                  {gpsCoords.accuracy ? ` (±${gpsCoords.accuracy}m)` : ''}
                </span>
                <button
                  type="button"
                  onClick={handleCaptureExactGps}
                  disabled={isLocatingGps}
                  className="px-2.5 py-1 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-[11px] font-semibold flex items-center gap-1 transition-colors disabled:opacity-60"
                >
                  {isLocatingGps ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <Navigation className="w-3 h-3" />
                  )}
                  <span>{isLocatingGps ? 'Locating...' : 'Use My GPS'}</span>
                </button>
              </div>
            </div>

            {MAPS_API_KEY && !gmpQuotaExceeded ? (
              <div className="rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden h-44 relative">
                <div className="absolute top-2 left-2 z-10 flex items-center gap-1 bg-slate-950/80 backdrop-blur-xs p-0.5 rounded-lg text-[10px]">
                  <button
                    type="button"
                    onClick={() => setMiniMapType('hybrid')}
                    className={`px-2 py-0.5 rounded-md font-semibold ${
                      miniMapType === 'hybrid' ? 'bg-blue-600 text-white' : 'text-slate-200'
                    }`}
                  >
                    Earth
                  </button>
                  <button
                    type="button"
                    onClick={() => setMiniMapType('roadmap')}
                    className={`px-2 py-0.5 rounded-md font-semibold ${
                      miniMapType === 'roadmap' ? 'bg-blue-600 text-white' : 'text-slate-200'
                    }`}
                  >
                    Street
                  </button>
                </div>
                <APIProvider apiKey={MAPS_API_KEY} libraries={['marker']}>
                  <GoogleMap
                    mapId="DEMO_MAP_ID"
                    defaultCenter={gpsCoords || DEI_CAMPUS_CENTER}
                    defaultZoom={17}
                    mapTypeId={miniMapType}
                    gestureHandling="greedy"
                    disableDefaultUI={false}
                    streetViewControl={true}
                    fullscreenControl={false}
                    internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                    style={{ width: '100%', height: '100%' }}
                    onClick={(ev) => {
                      const latLng = ev.detail?.latLng;
                      if (latLng) {
                        const lat = Number(latLng.lat.toFixed(6));
                        const lng = Number(latLng.lng.toFixed(6));
                        setGpsCoords({ lat, lng });
                        setMapCoords(latLngToSvg(lat, lng));
                      }
                    }}
                    className="w-full h-full"
                  >
                    <MiniMapPanSync coords={gpsCoords} />
                    <AdvancedMarker position={gpsCoords} title="Selected Campus Issue Location">
                      <Pin background="#2563eb" borderColor="#1e3a8a" glyphColor="#ffffff" scale={1.1} />
                    </AdvancedMarker>
                  </GoogleMap>
                </APIProvider>
              </div>
            ) : (
              <div className="rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden bg-slate-50 dark:bg-slate-800">
                <svg
                  viewBox="0 0 760 420"
                  onClick={handleMiniMapClick}
                  className="w-full h-32 cursor-crosshair select-none"
                >
                  <rect width="760" height="420" fill="#f8fafc" className="dark:fill-slate-900" />
                  <rect x="70" y="50" width="220" height="120" fill="#e2e8f0" className="dark:fill-slate-800" rx="8" />
                  <text x="180" y="115" textAnchor="middle" fill="#475569" fontSize="14" fontWeight="bold">Engineering</text>
                  <rect x="310" y="50" width="180" height="120" fill="#dbeafe" className="dark:fill-blue-950/50" rx="8" />
                  <text x="400" y="115" textAnchor="middle" fill="#1e40af" fontSize="14" fontWeight="bold">Science</text>
                  <rect x="510" y="50" width="200" height="120" fill="#e2e8f0" className="dark:fill-slate-800" rx="8" />
                  <text x="610" y="115" textAnchor="middle" fill="#475569" fontSize="14" fontWeight="bold">Central Library</text>
                  <rect x="70" y="260" width="160" height="110" fill="#fef3c7" className="dark:fill-amber-950/50" rx="8" />
                  <text x="150" y="320" textAnchor="middle" fill="#92400e" fontSize="13" fontWeight="bold">Girls Hostel</text>
                  <rect x="250" y="260" width="210" height="110" fill="#e2e8f0" className="dark:fill-slate-800" rx="8" />
                  <text x="355" y="320" textAnchor="middle" fill="#475569" fontSize="13" fontWeight="bold">Canteen Hub</text>
                  <rect x="480" y="260" width="230" height="110" fill="#e2e8f0" className="dark:fill-slate-800" rx="8" />
                  <text x="595" y="320" textAnchor="middle" fill="#475569" fontSize="13" fontWeight="bold">Seminar Complex</text>
                  <g transform={`translate(${mapCoords.x}, ${mapCoords.y})`}>
                    <circle cx="0" cy="0" r="18" fill="#2563eb" opacity="0.28" />
                    <circle cx="0" cy="0" r="10" fill="#1d4ed8" stroke="#ffffff" strokeWidth="3" />
                  </g>
                </svg>
              </div>
            )}
          </div>
        </form>

        {/* Sticky Always-Visible Submit Bar */}
        <div className="px-5 sm:px-6 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col-reverse sm:flex-row sm:justify-end gap-2 shrink-0">
          <button
            type="button"
            onClick={handleCloseCleanly}
            className="min-h-[44px] sm:min-h-0 px-4 py-2.5 sm:py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="submit"
            form="eco-report-form"
            disabled={isSubmitting || isProcessingImg}
            className="min-h-[46px] sm:min-h-0 px-5 py-2.5 sm:py-2 text-xs font-bold text-white bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-800 hover:to-indigo-800 disabled:opacity-50 rounded-xl transition-all shadow-sm"
          >
            {isProcessingImg
              ? 'Processing Photo...'
              : isSubmitting
                ? 'Submitting Report...'
                : 'Submit Report & Drop Pin'}
          </button>
        </div>
      </div>
    </div>
  );
};
