import React, { useState } from 'react';
import { X, CheckCircle2, Camera, Image as ImageIcon, Trash2, AlertTriangle } from 'lucide-react';
import { EcoReport } from '../types';
import { compressImageFile, estimateDataUrlKb } from '../utils/imageCompression';

interface Props {
  report: EcoReport | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirmResolve: (payload: {
    report: EcoReport;
    afterImageData?: string;
    resolutionNote?: string;
  }) => Promise<void>;
}

export const ResolveReportModal: React.FC<Props> = ({
  report,
  isOpen,
  onClose,
  onConfirmResolve
}) => {
  const [afterImageData, setAfterImageData] = useState<string | undefined>(undefined);
  const [resolutionNote, setResolutionNote] = useState('');
  const [isProcessingImg, setIsProcessingImg] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen || !report) return null;

  const handlePhotoPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setErrorMsg(null);
    setIsProcessingImg(true);
    try {
      const compressed = await compressImageFile(file);
      setAfterImageData(compressed);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to compress proof photo.');
    } finally {
      setIsProcessingImg(false);
    }
  };

  const handleConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMsg(null);
    try {
      await onConfirmResolve({
        report,
        afterImageData,
        resolutionNote: resolutionNote.trim() || undefined
      });
      setAfterImageData(undefined);
      setResolutionNote('');
      onClose();
    } catch {
      setErrorMsg('Failed to mark resolved. Check your connection and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/70 backdrop-blur-xs p-0 sm:p-4">
      <div className="bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden max-h-[92vh] flex flex-col">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-blue-950 to-indigo-900 text-white flex items-center justify-between shrink-0">
          <div>
            <h3 className="font-bold text-sm sm:text-base font-heading">
              Verify &amp; Resolve EcoPulse Ticket
            </h3>
            <p className="text-[11px] text-blue-100/80">
              Awards +10 Eco Karma to {report.userName}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-blue-100 hover:text-white hover:bg-white/10"
            aria-label="Close resolve modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleConfirm} className="p-5 space-y-4 overflow-y-auto flex-1">
          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-200 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-1.5">
            <div className="text-[11px] font-bold text-blue-700 dark:text-cyan-400">
              {report.issueCategory} · {report.location}
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">{report.description}</p>
            {report.imageData && (
              <img
                src={report.imageData}
                alt="Before fix evidence"
                className="w-full h-28 object-cover rounded-lg border border-slate-200 dark:border-slate-700 mt-1"
              />
            )}
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
              After-Fix Photo Proof (Optional)
            </label>
            {afterImageData ? (
              <div className="rounded-xl overflow-hidden border border-emerald-300 dark:border-emerald-800">
                <div className="relative">
                  <img
                    src={afterImageData}
                    alt="After fix proof"
                    className="w-full h-32 object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => setAfterImageData(undefined)}
                    className="absolute top-2 right-2 px-2.5 py-1 rounded-lg bg-slate-900/85 text-white text-xs flex items-center gap-1 hover:bg-rose-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove</span>
                  </button>
                </div>
                <div className="px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/50 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300">
                  After-Fix Photo attached ({estimateDataUrlKb(afterImageData)} KB)
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <label className="min-h-[46px] flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-dashed border-blue-400 dark:border-blue-700 bg-blue-50/60 dark:bg-blue-950/30 cursor-pointer text-xs font-semibold text-blue-800 dark:text-cyan-300">
                  <Camera className="w-4 h-4" />
                  <span>{isProcessingImg ? 'Processing...' : 'Snap After Photo'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handlePhotoPick}
                    className="hidden"
                  />
                </label>
                <label className="min-h-[46px] flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 cursor-pointer text-xs font-semibold text-slate-700 dark:text-slate-200">
                  <ImageIcon className="w-4 h-4" />
                  <span>Gallery</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoPick}
                    className="hidden"
                  />
                </label>
              </div>
            )}
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Resolution Summary Note (Optional)
            </label>
            <textarea
              rows={2}
              maxLength={280}
              value={resolutionNote}
              onChange={(e) => setResolutionNote(e.target.value)}
              placeholder="e.g. Fan regulator replaced and corridor lights inspected."
              className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white"
            />
          </div>

          <div className="pt-2 flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[42px] sm:min-h-0 px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || isProcessingImg}
              className="min-h-[44px] sm:min-h-0 px-5 py-2 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-xl flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Resolving...' : 'Confirm Resolved (+10 Karma)'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
