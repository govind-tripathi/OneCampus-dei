import React, { useState } from 'react';
import {
  Building2,
  Users,
  Leaf,
  ShieldCheck,
  Database,
  Send,
  Mail,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { UserRole } from '../types';

interface Props {
  isSignedIn: boolean;
  currentUserName?: string;
  currentUserEmail?: string;
  currentUserRole?: UserRole;
  adminEmail: string;
  onSendMessage: (payload: {
    senderName: string;
    senderEmail: string;
    subject: string;
    message: string;
  }) => Promise<void>;
  onRequestSignIn: () => void;
}

export const AboutContactView: React.FC<Props> = ({
  isSignedIn,
  currentUserName,
  currentUserEmail,
  adminEmail,
  onSendMessage,
  onRequestSignIn
}) => {
  const [name, setName] = useState(currentUserName || '');
  const [email, setEmail] = useState(currentUserEmail || '');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sentDone, setSentDone] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isSignedIn) {
      onRequestSignIn();
      return;
    }
    if (!name.trim() || !email.trim() || !subject.trim() || !message.trim()) return;
    setIsSending(true);
    try {
      await onSendMessage({
        senderName: name.trim(),
        senderEmail: email.trim(),
        subject: subject.trim(),
        message: message.trim()
      });
      setSentDone(true);
      setSubject('');
      setMessage('');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Honest Scope Overview */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
        <div className="space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-blue-700 dark:text-cyan-400">
            About ONECAMPUS (DEI Edition)
          </p>
          <h2 className="text-2xl font-extrabold font-heading text-slate-900 dark:text-white">
            Unified Smart Campus Portal for DEI Agra
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            OneCampus ek smart campus web platform hai jo Dayalbagh Educational Institute (DEI) ke liye{' '}
            <strong>SmartSpace</strong> (live classroom &amp; lab availability aur slot booking),{' '}
            <strong>PeerLearn</strong> (cashless skill barter &amp; ratings), aur{' '}
            <strong>EcoPulse</strong> (Live Camera photo capture + Google Maps Satellite GPS reporting) ek jagah deta hai.
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Starter records demo campus data par initialized hote hain; Firebase Authentication aur Firestore real-time database ke saath har authenticated change sabhi connected browsers par turant sync hota hai.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-slate-100 dark:border-slate-800">
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-sm text-slate-900 dark:text-white">
              <Building2 className="w-4 h-4 text-blue-700 dark:text-cyan-400" />
              <span>SmartSpace</span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              29 synced campus rooms across 6 DEI blocks, architectural floor plans with seat filter &amp; zoom, and conflict-checked time-slot reservations.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-sm text-slate-900 dark:text-white">
              <Users className="w-4 h-4 text-amber-500" />
              <span>PeerLearn</span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Cashless 1-hour = 1-credit student mentorship barter with atomic Firestore batch credit transfers and 5-star mentor ratings.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-sm text-slate-900 dark:text-white">
              <Leaf className="w-4 h-4 text-indigo-600 dark:text-cyan-400" />
              <span>EcoPulse</span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Live browser camera viewfinder, exact standing GPS tagging on Google Satellite Maps, and Admin after-fix verification (+10 Eco Karma).
            </p>
          </div>
        </div>
      </div>

      {/* Role Governance & Security Model */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
          <div className="flex items-center gap-2 font-bold text-base text-slate-900 dark:text-white font-heading">
            <ShieldCheck className="w-5 h-5 text-blue-700 dark:text-cyan-400" />
            <span>Access &amp; Security Architecture</span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
              <div className="font-bold text-slate-900 dark:text-white mb-0.5">Visitor (Read-Only)</div>
              <div className="text-slate-500 dark:text-slate-400">
                Inspect live room grid, floor plan, real analytics charts, skills, and EcoPulse Satellite map without login.
              </div>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
              <div className="font-bold text-slate-900 dark:text-white mb-0.5">Student &amp; Faculty (Google Auth)</div>
              <div className="text-slate-500 dark:text-slate-400">
                Verified Google sign-in enables room toggles, time-slot bookings, PeerLearn skill exchange, and EcoPulse photo + GPS reporting.
              </div>
            </div>
            <div className="p-3 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/70 dark:border-amber-900/50">
              <div className="font-bold text-amber-900 dark:text-amber-300 mb-0.5">Owner-Locked Administrator</div>
              <div className="text-amber-800/90 dark:text-amber-400">
                Strictly restricted to <strong>{adminEmail}</strong> verified via Firebase Auth tokens &amp; Firestore security rules. No self-promotion is possible.
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <Database className="w-4 h-4 text-blue-700 dark:text-cyan-400 shrink-0" />
            <span>Stack: React 19, TypeScript, Google Maps Platform, Firebase Auth &amp; Cloud Firestore</span>
          </div>
        </div>

        {/* Contact & Feedback Form */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white font-heading flex items-center gap-2">
                <Mail className="w-4 h-4 text-blue-700 dark:text-cyan-400" />
                <span>Contact &amp; Faculty Feedback</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Send suggestions, deployment inquiries, or faculty feedback directly to the portal administrator.
              </p>
            </div>
          </div>

          {sentDone && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Your message has been delivered to the Administrator inbox in Firestore.</span>
            </div>
          )}

          {!isSignedIn && (
            <div className="mb-4 p-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-600 dark:text-slate-300 flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-blue-700 dark:text-cyan-400 shrink-0" />
                Sign in with Google to submit messages directly, or email{' '}
                <a href={`mailto:${adminEmail}`} className="underline font-semibold">{adminEmail}</a>.
              </span>
              <button
                onClick={onRequestSignIn}
                className="px-3 py-1.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-semibold shrink-0"
              >
                Sign In
              </button>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">Your Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Prof. / Student Name"
                  className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@dei.ac.in"
                  className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">Subject</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                minLength={3}
                maxLength={140}
                placeholder="e.g. Department Room Onboarding or Evaluation Notes"
                className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white"
                required
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">Message</label>
              <textarea
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                minLength={5}
                maxLength={1000}
                placeholder="Share feedback or integration requirements..."
                className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-white"
                required
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isSending}
                className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSending ? 'Sending...' : 'Send Message'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
