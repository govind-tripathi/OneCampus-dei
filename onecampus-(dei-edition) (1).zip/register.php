<?php
require_once 'db.php';

// Redirect if already logged in
if (is_logged_in()) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = clean($_POST['full_name'] ?? '');
    $roll_no = clean($_POST['roll_no'] ?? '');
    $department = clean($_POST['department'] ?? '');
    $email = clean($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $avatar_seed = strtolower(explode(' ', trim($full_name))[0] ?? 'student');

    if (empty($full_name) || empty($roll_no) || empty($department) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid institute email address.";
    } else {
        // Check if email or roll_no exists
        $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR roll_no = ? LIMIT 1");
        $check_stmt->bind_param("ss", $email, $roll_no);
        $check_stmt->execute();
        $check_res = $check_stmt->get_result();

        if ($check_res->num_rows > 0) {
            $error = "An account with this Email or Roll Number already exists.";
        } else {
            $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
            $default_credits = 5;
            $default_green = 10;
            $role = 'student';

            $insert = $conn->prepare("INSERT INTO users (full_name, roll_no, department, email, password, role, skill_credits, green_points, avatar_seed) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $insert->bind_param("ssssssiis", $full_name, $roll_no, $department, $email, $hashed_pass, $role, $default_credits, $default_green, $avatar_seed);

            if ($insert->execute()) {
                $_SESSION['user_id'] = $insert->insert_id;
                $_SESSION['full_name'] = $full_name;
                $_SESSION['role'] = $role;
                set_flash("Account registered! You have been credited 5 Skill Credits & 10 Green Points welcome bonus.", "success");
                header("Location: index.php");
                exit;
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | ONECAMPUS - Dayalbagh Educational Institute</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dei-emerald: #059669;
            --dei-emerald-dark: #047857;
        }
        body {
            background-color: #f8fafc;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            min-height: 100vh;
        }
        .auth-brand-pane {
            background: linear-gradient(135deg, #059669 0%, #065f46 100%);
            color: #ffffff;
            position: relative;
            overflow: hidden;
        }
        .btn-emerald {
            background-color: var(--dei-emerald);
            color: #ffffff;
            border: none;
        }
        .btn-emerald:hover {
            background-color: var(--dei-emerald-dark);
            color: #ffffff;
        }
    </style>
</head>
<body class="d-flex align-items-center py-4">

<div class="container my-auto">
    <div class="row g-0 justify-content-center shadow-lg rounded-4 overflow-hidden bg-white border">
        
        <!-- Left Hero / Brand Pane -->
        <div class="col-lg-5 p-5 auth-brand-pane d-none d-lg-flex flex-column justify-content-between">
            <div>
                <div class="d-flex align-items-center gap-2 mb-3">
                    <span class="badge bg-white text-dark px-3 py-2 rounded-pill fw-bold">
                        <i class="fa-solid fa-graduation-cap text-success me-1"></i> DEI AGRA
                    </span>
                    <span class="badge bg-emerald-700 text-white-50 px-2 py-1 rounded">Student Enrollment</span>
                </div>
                <h1 class="display-6 fw-bold tracking-tight mb-2">Join ONECAMPUS</h1>
                <p class="lead fs-6 text-white-75 mb-4">
                    Unlock immediate access to Dayalbagh Educational Institute's smart room tracking, cashless peer learning barter, and eco-initiatives.
                </p>

                <div class="p-3 rounded-3 bg-white bg-opacity-10 border border-white border-opacity-25 mb-4">
                    <h6 class="fw-bold mb-1"><i class="fa-solid fa-gift text-warning me-1"></i> Welcome Starter Package</h6>
                    <ul class="list-unstyled small mb-0 text-white-75">
                        <li><i class="fa-solid fa-check text-warning me-1"></i> <strong>5 Skill Credits</strong> for booking 1-on-1 tutoring sessions</li>
                        <li><i class="fa-solid fa-check text-warning me-1"></i> <strong>10 Green Points</strong> to kick off your DEI Eco badge</li>
                        <li><i class="fa-solid fa-check text-warning me-1"></i> Real-time vacancy updates for all faculty labs</li>
                    </ul>
                </div>
            </div>

            <div class="pt-4 border-top border-white border-opacity-25 small text-white-50">
                <i class="fa-solid fa-shield-halved me-1"></i> Official Portal for DEI Students, Researchers & Faculty
            </div>
        </div>

        <!-- Right Register Form Pane -->
        <div class="col-lg-7 p-4 p-md-5">
            <div class="mb-4">
                <h3 class="fw-bold text-dark mb-1">Create Student Profile</h3>
                <p class="text-secondary small mb-0">Join your peers across DEI Engineering, Science, and Arts faculties.</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger py-2 small" role="alert">
                    <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form action="register.php" method="POST">
                <div class="row g-3 mb-3">
                    <div class="col-md-7">
                        <label class="form-label small fw-semibold text-secondary">Full Name</label>
                        <input type="text" name="full_name" class="form-control bg-light" placeholder="e.g. Tanmay Satsangi" required>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label small fw-semibold text-secondary">Roll Number</label>
                        <input type="text" name="roll_no" class="form-control bg-light" placeholder="e.g. 230145" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Faculty / Department</label>
                    <select name="department" class="form-select bg-light" required>
                        <option value="" disabled selected>Select your Faculty</option>
                        <option value="Faculty of Engineering - Mechanical">Faculty of Engineering - Mechanical</option>
                        <option value="Faculty of Engineering - Electrical">Faculty of Engineering - Electrical</option>
                        <option value="Faculty of Science - Physics">Faculty of Science - Physics</option>
                        <option value="Faculty of Science - Chemistry">Faculty of Science - Chemistry</option>
                        <option value="Faculty of Science - Mathematics & Computer Science">Faculty of Science - Mathematics & CS</option>
                        <option value="Multimedia Lab & Design">Multimedia Lab & Design</option>
                        <option value="Faculty of Arts & Music">Faculty of Arts & Music</option>
                        <option value="Faculty of Social Sciences">Faculty of Social Sciences</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Institute / Personal Email</label>
                    <input type="email" name="email" class="form-control bg-light" placeholder="e.g. student@dei.ac.in" required>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-semibold text-secondary">Create Password</label>
                    <input type="password" name="password" class="form-control bg-light" placeholder="Minimum 6 characters" required minlength="6">
                </div>

                <button type="submit" class="btn btn-emerald w-100 py-2 fw-semibold rounded-3 shadow-sm mb-3">
                    <i class="fa-solid fa-user-plus me-1"></i> Complete Registration & Claim 5 Credits
                </button>

                <div class="text-center small text-secondary">
                    Already registered? 
                    <a href="login.php" class="text-success fw-semibold text-decoration-none">Sign In directly</a>
                </div>
            </form>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
