<?php
require_once 'db.php';
require_login();

$user = current_user();

// Handle Room Status Toggle Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_room') {
    $room_id = intval($_POST['room_id'] ?? 0);
    $updater = $user['full_name'];

    if ($room_id > 0) {
        $stmt = $conn->prepare("UPDATE rooms SET status = CASE WHEN status = 'Available' THEN 'Occupied' ELSE 'Available' END, updated_by = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("si", $updater, $room_id);
        if ($stmt->execute()) {
            set_flash("Room occupancy status updated successfully!", "success");
        } else {
            set_flash("Could not update room status.", "danger");
        }
    }
    header("Location: index.php");
    exit;
}

// Fetch Rooms
$building_filter = clean($_GET['building'] ?? 'all');
$status_filter = clean($_GET['status'] ?? 'all');
$search_query = clean($_GET['search'] ?? '');

$sql = "SELECT * FROM rooms WHERE 1=1";
$params = [];
$types = "";

if ($building_filter !== 'all' && !empty($building_filter)) {
    $sql .= " AND building_name = ?";
    $params[] = $building_filter;
    $types .= "s";
}
if ($status_filter !== 'all' && !empty($status_filter)) {
    $sql .= " AND status = ?";
    $params[] = $status_filter;
    $types .= "s";
}
if (!empty($search_query)) {
    $sql .= " AND (room_name LIKE ? OR building_name LIKE ? OR current_activity LIKE ?)";
    $like_term = "%" . $search_query . "%";
    $params[] = $like_term;
    $params[] = $like_term;
    $params[] = $like_term;
    $types .= "sss";
}
$sql .= " ORDER BY status ASC, building_name ASC, room_name ASC";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$rooms = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Quick Stats Calculation
$total_rooms = count($rooms);
$available_count = 0;
$occupied_count = 0;

$all_rooms_res = $conn->query("SELECT status, COUNT(*) as cnt FROM rooms GROUP BY status");
while ($row = $all_rooms_res->fetch_assoc()) {
    if ($row['status'] === 'Available') $available_count = $row['cnt'];
    if ($row['status'] === 'Occupied') $occupied_count = $row['cnt'];
}
$overall_total = $available_count + $occupied_count;

// Buildings list for filter
$buildings = [
    'all' => 'All Faculties & Blocks',
    'Faculty of Engineering' => 'Faculty of Engineering',
    'Faculty of Science' => 'Faculty of Science',
    'Multimedia Lab' => 'Multimedia Lab',
    'Central Library' => 'Central Library',
    'Seminar Hall Complex' => 'Seminar Hall Complex',
    'DEI Canteen & Campus Hub' => 'DEI Canteen Hub'
];

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartSpace Dashboard | ONECAMPUS - Dayalbagh Educational Institute</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dei-emerald: #059669;
            --dei-emerald-light: #10b981;
            --dei-amber: #f59e0b;
            --dei-coral: #ef4444;
        }
        body {
            background-color: #f8fafc;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            color: #1e293b;
        }
        .navbar-dei {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
        }
        .nav-link.active-tab {
            color: var(--dei-emerald) !important;
            font-weight: 600;
            border-bottom: 2px solid var(--dei-emerald);
        }
        .card-stat {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .card-stat:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
        }
        .room-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            transition: all 0.25s ease;
        }
        .room-card:hover {
            box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.07);
            border-color: #cbd5e1;
        }
        .pulse-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
        }
        .pulse-available {
            background-color: #10b981;
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.25);
            animation: pulse-green 2s infinite;
        }
        .pulse-occupied {
            background-color: #ef4444;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.25);
        }
        @keyframes pulse-green {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
        }
        .btn-emerald {
            background-color: var(--dei-emerald);
            color: #ffffff;
        }
        .btn-emerald:hover {
            background-color: #047857;
            color: #ffffff;
        }
        .badge-credit {
            background-color: #fef3c7;
            color: #92400e;
            border: 1px solid #fde68a;
        }
        .badge-green {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
    </style>
</head>
<body>

<!-- Navigation Header -->
<nav class="navbar navbar-expand-lg navbar-dei sticky-top py-2">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold text-dark" href="index.php">
            <span class="bg-success text-white px-2 py-1 rounded-3 fs-6">
                <i class="fa-solid fa-graduation-cap"></i>
            </span>
            <span>ONECAMPUS <span class="badge bg-light text-success border border-success-subtle fw-normal ms-1" style="font-size: 11px;">DEI Agra</span></span>
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3 gap-1">
                <li class="nav-item">
                    <a class="nav-link px-3 active-tab" href="index.php">
                        <i class="fa-solid fa-door-open me-1"></i> SmartSpace
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 text-secondary" href="peerlearn.php">
                        <i class="fa-solid fa-handshake-simple me-1"></i> PeerLearn
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 text-secondary" href="ecopulse.php">
                        <i class="fa-solid fa-leaf me-1"></i> EcoPulse
                    </a>
                </li>
            </ul>

            <!-- Global Search Bar in Header -->
            <form action="index.php" method="GET" class="d-flex mx-lg-3 my-2 my-lg-0 flex-grow-1" style="max-width: 320px;">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light border-end-0 text-muted rounded-start-pill ps-3">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </span>
                    <input type="text" name="search" class="form-control bg-light border-start-0 rounded-end-pill" placeholder="Search rooms, skills, reports..." value="<?= htmlspecialchars($_GET['search'] ?? ''); ?>">
                </div>
            </form>

            <!-- User Status & Profile Chips -->
            <div class="d-flex align-items-center gap-3">
                <div class="d-none d-md-flex align-items-center gap-2">
                    <span class="badge badge-credit px-2 py-1 rounded-pill small fw-semibold" title="Skill Credits available for barter">
                        <i class="fa-solid fa-coins text-warning me-1"></i> <?= $user['skill_credits']; ?> Credits
                    </span>
                    <span class="badge badge-green px-2 py-1 rounded-pill small fw-semibold" title="Green Points earned for eco-initiatives">
                        <i class="fa-solid fa-award text-success me-1"></i> <?= $user['green_points']; ?> Karma
                    </span>
                </div>

                <div class="dropdown">
                    <button class="btn btn-light btn-sm dropdown-toggle rounded-pill px-3 border" type="button" data-bs-toggle="dropdown">
                        <i class="fa-solid fa-circle-user text-secondary me-1"></i> <?= htmlspecialchars($user['full_name']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                        <li class="px-3 py-1">
                            <small class="text-muted d-block"><?= htmlspecialchars($user['department']); ?></small>
                            <span class="badge bg-secondary-subtle text-secondary text-uppercase" style="font-size: 10px;"><?= $user['role']; ?></span>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>

<main class="container py-4">

    <!-- Flash Alert -->
    <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type']; ?> alert-dismissible fade show rounded-3 shadow-sm mb-4" role="alert">
            <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flash['text']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Top Greeting Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-2 border-bottom">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <span class="text-muted small" id="liveClock"><i class="fa-regular fa-clock me-1"></i> Updating time...</span>
                <span class="text-secondary opacity-50">·</span>
                <span class="badge bg-success-subtle text-success px-2 py-0.5 rounded">Dayalbagh Campus Active</span>
            </div>
            <h2 class="fw-bold tracking-tight mb-0">Good Day, <?= htmlspecialchars(explode(' ', $user['full_name'])[0]); ?>! 👋</h2>
            <p class="text-secondary small mb-0">Check live vacancy across DEI lecture halls, labs, and reading pavilions.</p>
        </div>

        <div class="d-flex gap-2">
            <a href="peerlearn.php" class="btn btn-outline-success btn-sm px-3 rounded-pill">
                <i class="fa-solid fa-magnifying-glass me-1"></i> Find a Tutor
            </a>
            <a href="ecopulse.php" class="btn btn-emerald btn-sm px-3 rounded-pill">
                <i class="fa-solid fa-camera me-1"></i> Report Issue
            </a>
        </div>
    </div>

    <!-- Quick Stats Cards Row -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card-stat p-3">
                <div class="text-secondary small fw-medium mb-1">Available Rooms</div>
                <div class="d-flex align-items-center justify-content-between">
                    <span class="fs-3 fw-bold text-success font-monospace"><?= $available_count; ?></span>
                    <span class="p-2 bg-success-subtle text-success rounded-circle">
                        <i class="fa-solid fa-door-open"></i>
                    </span>
                </div>
                <small class="text-muted" style="font-size: 12px;">Ready for study / sessions</small>
            </div>
        </div>

        <div class="col-6 col-md-3">
            <div class="card-stat p-3">
                <div class="text-secondary small fw-medium mb-1">Occupied / In Use</div>
                <div class="d-flex align-items-center justify-content-between">
                    <span class="fs-3 fw-bold text-danger font-monospace"><?= $occupied_count; ?></span>
                    <span class="p-2 bg-danger-subtle text-danger rounded-circle">
                        <i class="fa-solid fa-chalkboard-user"></i>
                    </span>
                </div>
                <small class="text-muted" style="font-size: 12px;">Lectures & Labs in progress</small>
            </div>
        </div>

        <div class="col-6 col-md-3">
            <div class="card-stat p-3">
                <div class="text-secondary small fw-medium mb-1">My Skill Credits</div>
                <div class="d-flex align-items-center justify-content-between">
                    <span class="fs-3 fw-bold text-warning font-monospace"><?= $user['skill_credits']; ?></span>
                    <span class="p-2 bg-warning-subtle text-warning rounded-circle">
                        <i class="fa-solid fa-coins"></i>
                    </span>
                </div>
                <small class="text-muted" style="font-size: 12px;">Earn more by teaching peers</small>
            </div>
        </div>

        <div class="col-6 col-md-3">
            <div class="card-stat p-3">
                <div class="text-secondary small fw-medium mb-1">Eco Karma Points</div>
                <div class="d-flex align-items-center justify-content-between">
                    <span class="fs-3 fw-bold text-emerald font-monospace" style="color: #059669;"><?= $user['green_points']; ?></span>
                    <span class="p-2 bg-emerald-subtle rounded-circle" style="background-color: #d1fae5; color: #059669;">
                        <i class="fa-solid fa-seedling"></i>
                    </span>
                </div>
                <small class="text-muted" style="font-size: 12px;">Top 10% Campus Steward</small>
            </div>
        </div>
    </div>

    <!-- Main Workspace: SmartSpace Filter Bar & Grid + Side Trivia Widget -->
    <div class="row g-4">
        
        <!-- Left: SmartSpace Room Availability -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white mb-4">
                
                <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2 mb-3">
                    <div>
                        <h4 class="fw-bold mb-0">SmartSpace Live Availability</h4>
                        <p class="text-secondary small mb-0">Real-time status inspired by UIUC & UMich computing occupancy.</p>
                    </div>
                    <span class="badge bg-light text-secondary border">Showing <?= count($rooms); ?> Rooms</span>
                </div>

                <!-- Building & Status Filters -->
                <form action="index.php" method="GET" class="row g-2 mb-4">
                    <div class="col-md-7">
                        <select name="building" class="form-select form-select-sm" onchange="this.form.submit()">
                            <?php foreach ($buildings as $val => $lbl): ?>
                                <option value="<?= htmlspecialchars($val); ?>" <?= $building_filter === $val ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($lbl); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <div class="btn-group btn-group-sm w-100" role="group">
                            <a href="index.php?building=<?= urlencode($building_filter); ?>&status=all" class="btn <?= $status_filter === 'all' ? 'btn-dark' : 'btn-outline-secondary'; ?>">All</a>
                            <a href="index.php?building=<?= urlencode($building_filter); ?>&status=Available" class="btn <?= $status_filter === 'Available' ? 'btn-success' : 'btn-outline-secondary'; ?>">Available</a>
                            <a href="index.php?building=<?= urlencode($building_filter); ?>&status=Occupied" class="btn <?= $status_filter === 'Occupied' ? 'btn-danger' : 'btn-outline-secondary'; ?>">Occupied</a>
                        </div>
                    </div>
                </form>

                <!-- Interactive Visual Map & Floor Plan Component -->
                <div class="card border border-light-subtle rounded-3 overflow-hidden mb-4 shadow-xs">
                    <div class="card-header bg-light-subtle d-flex flex-column flex-sm-row justify-content-between align-items-sm-center py-2 px-3 gap-2">
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge bg-success-subtle text-success px-2 py-1 rounded-pill small fw-semibold">
                                <i class="fa-solid fa-map-location-dot me-1"></i> Interactive Floor Plan
                            </span>
                            <span class="text-secondary small fw-medium">Facility Architectural Blueprint</span>
                        </div>
                        <span class="text-muted small" style="font-size: 11px;">
                            <i class="fa-solid fa-hand-pointer text-success me-1"></i> Click room in map to toggle occupancy
                        </span>
                    </div>

                    <div class="p-3 bg-white">
                        <!-- Facility Selection Tabs on Map -->
                        <div class="d-flex gap-1 overflow-x-auto pb-2 mb-3">
                            <a href="index.php?building=Faculty+of+Engineering" class="btn btn-sm <?= ($building_filter === 'Faculty of Engineering' || $building_filter === 'all') ? 'btn-success' : 'btn-outline-secondary'; ?> rounded-pill px-3 py-1" style="font-size: 12px; white-space: nowrap;">
                                <i class="fa-solid fa-gear me-1"></i> Faculty of Engineering
                            </a>
                            <a href="index.php?building=Faculty+of+Science" class="btn btn-sm <?= ($building_filter === 'Faculty of Science') ? 'btn-success' : 'btn-outline-secondary'; ?> rounded-pill px-3 py-1" style="font-size: 12px; white-space: nowrap;">
                                <i class="fa-solid fa-flask me-1"></i> Faculty of Science
                            </a>
                            <a href="index.php?building=Central+Library" class="btn btn-sm <?= ($building_filter === 'Central Library') ? 'btn-success' : 'btn-outline-secondary'; ?> rounded-pill px-3 py-1" style="font-size: 12px; white-space: nowrap;">
                                <i class="fa-solid fa-book-open me-1"></i> Central Library
                            </a>
                            <a href="index.php?building=Multimedia+Lab" class="btn btn-sm <?= ($building_filter === 'Multimedia Lab') ? 'btn-success' : 'btn-outline-secondary'; ?> rounded-pill px-3 py-1" style="font-size: 12px; white-space: nowrap;">
                                <i class="fa-solid fa-vr-cardboard me-1"></i> Multimedia Lab
                            </a>
                        </div>

                        <!-- Interactive SVG Map Display -->
                        <div class="border rounded-3 p-2 bg-light-subtle text-center overflow-x-auto">
                            <svg viewBox="0 0 760 380" class="w-100" style="max-height: 380px; min-width: 580px;">
                                <!-- Grid Defs -->
                                <defs>
                                    <pattern id="phGrid" width="20" height="20" patternUnits="userSpaceOnUse">
                                        <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#e2e8f0" stroke-width="0.8"/>
                                    </pattern>
                                </defs>
                                <rect width="100%" height="100%" fill="url(#phGrid)" rx="6"/>

                                <!-- Perimeter Wall -->
                                <rect x="20" y="15" width="720" height="350" fill="none" stroke="#94a3b8" stroke-width="2" stroke-dasharray="6,4" rx="10"/>

                                <!-- Central Corridor -->
                                <rect x="40" y="155" width="680" height="40" fill="#f1f5f9" stroke="#cbd5e1" stroke-width="1.5" rx="4"/>
                                <text x="380" y="180" text-anchor="middle" fill="#64748b" font-size="10" font-weight="bold" letter-spacing="2">CENTRAL BREEZEWAY & SOLAR CORRIDOR</text>

                                <!-- North & South Entrances -->
                                <circle cx="380" cy="15" r="5" fill="#059669"/>
                                <text x="380" y="30" text-anchor="middle" fill="#059669" font-size="9" font-weight="bold">▲ NORTH QUADRANGLE ENTRY</text>

                                <circle cx="380" cy="365" r="5" fill="#059669"/>
                                <text x="380" y="358" text-anchor="middle" fill="#059669" font-size="9" font-weight="bold">▲ SOUTH SOLAR PORTICO</text>

                                <!-- Interactive Room 1: E-204 / Lecture Hall -->
                                <g class="map-room-btn" onclick="submitToggleRoom(1)" style="cursor: pointer;">
                                    <rect x="50" y="40" width="190" height="100" fill="#ecfdf5" stroke="#10b981" stroke-width="2" rx="6"/>
                                    <rect x="60" y="48" width="40" height="16" fill="#a7f3d0" rx="3"/>
                                    <text x="80" y="60" text-anchor="middle" fill="#065f46" font-size="9" font-weight="bold">E-204</text>
                                    <circle cx="225" cy="55" r="4" fill="#10b981"/>
                                    <text x="60" y="80" fill="#0f172a" font-size="11" font-weight="bold">Lecture Hall E-204</text>
                                    <text x="60" y="96" fill="#64748b" font-size="9">Classroom · Cap: 65</text>
                                    <rect x="60" y="110" width="170" height="18" fill="#10b981" rx="3"/>
                                    <text x="145" y="123" text-anchor="middle" fill="#ffffff" font-size="9" font-weight="bold">AVAILABLE (CLICK TO TOGGLE)</text>
                                </g>

                                <!-- Interactive Room 2: CAD Lab -->
                                <g class="map-room-btn" onclick="submitToggleRoom(2)" style="cursor: pointer;">
                                    <rect x="260" y="40" width="220" height="100" fill="#fff1f2" stroke="#f43f5e" stroke-width="2" rx="6"/>
                                    <rect x="270" y="48" width="55" height="16" fill="#fecdd3" rx="3"/>
                                    <text x="297" y="60" text-anchor="middle" fill="#881337" font-size="9" font-weight="bold">CAD-01</text>
                                    <circle cx="465" cy="55" r="4" fill="#ef4444"/>
                                    <text x="270" y="80" fill="#0f172a" font-size="11" font-weight="bold">Advanced CAD/CAM Lab</text>
                                    <text x="270" y="96" fill="#64748b" font-size="9">Computer Lab · Cap: 40</text>
                                    <rect x="270" y="110" width="200" height="18" fill="#f43f5e" rx="3"/>
                                    <text x="370" y="123" text-anchor="middle" fill="#ffffff" font-size="9" font-weight="bold">OCCUPIED (CLICK TO TOGGLE)</text>
                                </g>

                                <!-- Room 3: E-202 Mechatronics -->
                                <g class="map-room-btn" style="cursor: pointer;" onclick="alert('Room E-202: Maintenance in progress. See EcoPulse for tickets.')">
                                    <rect x="500" y="40" width="210" height="100" fill="#f8fafc" stroke="#cbd5e1" stroke-width="1.5" rx="6"/>
                                    <text x="515" y="70" fill="#0f172a" font-size="11" font-weight="bold">Mechatronics & IoT Bay</text>
                                    <text x="515" y="88" fill="#64748b" font-size="9">Computer Lab · Cap: 35</text>
                                    <rect x="515" y="105" width="180" height="18" fill="#94a3b8" rx="3"/>
                                    <text x="605" y="118" text-anchor="middle" fill="#ffffff" font-size="9" font-weight="bold">RESERVED (IOT PRACTICAL)</text>
                                </g>

                                <!-- Room 4: South Wing E-101 -->
                                <g class="map-room-btn" onclick="submitToggleRoom(3)" style="cursor: pointer;">
                                    <rect x="50" y="210" width="200" height="110" fill="#ecfdf5" stroke="#10b981" stroke-width="2" rx="6"/>
                                    <rect x="60" y="218" width="40" height="16" fill="#a7f3d0" rx="3"/>
                                    <text x="80" y="230" text-anchor="middle" fill="#065f46" font-size="9" font-weight="bold">S-102</text>
                                    <text x="60" y="250" fill="#0f172a" font-size="11" font-weight="bold">Quantum Physics S-102</text>
                                    <text x="60" y="268" fill="#64748b" font-size="9">Classroom · Cap: 45</text>
                                    <rect x="60" y="285" width="180" height="18" fill="#10b981" rx="3"/>
                                    <text x="150" y="298" text-anchor="middle" fill="#ffffff" font-size="9" font-weight="bold">AVAILABLE (CLICK TO OCCUPY)</text>
                                </g>

                                <!-- Room 5: South Wing Robotics Prototyping -->
                                <g class="map-room-btn" onclick="submitToggleRoom(5)" style="cursor: pointer;">
                                    <rect x="270" y="210" width="210" height="110" fill="#ecfdf5" stroke="#10b981" stroke-width="2" rx="6"/>
                                    <rect x="280" y="218" width="45" height="16" fill="#a7f3d0" rx="3"/>
                                    <text x="302" y="230" text-anchor="middle" fill="#065f46" font-size="9" font-weight="bold">M-01</text>
                                    <text x="280" y="250" fill="#0f172a" font-size="11" font-weight="bold">Creative UI/UX & VR Suite</text>
                                    <text x="280" y="268" fill="#64748b" font-size="9">Computer Lab · Cap: 32</text>
                                    <rect x="280" y="285" width="190" height="18" fill="#10b981" rx="3"/>
                                    <text x="375" y="298" text-anchor="middle" fill="#ffffff" font-size="9" font-weight="bold">AVAILABLE (CLICK TO OCCUPY)</text>
                                </g>

                                <!-- Room 6: South Wing Library Stacks Annex -->
                                <g class="map-room-btn" onclick="submitToggleRoom(6)" style="cursor: pointer;">
                                    <rect x="500" y="210" width="210" height="110" fill="#ecfdf5" stroke="#10b981" stroke-width="2" rx="6"/>
                                    <rect x="510" y="218" width="45" height="16" fill="#a7f3d0" rx="3"/>
                                    <text x="532" y="230" text-anchor="middle" fill="#065f46" font-size="9" font-weight="bold">LIB-01</text>
                                    <text x="510" y="250" fill="#0f172a" font-size="11" font-weight="bold">Quiet Study Hall - 1st Floor</text>
                                    <text x="510" y="268" fill="#64748b" font-size="9">Reading Hall · Cap: 120</text>
                                    <rect x="510" y="285" width="190" height="18" fill="#10b981" rx="3"/>
                                    <text x="605" y="298" text-anchor="middle" fill="#ffffff" font-size="9" font-weight="bold">AVAILABLE (CLICK TO OCCUPY)</text>
                                </g>
                            </svg>
                        </div>

                        <!-- Map Legend Footer -->
                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-2 pt-2 border-top small text-secondary" style="font-size: 11px;">
                            <div class="d-flex align-items-center gap-3">
                                <span><span class="badge bg-success-subtle text-success border border-success-subtle me-1">■</span> Available</span>
                                <span><span class="badge bg-danger-subtle text-danger border border-danger-subtle me-1">■</span> Occupied</span>
                                <span><span class="badge bg-secondary-subtle text-secondary me-1">■</span> Corridors & Hallways</span>
                            </div>
                            <span class="text-success"><i class="fa-solid fa-bolt me-1"></i> DEI Solar Microgrid Monitored</span>
                        </div>
                    </div>
                </div>

                <!-- Hidden form for map clicks -->
                <form id="mapToggleForm" action="index.php" method="POST" style="display: none;">
                    <input type="hidden" name="action" value="toggle_room">
                    <input type="hidden" name="room_id" id="mapRoomIdInput" value="">
                </form>

                <script>
                function submitToggleRoom(roomId) {
                    document.getElementById('mapRoomIdInput').value = roomId;
                    document.getElementById('mapToggleForm').submit();
                }
                </script>

                <!-- Rooms Grid Header -->
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="fw-bold text-dark mb-0"><i class="fa-solid fa-list-check me-1 text-success"></i> Facility Rooms & Labs Grid</h6>
                    <small class="text-muted"><?= count($rooms); ?> facilities listed</small>
                </div>

                <!-- Rooms Grid -->
                <div class="row g-3">
                    <?php if (empty($rooms)): ?>
                        <div class="col-12 py-5 text-center text-muted">
                            <i class="fa-solid fa-magnifying-glass fs-2 mb-2 d-block opacity-50"></i>
                            No rooms matched your filter selection. Try selecting "All Faculties".
                        </div>
                    <?php else: ?>
                        <?php foreach ($rooms as $room): ?>
                            <?php $isAvail = ($room['status'] === 'Available'); ?>
                            <div class="col-md-6">
                                <div class="room-card p-3 h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <span class="badge <?= $isAvail ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'; ?> px-2 py-1 rounded-pill small fw-semibold">
                                                <span class="pulse-dot <?= $isAvail ? 'pulse-available' : 'pulse-occupied'; ?> me-1"></span>
                                                <?= $room['status']; ?>
                                            </span>
                                            <span class="text-muted small" style="font-size: 11px;">
                                                <i class="fa-solid fa-users me-1"></i> Cap: <?= $room['capacity']; ?>
                                            </span>
                                        </div>

                                        <h6 class="fw-bold text-dark mb-1"><?= htmlspecialchars($room['room_name']); ?></h6>
                                        <div class="text-secondary small mb-2">
                                            <i class="fa-solid fa-building-columns me-1 text-muted"></i> <?= htmlspecialchars($room['building_name']); ?>
                                            <span class="text-muted">· <?= htmlspecialchars($room['room_type']); ?></span>
                                        </div>

                                        <div class="p-2 rounded bg-light small text-secondary mb-3">
                                            <strong>Current Status:</strong> <?= htmlspecialchars($room['current_activity']); ?>
                                        </div>
                                    </div>

                                    <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                        <span class="text-muted" style="font-size: 11px;">
                                            <i class="fa-regular fa-clock me-1"></i> Updated <?= time_ago($room['updated_at']); ?>
                                        </span>

                                        <!-- 1-Click Status Toggle Form -->
                                        <form action="index.php" method="POST" class="m-0">
                                            <input type="hidden" name="action" value="toggle_room">
                                            <input type="hidden" name="room_id" value="<?= $room['id']; ?>">
                                            <button type="submit" class="btn btn-sm <?= $isAvail ? 'btn-outline-danger' : 'btn-outline-success'; ?> rounded-pill px-3 py-1" style="font-size: 12px;">
                                                <?= $isAvail ? 'Mark Occupied' : 'Mark Available'; ?>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

            </div>
        </div>

        <!-- Right: Study Break Spin-Wheel & Campus Trivia (Anti-Boredom Widget) -->
        <div class="col-lg-4">
            
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white mb-4">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h5 class="fw-bold mb-0">🎯 Study Break & Trivia</h5>
                    <span class="badge bg-warning-subtle text-dark">Quick Refresh</span>
                </div>
                <p class="text-secondary small mb-3">
                    Stressed by exams? Spin for a DEI heritage fact or campus brain-teaser!
                </p>

                <!-- Interactive Mini-Widget -->
                <div class="p-3 rounded-3 text-center mb-3" style="background: linear-gradient(135deg, #ecfdf5 0%, #fef3c7 100%); border: 1px dashed #6ee7b7;">
                    <div class="fs-1 mb-2" id="triviaEmoji">💡</div>
                    <h6 class="fw-bold text-dark mb-1" id="triviaQuestion">Click below to generate a study break question!</h6>
                    <p class="text-secondary small mb-3" id="triviaAnswer" style="display: none;"></p>
                    
                    <div class="d-flex gap-2 justify-content-center">
                        <button type="button" class="btn btn-emerald btn-sm px-3 rounded-pill" onclick="spinTrivia()">
                            <i class="fa-solid fa-arrows-rotate me-1"></i> Spin Trivia
                        </button>
                        <button type="button" class="btn btn-outline-secondary btn-sm px-3 rounded-pill" id="btnReveal" onclick="revealAnswer()" style="display: none;">
                            Show Answer
                        </button>
                    </div>
                </div>

                <div class="small text-muted border-top pt-2">
                    <i class="fa-solid fa-lightbulb text-warning me-1"></i> Tip: Use vacant classrooms in Engineering E-204 for quiet mock interviews.
                </div>
            </div>

            <!-- DEI Campus Quick Links Card -->
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <h6 class="fw-bold mb-3"><i class="fa-solid fa-compass text-success me-2"></i>DEI Campus Quick Shortcuts</h6>
                <div class="list-group list-group-flush small">
                    <a href="peerlearn.php" class="list-group-item list-group-item-action px-0 py-2 d-flex justify-content-between align-items-center">
                        <span><i class="fa-solid fa-code text-primary me-2"></i>Offer Python / CAD Mentorship</span>
                        <span class="badge bg-light text-dark">+1 Credit</span>
                    </a>
                    <a href="ecopulse.php" class="list-group-item list-group-item-action px-0 py-2 d-flex justify-content-between align-items-center">
                        <span><i class="fa-solid fa-triangle-exclamation text-warning me-2"></i>Report Dripping Tap / Fan</span>
                        <span class="badge bg-success-subtle text-success">+10 Points</span>
                    </a>
                    <div class="list-group-item px-0 py-2 text-muted">
                        <i class="fa-solid fa-shield-cat text-secondary me-2"></i>DEI Caretaker Desk: Intercom #2041
                    </div>
                </div>
            </div>

        </div>

    </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Live Clock
function updateClock() {
    const el = document.getElementById('liveClock');
    if (el) {
        const now = new Date();
        el.innerHTML = '<i class="fa-regular fa-clock me-1"></i> ' + now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' · DEI Agra';
    }
}
setInterval(updateClock, 1000);
updateClock();

// Trivia Questions Array
const DEI_TRIVIA = [
    {
        q: "What is Dayalbagh Educational Institute's foundational motto of life?",
        a: "Answer: 'Work is Worship' and synthesis of Science with Spirituality!",
        emoji: "🏛️"
    },
    {
        q: "Which faculty at DEI is renowned for pioneering solar microgrids and electric vehicle labs?",
        a: "Answer: Faculty of Engineering, Dayalbagh!",
        emoji: "⚡"
    },
    {
        q: "What is the unique zero-waste dairy and agricultural system practiced in Dayalbagh?",
        a: "Answer: The community-managed Gaushala & Dairy Farming Cooperative!",
        emoji: "🌱"
    },
    {
        q: "Quick Brain Teaser: What gets wetter the more it dries?",
        a: "Answer: A towel! Time to wash your face and get back to studying!",
        emoji: "🧠"
    },
    {
        q: "Which coding language was originally named 'Oak' before its release?",
        a: "Answer: Java! Invented by James Gosling in 1995.",
        emoji: "☕"
    }
];

let currentTriviaIndex = 0;

function spinTrivia() {
    currentTriviaIndex = Math.floor(Math.random() * DEI_TRIVIA.length);
    const item = DEI_TRIVIA[currentTriviaIndex];
    document.getElementById('triviaQuestion').innerText = item.q;
    document.getElementById('triviaEmoji').innerText = item.emoji;
    document.getElementById('triviaAnswer').style.display = 'none';
    document.getElementById('btnReveal').style.display = 'inline-block';
}

function revealAnswer() {
    const item = DEI_TRIVIA[currentTriviaIndex];
    const ansEl = document.getElementById('triviaAnswer');
    ansEl.innerText = item.a;
    ansEl.style.display = 'block';
    document.getElementById('btnReveal').style.display = 'none';
}
</script>
</body>
</html>
