<?php
require_once 'db.php';

// Redirect if already logged in
if (is_logged_in()) {
    header("Location: index.php");
    exit;
}

$error = '';

// Handle 1-Click Demo Logins
if (isset($_GET['demo'])) {
    $demo_type = clean($_GET['demo']);
    $demo_email = '';
    
    if ($demo_type === 'admin') {
        $demo_email = 'admin@dei.ac.in';
    } elseif ($demo_type === 'student_priya') {
        $demo_email = 'priya@dei.ac.in';
    } else {
        $demo_email = 'aarav@dei.ac.in';
    }

    $stmt = $conn->prepare("SELECT id, full_name, role FROM users WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $demo_email);
    $stmt->execute();
    $res = $stmt->get_result();
    
    if ($user = $res->fetch_assoc()) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'];
        set_flash("Welcome back, " . htmlspecialchars($user['full_name']) . "! (Logged in via 1-Click Demo)", "success");
        header("Location: index.php");
        exit;
    }
}

// Handle Normal Form Login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = "Please fill in all credentials.";
    } else {
        $stmt = $conn->prepare("SELECT id, full_name, password, role FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($user = $res->fetch_assoc()) {
            if (password_verify($password, $user['password']) || $password === 'student123' || $password === 'admin123') {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role'] = $user['role'];
                set_flash("Welcome to ONECAMPUS, " . htmlspecialchars($user['full_name']) . "!", "success");
                header("Location: index.php");
                exit;
            } else {
                $error = "Incorrect password. Default demo password is 'student123' or 'admin123'.";
            }
        } else {
            $error = "No account found with this email address.";
        }
    }
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | ONECAMPUS - Dayalbagh Educational Institute</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dei-emerald: #059669;
            --dei-emerald-dark: #047857;
            --dei-amber: #f59e0b;
        }
        body {
            background-color: #f8fafc;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            min-height: 100vh;
        }
        .auth-brand-pane {
            background: linear-gradient(135deg, #059669 0%, #065f46 100%);
            color: #ffffff;
            position: relative;
            overflow: hidden;
        }
        .auth-brand-pane::after {
            content: "";
            position: absolute;
            top: -50px;
            right: -50px;
            width: 250px;
            height: 250px;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 50%;
        }
        .btn-emerald {
            background-color: var(--dei-emerald);
            color: #ffffff;
            border: none;
            transition: all 0.2s ease;
        }
        .btn-emerald:hover {
            background-color: var(--dei-emerald-dark);
            color: #ffffff;
            transform: translateY(-1px);
        }
        .demo-card {
            border: 1px dashed #cbd5e1;
            background-color: #f8fafc;
            border-radius: 12px;
            transition: all 0.2s ease;
        }
        .demo-card:hover {
            border-color: var(--dei-emerald);
            background-color: #ecfdf5;
        }
    </style>
</head>
<body class="d-flex align-items-center py-4">

<div class="container my-auto">
    <div class="row g-0 justify-content-center shadow-lg rounded-4 overflow-hidden bg-white border">
        
        <!-- Left Hero / Brand Pane (Hidden on small mobile) -->
        <div class="col-lg-5 p-5 auth-brand-pane d-none d-lg-flex flex-column justify-content-between">
            <div>
                <div class="d-flex align-items-center gap-2 mb-3">
                    <span class="badge bg-white text-dark px-3 py-2 rounded-pill fw-bold">
                        <i class="fa-solid fa-graduation-cap text-success me-1"></i> DEI AGRA
                    </span>
                    <span class="badge bg-emerald-700 text-white-50 px-2 py-1 rounded">DEI Edition</span>
                </div>
                <h1 class="display-6 fw-bold tracking-tight mb-2">ONECAMPUS</h1>
                <p class="lead fs-6 text-white-75 mb-4">
                    Dayalbagh Educational Institute's unified smart portal for finding open classrooms, peer skill-barter, and campus care.
                </p>

                <div class="space-y-3">
                    <div class="d-flex align-items-start gap-3 mb-3">
                        <div class="bg-white bg-opacity-20 p-2 rounded-3 text-white">
                            <i class="fa-solid fa-door-open fs-5"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0">SmartSpace Finder</h6>
                            <small class="text-white-75">Live occupancy status of Engineering, Science & Library labs.</small>
                        </div>
                    </div>
                    <div class="d-flex align-items-start gap-3 mb-3">
                        <div class="bg-white bg-opacity-20 p-2 rounded-3 text-white">
                            <i class="fa-solid fa-handshake-simple fs-5"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0">PeerLearn Credit Barter</h6>
                            <small class="text-white-75">Cashless 1-to-1 skill exchange: Learn Python, teach CAD.</small>
                        </div>
                    </div>
                    <div class="d-flex align-items-start gap-3">
                        <div class="bg-white bg-opacity-20 p-2 rounded-3 text-white">
                            <i class="fa-solid fa-leaf fs-5"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0">EcoPulse Campus Care</h6>
                            <small class="text-white-75">Report maintenance, save energy, and top the green leaderboard.</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="pt-4 border-top border-white border-opacity-25 small text-white-50">
                <i class="fa-solid fa-quote-left me-1"></i> "Work is Worship" — Dayalbagh Educational Institute (Deemed University)
            </div>
        </div>

        <!-- Right Login Form Pane -->
        <div class="col-lg-7 p-4 p-md-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold text-dark mb-1">Student & Faculty Sign In</h3>
                    <p class="text-secondary small mb-0">Enter your university credentials or click a 1-click demo button below.</p>
                </div>
                <div class="d-lg-none">
                    <span class="badge bg-success-subtle text-success px-2 py-1 rounded">ONECAMPUS</span>
                </div>
            </div>

            <!-- Flash Alert -->
            <?php if ($flash): ?>
                <div class="alert alert-<?= $flash['type']; ?> alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($flash['text']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger py-2 small" role="alert">
                    <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- 1-Click Presentation Demo Badges -->
            <div class="mb-4">
                <label class="form-label text-muted small fw-semibold text-uppercase tracking-wide mb-2">
                    ⚡ Instant Presentation Demo Logins
                </label>
                <div class="row g-2">
                    <div class="col-md-4 col-sm-6">
                        <a href="login.php?demo=student_aarav" class="text-decoration-none">
                            <div class="demo-card p-2 text-center h-100">
                                <div class="fw-bold text-dark small">Aarav (Student)</div>
                                <span class="text-muted" style="font-size: 11px;">B.Tech Engineering</span>
                                <div class="mt-1"><span class="badge bg-success" style="font-size: 10px;">Login ⚡</span></div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <a href="login.php?demo=student_priya" class="text-decoration-none">
                            <div class="demo-card p-2 text-center h-100">
                                <div class="fw-bold text-dark small">Priya (Student)</div>
                                <span class="text-muted" style="font-size: 11px;">M.Sc Physics</span>
                                <div class="mt-1"><span class="badge bg-success" style="font-size: 10px;">Login ⚡</span></div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 col-12">
                        <a href="login.php?demo=admin" class="text-decoration-none">
                            <div class="demo-card p-2 text-center h-100 bg-amber-50">
                                <div class="fw-bold text-dark small">Dr. Anand (Admin)</div>
                                <span class="text-muted" style="font-size: 11px;">Faculty Caretaker</span>
                                <div class="mt-1"><span class="badge bg-warning text-dark" style="font-size: 10px;">Admin 🔑</span></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <div class="position-relative text-center my-4">
                <hr class="text-secondary opacity-25">
                <span class="position-absolute top-50 start-50 translate-middle bg-white px-3 text-muted small">
                    or sign in manually
                </span>
            </div>

            <!-- Manual Form -->
            <form action="login.php" method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Institute Email</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0 text-secondary">
                            <i class="fa-solid fa-envelope"></i>
                        </span>
                        <input type="email" name="email" class="form-control bg-light border-start-0" placeholder="e.g. aarav@dei.ac.in" required value="aarav@dei.ac.in">
                    </div>
                </div>

                <div class="mb-3">
                    <div class="d-flex justify-content-between">
                        <label class="form-label small fw-semibold text-secondary">Password</label>
                        <span class="text-muted small">Default: <code>student123</code></span>
                    </div>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0 text-secondary">
                            <i class="fa-solid fa-lock"></i>
                        </span>
                        <input type="password" name="password" class="form-control bg-light border-start-0" placeholder="••••••••" required value="student123">
                    </div>
                </div>

                <button type="submit" class="btn btn-emerald w-100 py-2 fw-semibold rounded-3 shadow-sm mb-3">
                    <i class="fa-solid fa-right-to-bracket me-1"></i> Sign In to ONECAMPUS
                </button>

                <div class="text-center small text-secondary">
                    New to DEI ONECAMPUS? 
                    <a href="register.php" class="text-success fw-semibold text-decoration-none">Create a Student Profile</a>
                </div>
            </form>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
