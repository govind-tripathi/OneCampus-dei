-- ==========================================================
-- ONECAMPUS (DEI Edition) - Smart Campus Portal Database
-- Target: Dayalbagh Educational Institute (DEI), Agra
-- Engine: MySQL / MariaDB (Compatible with XAMPP, LAMP, AWebServer)
-- ==========================================================

CREATE DATABASE IF NOT EXISTS `onecampus` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `onecampus`;

-- Disable foreign key checks for clean teardown/rebuild if needed
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `eco_reports`;
DROP TABLE IF EXISTS `skill_transactions`;
DROP TABLE IF EXISTS `skills`;
DROP TABLE IF EXISTS `rooms`;
DROP TABLE IF EXISTS `users`;

SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------------------------------------
-- 1. Table structure for table `users`
-- ----------------------------------------------------------
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(100) NOT NULL,
  `roll_no` VARCHAR(50) NOT NULL UNIQUE,
  `department` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('student', 'admin') DEFAULT 'student',
  `skill_credits` INT NOT NULL DEFAULT 5,
  `green_points` INT NOT NULL DEFAULT 10,
  `avatar_seed` VARCHAR(50) DEFAULT 'dei',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 2. Table structure for table `rooms`
-- ----------------------------------------------------------
CREATE TABLE `rooms` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `building_name` VARCHAR(100) NOT NULL,
  `room_name` VARCHAR(100) NOT NULL,
  `room_type` ENUM('Classroom', 'Computer Lab', 'Reading Hall') NOT NULL,
  `capacity` INT NOT NULL,
  `status` ENUM('Available', 'Occupied') DEFAULT 'Available',
  `current_activity` VARCHAR(255) DEFAULT 'Self Study / Free for Occupancy',
  `updated_by` VARCHAR(100) DEFAULT 'Faculty Caretaker',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 3. Table structure for table `skills`
-- ----------------------------------------------------------
CREATE TABLE `skills` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `skill_title` VARCHAR(150) NOT NULL,
  `category` ENUM('Coding', 'Academics', 'Design', 'Music/Art') NOT NULL,
  `description` TEXT NOT NULL,
  `availability_time` VARCHAR(100) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_skills_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 4. Table structure for table `skill_transactions`
-- ----------------------------------------------------------
CREATE TABLE `skill_transactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `skill_id` INT NOT NULL,
  `learner_id` INT NOT NULL,
  `mentor_id` INT NOT NULL,
  `status` ENUM('Requested', 'Completed') DEFAULT 'Requested',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_txn_skill` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_txn_learner` FOREIGN KEY (`learner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_txn_mentor` FOREIGN KEY (`mentor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 5. Table structure for table `eco_reports`
-- ----------------------------------------------------------
CREATE TABLE `eco_reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `location` VARCHAR(150) NOT NULL,
  `issue_category` ENUM('Electrical/Fan', 'Water Leakage', 'Cleanliness', 'Green Initiative') NOT NULL,
  `description` TEXT NOT NULL,
  `image_path` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('Open', 'Resolved') DEFAULT 'Open',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_eco_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- PRE-POPULATED DEMO RECORDS FOR DAYALBAGH EDUCATIONAL INSTITUTE
-- ==========================================================

-- Default Passwords:
-- Admin: admin123 -> $2y$10$wO0oD.mBsqYjNlS7a3oOueXh6vSgh3R14c2Wv2xXq2kUe05sWbm0S
-- Student: student123 -> $2y$10$0s9hFkE3eD6r.7c.R51u9epm2VvV0O3Esh/1ZtzC.f1X0Kj2D0w/a

INSERT INTO `users` (`id`, `full_name`, `roll_no`, `department`, `email`, `password`, `role`, `skill_credits`, `green_points`, `avatar_seed`) VALUES
(1, 'Dr. Anand Swarup', 'DEI-FAC-001', 'Faculty of Engineering', 'admin@dei.ac.in', '$2y$10$wO0oD.mBsqYjNlS7a3oOueXh6vSgh3R14c2Wv2xXq2kUe05sWbm0S', 'admin', 15, 60, 'anand'),
(2, 'Aarav Sharma', '220101', 'Faculty of Engineering - Mechanical', 'aarav@dei.ac.in', '$2y$10$0s9hFkE3eD6r.7c.R51u9epm2VvV0O3Esh/1ZtzC.f1X0Kj2D0w/a', 'student', 7, 35, 'aarav'),
(3, 'Priya Verma', '220205', 'Faculty of Science - Physics', 'priya@dei.ac.in', '$2y$10$0s9hFkE3eD6r.7c.R51u9epm2VvV0O3Esh/1ZtzC.f1X0Kj2D0w/a', 'student', 6, 45, 'priya'),
(4, 'Rohan Gupta', '220312', 'Multimedia Lab & Design', 'rohan@dei.ac.in', '$2y$10$0s9hFkE3eD6r.7c.R51u9epm2VvV0O3Esh/1ZtzC.f1X0Kj2D0w/a', 'student', 4, 20, 'rohan'),
(5, 'Sunidhi Satsangi', '220419', 'Faculty of Social Sciences', 'sunidhi@dei.ac.in', '$2y$10$0s9hFkE3eD6r.7c.R51u9epm2VvV0O3Esh/1ZtzC.f1X0Kj2D0w/a', 'student', 8, 50, 'sunidhi');

-- ----------------------------------------------------------
-- 8 Realistic DEI Rooms & Labs
-- ----------------------------------------------------------
INSERT INTO `rooms` (`id`, `building_name`, `room_name`, `room_type`, `capacity`, `status`, `current_activity`, `updated_by`) VALUES
(1, 'Faculty of Engineering', 'Lecture Hall E-204', 'Classroom', 65, 'Available', 'Free for Group Study / Presentation Rehearsal', 'Aarav Sharma'),
(2, 'Faculty of Engineering', 'Advanced CAD/CAM & Robotics Lab', 'Computer Lab', 40, 'Occupied', 'B.Tech Mechanical SolidWorks Lab Session', 'Dr. Anand Swarup'),
(3, 'Faculty of Science', 'Quantum Physics Room S-102', 'Classroom', 45, 'Available', 'Free for Self Study & Peer Mentorship', 'Priya Verma'),
(4, 'Faculty of Science', 'Spectroscopy & Optics Research Lab', 'Classroom', 30, 'Occupied', 'M.Sc Optics Practical in progress', 'Lab Assistant Verma'),
(5, 'Multimedia Lab', 'Creative UI/UX & VR Suite M-01', 'Computer Lab', 32, 'Available', 'Open for Project Work & Video Editing', 'Rohan Gupta'),
(6, 'Central Library', 'Quiet Study Hall - 1st Floor', 'Reading Hall', 120, 'Available', 'Silent Reading & Research Zone (AC Enabled)', 'Librarian Dayal'),
(7, 'Seminar Hall Complex', 'Main Auditorium (Dayal Hall)', 'Classroom', 250, 'Occupied', 'Dean Address on Campus Sustainability', 'Security Desk'),
(8, 'DEI Canteen & Campus Hub', 'Solar Pavilion Study Kiosk', 'Reading Hall', 50, 'Available', 'Open air collaborative study tables with power outlets', 'Eco-Club DEI');

-- ----------------------------------------------------------
-- 6 Pre-inserted Student Skills
-- ----------------------------------------------------------
INSERT INTO `skills` (`id`, `user_id`, `skill_title`, `category`, `description`, `availability_time`) VALUES
(1, 2, 'Python Data Structures & LeetCode Prep', 'Coding', 'Can help 1st & 2nd year students conquer Trees, Graphs, and Dynamic Programming with clear whiteboard drawings and DEI course alignment.', 'Mon & Thu: 5:00 PM - 7:00 PM'),
(2, 4, 'Figma UI/UX & Mobile App Prototyping', 'Design', 'Learn wireframing, modern auto-layout, interactive prototypes, and typography pairings. Perfect for project presentations!', 'Tue & Sat: 4:30 PM - 6:30 PM'),
(3, 3, 'Quantum Mechanics & Mathematical Physics', 'Academics', 'Confused about Wavefunctions or Dirac notation? Let me walk you through intuitive problem-solving strategies before mid-semester tests.', 'Wed & Fri: 3:00 PM - 5:00 PM'),
(4, 5, 'Classical Sitar & Morning Ragas (DEI Tradition)', 'Music/Art', 'Experience Dayalbagh rich musical legacy: basic finger techniques, Swaras, and Raga Yaman foundations for beginners.', 'Sunday: 10:00 AM - 12:00 PM'),
(5, 2, 'SolidWorks 3D Modeling & 3D Printing Prep', 'Design', 'Get hands-on mechanical CAD skills for capstone projects, drone frames, and lab fabrication at DEI Engineering workshop.', 'Friday: 4:00 PM - 6:00 PM'),
(6, 3, 'LaTeX Thesis & Scientific Research Paper Writing', 'Academics', 'Format your research paper, citations (BibTeX), and equations in Overleaf/LaTeX without wrestling with MS Word formatting!', 'Saturday: 2:00 PM - 4:00 PM');

-- ----------------------------------------------------------
-- Sample Skill Transactions
-- ----------------------------------------------------------
INSERT INTO `skill_transactions` (`id`, `skill_id`, `learner_id`, `mentor_id`, `status`) VALUES
(1, 1, 3, 2, 'Completed'),
(2, 2, 2, 4, 'Requested'),
(3, 3, 5, 3, 'Requested');

-- ----------------------------------------------------------
-- 4 Pre-inserted EcoPulse Campus Reports
-- ----------------------------------------------------------
INSERT INTO `eco_reports` (`id`, `user_id`, `location`, `issue_category`, `description`, `image_path`, `status`) VALUES
(1, 2, 'Faculty of Engineering, Corridor 2nd Floor', 'Electrical/Fan', 'Fan regulator sparking in room E-202. Two ceiling fans left spinning on high speed in an empty room.', 'uploads/sample_electrical.jpg', 'Open'),
(2, 3, 'Faculty of Science, Near Botanical Garden', 'Water Leakage', 'RO Drinking Water dispenser tap is slowly dripping clean filtered water. Urgent washer replacement required.', 'uploads/sample_water.jpg', 'Open'),
(3, 4, 'Central Library Back Lawn', 'Cleanliness', 'Dry autumn leaves and paper cups accumulated near the reading benches after the cultural rehearsal.', 'uploads/sample_cleanliness.jpg', 'Resolved'),
(4, 5, 'DEI Canteen Courtyard', 'Green Initiative', 'Proposed adding a 3-bin segregated composting station for organic food leftovers and tea cups.', 'uploads/sample_green.jpg', 'Open');
