<?php
require_once 'db.php';
require_login();

$user = current_user();
$celebrate = false;

// Handle New Skill Posting
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_skill') {
    $title = clean($_POST['skill_title'] ?? '');
    $category = clean($_POST['category'] ?? '');
    $desc = clean($_POST['description'] ?? '');
    $avail = clean($_POST['availability_time'] ?? '');

    if (!empty($title) && !empty($category) && !empty($desc) && !empty($avail)) {
        $stmt = $conn->prepare("INSERT INTO skills (user_id, skill_title, category, description, availability_time) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $user['id'], $title, $category, $desc, $avail);
        if ($stmt->execute()) {
            set_flash("Awesome! Your skill listing has been published to the DEI community.", "success");
        } else {
            set_flash("Failed to publish skill listing.", "danger");
        }
    } else {
        set_flash("Please fill out all skill listing fields.", "warning");
    }
    header("Location: peerlearn.php");
    exit;
}

// Handle Booking Session
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'book_session') {
    $skill_id = intval($_POST['skill_id'] ?? 0);
    $mentor_id = intval($_POST['mentor_id'] ?? 0);

    if ($mentor_id === $user['id']) {
        set_flash("You cannot book a session with yourself!", "warning");
    } elseif ($user['skill_credits'] < 1) {
        set_flash("Insufficient Skill Credits! Teach a peer or participate in EcoPulse to earn credits.", "danger");
    } else {
        $stmt = $conn->prepare("INSERT INTO skill_transactions (skill_id, learner_id, mentor_id, status) VALUES (?, ?, ?, 'Requested')");
        $stmt->bind_param("iii", $skill_id, $user['id'], $mentor_id);
        if ($stmt->execute()) {
            set_flash("1-Hr Session requested! When the session concludes, mark it complete in 'My Sessions'.", "success");
        } else {
            set_flash("Failed to book session.", "danger");
        }
    }
    header("Location: peerlearn.php");
    exit;
}

// Handle Complete Session (Transactional Exchange of 1 Credit)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'complete_session') {
    $txn_id = intval($_POST['txn_id'] ?? 0);

    // Fetch transaction details
    $stmt = $conn->prepare("SELECT id, skill_id, learner_id, mentor_id, status FROM skill_transactions WHERE id = ?");
    $stmt->bind_param("i", $txn_id);
    $stmt->execute();
    $txn = $stmt->get_result()->fetch_assoc();

    if ($txn && $txn['status'] === 'Requested') {
        // Safe Transaction
        $conn->begin_transaction();
        try {
            // Check learner credits
            $c_stmt = $conn->prepare("SELECT skill_credits FROM users WHERE id = ? FOR UPDATE");
            $c_stmt->bind_param("i", $txn['learner_id']);
            $c_stmt->execute();
            $l_credits = $c_stmt->get_result()->fetch_assoc()['skill_credits'] ?? 0;

            if ($l_credits < 1) {
                throw new Exception("Learner has insufficient balance to complete transfer.");
            }

            // Deduct 1 from learner
            $d_stmt = $conn->prepare("UPDATE users SET skill_credits = skill_credits - 1 WHERE id = ?");
            $d_stmt->bind_param("i", $txn['learner_id']);
            $d_stmt->execute();

            // Add 1 to mentor
            $a_stmt = $conn->prepare("UPDATE users SET skill_credits = skill_credits + 1 WHERE id = ?");
            $a_stmt->bind_param("i", $txn['mentor_id']);
            $a_stmt->execute();

            // Mark completed
            $u_stmt = $conn->prepare("UPDATE skill_transactions SET status = 'Completed' WHERE id = ?");
            $u_stmt->bind_param("i", $txn_id);
            $u_stmt->execute();

            $conn->commit();
            set_flash("🎉 Session completed! 1 Skill Credit transferred to mentor. Keep up the learning streak!", "success");
            header("Location: peerlearn.php?celebrate=1");
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            set_flash("Transaction error: " . $e->getMessage(), "danger");
            header("Location: peerlearn.php");
            exit;
        }
    }
}

if (isset($_GET['celebrate'])) {
    $celebrate = true;
}

// Fetch Active Category Filter
$cat_filter = clean($_GET['category'] ?? 'all');
$sql = "SELECT s.*, u.full_name, u.department, u.roll_no, u.avatar_seed 
        FROM skills s 
        JOIN users u ON s.user_id = u.id 
        WHERE 1=1";
$params = [];
$types = "";

if ($cat_filter !== 'all' && !empty($cat_filter)) {
    $sql .= " AND s.category = ?";
    $params[] = $cat_filter;
    $types .= "s";
}
$sql .= " ORDER BY s.id DESC";
$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$skills = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch My Sessions (as Learner or Mentor)
$my_sessions_stmt = $conn->prepare("
    SELECT st.id as txn_id, st.status, st.created_at,
           s.skill_title, s.category,
           l.full_name as learner_name, l.id as learner_id,
           m.full_name as mentor_name, m.id as mentor_id
    FROM skill_transactions st
    JOIN skills s ON st.skill_id = s.id
    JOIN users l ON st.learner_id = l.id
    JOIN users m ON st.mentor_id = m.id
    WHERE st.learner_id = ? OR st.mentor_id = ?
    ORDER BY st.id DESC
");
$my_sessions_stmt->bind_param("ii", $user['id'], $user['id']);
$my_sessions_stmt->execute();
$my_sessions = $my_sessions_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PeerLearn Skill Barter | ONECAMPUS - DEI</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Canvas Confetti -->
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.2/dist/confetti.browser.min.js"></script>
    <style>
        :root {
            --dei-emerald: #059669;
            --dei-amber: #f59e0b;
        }
        body {
            background-color: #f8fafc;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            color: #1e293b;
        }
        .navbar-dei {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
        }
        .nav-link.active-tab {
            color: var(--dei-emerald) !important;
            font-weight: 600;
            border-bottom: 2px solid var(--dei-emerald);
        }
        .skill-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            transition: all 0.25s ease;
        }
        .skill-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 24px -6px rgba(0, 0, 0, 0.08);
            border-color: #cbd5e1;
        }
        .avatar-circle {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: #ffffff;
        }
        .bg-coding { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
        .bg-academics { background: linear-gradient(135deg, #8b5cf6, #6d28d9); }
        .bg-design { background: linear-gradient(135deg, #ec4899, #be185d); }
        .bg-music { background: linear-gradient(135deg, #f59e0b, #b45309); }

        .btn-emerald {
            background-color: var(--dei-emerald);
            color: #ffffff;
        }
        .btn-emerald:hover {
            background-color: #047857;
            color: #ffffff;
        }
    </style>
</head>
<body>

<!-- Navigation Header -->
<nav class="navbar navbar-expand-lg navbar-dei sticky-top py-2">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold text-dark" href="index.php">
            <span class="bg-success text-white px-2 py-1 rounded-3 fs-6">
                <i class="fa-solid fa-graduation-cap"></i>
            </span>
            <span>ONECAMPUS <span class="badge bg-light text-success border border-success-subtle fw-normal ms-1" style="font-size: 11px;">DEI Agra</span></span>
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3 gap-1">
                <li class="nav-item">
                    <a class="nav-link px-3 text-secondary" href="index.php">
                        <i class="fa-solid fa-door-open me-1"></i> SmartSpace
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 active-tab" href="peerlearn.php">
                        <i class="fa-solid fa-handshake-simple me-1"></i> PeerLearn
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 text-secondary" href="ecopulse.php">
                        <i class="fa-solid fa-leaf me-1"></i> EcoPulse
                    </a>
                </li>
            </ul>

            <!-- Balance & User -->
            <div class="d-flex align-items-center gap-3">
                <span class="badge bg-warning-subtle text-dark border border-warning px-3 py-2 rounded-pill fw-semibold">
                    <i class="fa-solid fa-coins text-warning me-1"></i> <?= $user['skill_credits']; ?> Skill Credits
                </span>

                <div class="dropdown">
                    <button class="btn btn-light btn-sm dropdown-toggle rounded-pill px-3 border" type="button" data-bs-toggle="dropdown">
                        <i class="fa-solid fa-circle-user text-secondary me-1"></i> <?= htmlspecialchars($user['full_name']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                        <li class="px-3 py-1">
                            <small class="text-muted d-block"><?= htmlspecialchars($user['department']); ?></small>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>

<main class="container py-4">

    <!-- Flash Alert -->
    <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type']; ?> alert-dismissible fade show rounded-3 shadow-sm mb-4" role="alert">
            <?= htmlspecialchars($flash['text']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Header Section -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-2 border-bottom">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <span class="badge bg-warning-subtle text-warning-emphasis px-2 py-0.5 rounded">Cashless Peer Barter</span>
                <span class="text-secondary opacity-50">·</span>
                <span class="text-muted small">Inspired by Simbi & Stanford Peer Learning</span>
            </div>
            <h2 class="fw-bold tracking-tight mb-0">PeerLearn Skill Marketplace</h2>
            <p class="text-secondary small mb-0">Teach what you love, learn what you need — 1 Credit per 1-Hour peer session.</p>
        </div>

        <div class="d-flex gap-2">
            <!-- Button Trigger Modal -->
            <button type="button" class="btn btn-emerald btn-sm px-3 rounded-pill" data-bs-toggle="modal" data-bs-target="#offerSkillModal">
                <i class="fa-solid fa-plus me-1"></i> Offer a Skill (+Credits)
            </button>
            <a href="#mySessionsSection" class="btn btn-outline-secondary btn-sm px-3 rounded-pill">
                <i class="fa-solid fa-list-check me-1"></i> My Sessions (<?= count($my_sessions); ?>)
            </a>
        </div>
    </div>

    <!-- Category Filter Pills -->
    <div class="d-flex flex-wrap gap-2 mb-4">
        <a href="peerlearn.php?category=all" class="btn btn-sm <?= $cat_filter === 'all' ? 'btn-dark' : 'btn-outline-secondary'; ?> rounded-pill px-3">
            All Skills
        </a>
        <a href="peerlearn.php?category=Coding" class="btn btn-sm <?= $cat_filter === 'Coding' ? 'btn-primary' : 'btn-outline-secondary'; ?> rounded-pill px-3">
            <i class="fa-solid fa-code me-1"></i> Coding & Tech
        </a>
        <a href="peerlearn.php?category=Academics" class="btn btn-sm <?= $cat_filter === 'Academics' ? 'btn-secondary text-white' : 'btn-outline-secondary'; ?> rounded-pill px-3">
            <i class="fa-solid fa-book me-1"></i> Academics & Research
        </a>
        <a href="peerlearn.php?category=Design" class="btn btn-sm <?= $cat_filter === 'Design' ? 'btn-danger' : 'btn-outline-secondary'; ?> rounded-pill px-3">
            <i class="fa-solid fa-pen-nib me-1"></i> UI/UX & CAD Design
        </a>
        <a href="peerlearn.php?category=Music/Art" class="btn btn-sm <?= $cat_filter === 'Music/Art' ? 'btn-warning text-dark' : 'btn-outline-secondary'; ?> rounded-pill px-3">
            <i class="fa-solid fa-guitar me-1"></i> Music & DEI Arts
        </a>
    </div>

    <!-- Skills Cards Feed -->
    <div class="row g-4 mb-5">
        <?php if (empty($skills)): ?>
            <div class="col-12 py-5 text-center text-muted">
                <i class="fa-solid fa-graduation-cap fs-2 mb-2 d-block opacity-50"></i>
                No skill listings found in this category yet. Be the first student to post one!
            </div>
        <?php else: ?>
            <?php foreach ($skills as $skill): ?>
                <?php 
                    $catClass = 'bg-coding';
                    if ($skill['category'] === 'Academics') $catClass = 'bg-academics';
                    if ($skill['category'] === 'Design') $catClass = 'bg-design';
                    if ($skill['category'] === 'Music/Art') $catClass = 'bg-music';
                    $initials = strtoupper(substr($skill['full_name'], 0, 1));
                    $isSelf = ($skill['user_id'] === $user['id']);
                ?>
                <div class="col-md-6 col-lg-4">
                    <div class="skill-card p-4 h-100 d-flex flex-column justify-content-between">
                        <div>
                            <!-- Header: User Avatar & Tag -->
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="avatar-circle <?= $catClass; ?>">
                                        <?= $initials; ?>
                                    </div>
                                    <div>
                                        <h6 class="fw-bold mb-0 text-dark"><?= htmlspecialchars($skill['full_name']); ?></h6>
                                        <small class="text-muted" style="font-size: 11px;"><?= htmlspecialchars($skill['department']); ?></small>
                                    </div>
                                </div>
                                <span class="badge bg-light text-secondary border px-2 py-1 rounded" style="font-size: 11px;">
                                    <?= htmlspecialchars($skill['category']); ?>
                                </span>
                            </div>

                            <!-- Title & Description -->
                            <h5 class="fw-bold text-dark mb-2"><?= htmlspecialchars($skill['skill_title']); ?></h5>
                            <p class="text-secondary small mb-3" style="line-height: 1.5;">
                                <?= htmlspecialchars($skill['description']); ?>
                            </p>

                            <!-- Availability Badge -->
                            <div class="p-2 rounded bg-light small text-secondary mb-4">
                                <i class="fa-regular fa-clock me-1 text-muted"></i> <strong>Slots:</strong> <?= htmlspecialchars($skill['availability_time']); ?>
                            </div>
                        </div>

                        <!-- Footer CTA -->
                        <div class="pt-3 border-top d-flex justify-content-between align-items-center">
                            <span class="fw-bold text-dark small">
                                <i class="fa-solid fa-coins text-warning me-1"></i> 1 Credit <span class="text-muted fw-normal">/ hr</span>
                            </span>

                            <?php if ($isSelf): ?>
                                <span class="badge bg-secondary-subtle text-secondary py-2 px-3 rounded-pill">Your Listing</span>
                            <?php else: ?>
                                <form action="peerlearn.php" method="POST" class="m-0">
                                    <input type="hidden" name="action" value="book_session">
                                    <input type="hidden" name="skill_id" value="<?= $skill['id']; ?>">
                                    <input type="hidden" name="mentor_id" value="<?= $skill['user_id']; ?>">
                                    <button type="submit" class="btn btn-emerald btn-sm px-3 rounded-pill">
                                        Book Session
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- My Sessions Management Section -->
    <div id="mySessionsSection" class="card border-0 shadow-sm rounded-4 p-4 bg-white">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h4 class="fw-bold mb-0">My Peer Learning Sessions</h4>
                <p class="text-secondary small mb-0">Manage requested and completed 1-to-1 tutoring trades.</p>
            </div>
            <span class="badge bg-light text-secondary border"><?= count($my_sessions); ?> Sessions</span>
        </div>

        <?php if (empty($my_sessions)): ?>
            <div class="py-4 text-center text-muted small">
                No active or historical peer sessions yet. Book a session from the marketplace above!
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead class="table-light">
                        <tr class="small text-muted text-uppercase">
                            <th>Skill</th>
                            <th>Mentor</th>
                            <th>Learner</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($my_sessions as $sess): ?>
                            <tr>
                                <td>
                                    <span class="fw-semibold text-dark"><?= htmlspecialchars($sess['skill_title']); ?></span>
                                    <div class="badge bg-light text-secondary border" style="font-size: 10px;"><?= $sess['category']; ?></div>
                                </td>
                                <td>
                                    <?= htmlspecialchars($sess['mentor_name']); ?>
                                    <?= ($sess['mentor_id'] === $user['id']) ? '<span class="badge bg-success-subtle text-success ms-1">You</span>' : ''; ?>
                                </td>
                                <td>
                                    <?= htmlspecialchars($sess['learner_name']); ?>
                                    <?= ($sess['learner_id'] === $user['id']) ? '<span class="badge bg-primary-subtle text-primary ms-1">You</span>' : ''; ?>
                                </td>
                                <td>
                                    <?php if ($sess['status'] === 'Completed'): ?>
                                        <span class="badge bg-success-subtle text-success px-2 py-1 rounded-pill">
                                            <i class="fa-solid fa-check me-1"></i> Completed
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-warning-subtle text-warning-emphasis px-2 py-1 rounded-pill">
                                            <i class="fa-solid fa-hourglass-half me-1"></i> Requested
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted small">
                                    <?= date('d M, Y', strtotime($sess['created_at'])); ?>
                                </td>
                                <td class="text-end">
                                    <?php if ($sess['status'] === 'Requested'): ?>
                                        <!-- Safe Transaction Completion Button -->
                                        <form action="peerlearn.php" method="POST" class="d-inline">
                                            <input type="hidden" name="action" value="complete_session">
                                            <input type="hidden" name="txn_id" value="<?= $sess['txn_id']; ?>">
                                            <button type="submit" class="btn btn-outline-success btn-sm rounded-pill px-3" onclick="return confirm('Confirm completing this 1-hour session? 1 credit will transfer from learner to mentor.');">
                                                Complete & Transfer Credit 🎉
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted small"><i class="fa-solid fa-circle-check text-success me-1"></i> Settled</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

</main>

<!-- Offer Skill Modal -->
<div class="modal fade" id="offerSkillModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <div class="modal-header border-bottom-0 pb-0">
                <h5 class="modal-title fw-bold">Offer a Peer Skill</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="peerlearn.php" method="POST">
                <input type="hidden" name="action" value="create_skill">
                <div class="modal-body">
                    <p class="text-secondary small mb-3">Earn Skill Credits by teaching juniors or classmates in your domain.</p>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Skill Title</label>
                        <input type="text" name="skill_title" class="form-control" placeholder="e.g. ROS Robotics & MATLAB Simulation" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Category</label>
                        <select name="category" class="form-select" required>
                            <option value="Coding">Coding & Tech</option>
                            <option value="Academics">Academics & Science</option>
                            <option value="Design">UI/UX & CAD Modeling</option>
                            <option value="Music/Art">Music & Fine Arts</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Description & What You'll Cover</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Briefly describe what a peer will learn during your 1-hour session..." required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Your Free Slots / Availability</label>
                        <input type="text" name="availability_time" class="form-control" placeholder="e.g. Wednesday & Friday: 4:00 PM - 6:00 PM" required>
                    </div>
                </div>
                <div class="modal-footer border-top-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-emerald rounded-pill px-4">Publish Listing</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<?php if ($celebrate): ?>
<script>
window.addEventListener('DOMContentLoaded', () => {
    confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
    });
});
</script>
<?php endif; ?>

</body>
</html>
